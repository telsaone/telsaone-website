-- Jalankan sekali di Supabase > SQL Editor SETELAH telsaone-level.sql. Aman dijalankan ulang.
-- Memperbaiki: level di Papan Peringkat tidak ikut naik (misal tampil LV 16 padahal sudah level 21)
-- karena level hanya diperbarui kalau skor baru > skor terbaik. Sekarang untuk Brick Breaker
-- level di papan peringkat = level tertinggi yang pernah dicapai pemain.

-- 1) kirim_skor: level Brick Breaker tidak pernah turun
create or replace function public.kirim_skor(p_game text, p_skor int, p_level int)
returns int
language plpgsql
security definer
set search_path = public
as $$
declare
  terbaik int;
begin
  if auth.uid() is null then
    raise exception 'Harus login';
  end if;
  if p_skor is null or p_skor < 0 or p_skor > 1000000 then
    raise exception 'Skor tidak valid';
  end if;
  if exists (select 1 from public.games where id = p_game and status = 'archived') then
    raise exception 'Game sudah diarsipkan';
  end if;

  insert into public.game_scores as t (game_id, user_id, skor, level, plays)
  values (p_game, auth.uid(), p_skor, greatest(coalesce(p_level, 1), 1), 1)
  on conflict (game_id, user_id) do update set
    plays = t.plays + 1,
    last_played = now(),
    skor = greatest(t.skor, excluded.skor),
    level = case
      when excluded.game_id = 'brick' then greatest(t.level, excluded.level)
      when excluded.skor > t.skor then excluded.level
      else t.level end,
    best_at = case when excluded.skor > t.skor then now() else t.best_at end;

  perform public.sinkron_juara(p_game);

  select skor into terbaik from public.game_scores where game_id = p_game and user_id = auth.uid();
  return terbaik;
end;
$$;
revoke all on function public.kirim_skor(text, int, int) from public, anon;
grant execute on function public.kirim_skor(text, int, int) to authenticated;

-- 2) selesai_level: begitu level selesai, level di papan peringkat langsung ikut naik (level berikutnya)
create or replace function public.selesai_level(p_game text, p_level int)
returns void language plpgsql security definer set search_path = public as $$
declare baru int;
begin
  if auth.uid() is null then return; end if;
  if p_level is null or p_level < 1 or p_level > 500 then return; end if;
  if exists (select 1 from public.games where id = p_game and status = 'archived') then return; end if;
  if p_level > 1 and not exists (select 1 from public.level_selesai where game_id = p_game and user_id = auth.uid() and level = p_level - 1)
     and coalesce((select gs.level from public.game_scores gs where gs.game_id = p_game and gs.user_id = auth.uid()), 1) < p_level then return; end if;
  if exists (select 1 from public.level_selesai where game_id = p_game and user_id = auth.uid() and selesai_at > now() - interval '12 seconds') then return; end if;

  insert into public.level_selesai (game_id, user_id, level) values (p_game, auth.uid(), p_level) on conflict do nothing;
  get diagnostics baru = row_count;

  if p_game = 'brick' then
    update public.game_scores set level = greatest(level, least(p_level + 1, 500))
    where game_id = p_game and user_id = auth.uid();
  end if;

  if baru = 0 or not public.level_aktif() or not public.kaget_aktif() or p_level > public.level_maks() then return; end if;

  insert into public.dana_kaget_hadiah (game_id, user_id, jenis, level) values (p_game, auth.uid(), 'level', p_level) on conflict do nothing;
  perform public.isi_hadiah_tertunda();
end;
$$;
revoke all on function public.selesai_level(text, int) from public, anon;
grant execute on function public.selesai_level(text, int) to authenticated;

-- 3) Perbaiki data lama: samakan level di papan peringkat dengan level terjauh yang sudah diselesaikan
update public.game_scores gs
set level = greatest(gs.level, x.maks + 1)
from (select game_id, user_id, max(level) as maks from public.level_selesai where game_id = 'brick' group by game_id, user_id) x
where gs.game_id = x.game_id and gs.user_id = x.user_id;

notify pgrst, 'reload schema';
