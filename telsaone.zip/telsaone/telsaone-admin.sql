-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-chat.sql).
-- Admin web = akun Google dengan email GANTI_DENGAN_EMAIL_ADMIN.

-- Fungsi pengecekan admin (dibaca dari token login, tidak bisa dipalsukan pengguna)
create or replace function public.is_admin()
returns boolean language sql stable as $$
  select coalesce(
    lower(auth.jwt() ->> 'email') = 'GANTI_DENGAN_EMAIL_ADMIN'
    and (auth.jwt() -> 'app_metadata' -> 'providers') @> '["google"]'::jsonb,
    false);
$$;

-- Isi web (musik, media, tautan, teks): semua orang boleh membaca, hanya admin yang boleh mengubah
create table if not exists public.site_content (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.site_content enable row level security;

drop policy if exists "konten dibaca semua" on public.site_content;
create policy "konten dibaca semua" on public.site_content for select using (true);
drop policy if exists "konten admin insert" on public.site_content;
create policy "konten admin insert" on public.site_content for insert to authenticated with check (public.is_admin());
drop policy if exists "konten admin update" on public.site_content;
create policy "konten admin update" on public.site_content for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "konten admin delete" on public.site_content;
create policy "konten admin delete" on public.site_content for delete to authenticated using (public.is_admin());

-- Bucket file musik/gambar/video (maks 50 MB per file)
insert into storage.buckets (id, name, public, file_size_limit)
values ('konten', 'konten', true, 52428800)
on conflict (id) do nothing;

drop policy if exists "konten file dibaca semua" on storage.objects;
create policy "konten file dibaca semua" on storage.objects for select using (bucket_id = 'konten');
drop policy if exists "konten file admin insert" on storage.objects;
create policy "konten file admin insert" on storage.objects for insert to authenticated with check (bucket_id = 'konten' and public.is_admin());
drop policy if exists "konten file admin update" on storage.objects;
create policy "konten file admin update" on storage.objects for update to authenticated using (bucket_id = 'konten' and public.is_admin());
drop policy if exists "konten file admin delete" on storage.objects;
create policy "konten file admin delete" on storage.objects for delete to authenticated using (bucket_id = 'konten' and public.is_admin());

-- Admin boleh menghapus pesan chat siapa saja
drop policy if exists "pesan hapus admin" on public.messages;
create policy "pesan hapus admin" on public.messages for delete to authenticated using (public.is_admin());
