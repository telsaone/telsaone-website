-- ============================================================
-- telsaone: SEMUA SQL dalam satu file, urutan sudah benar.
-- Supabase > SQL Editor > New query > tempel seluruh isi > Run (aman dijalankan ulang).
-- Tidak termasuk telsaone-story-cron.sql (butuh pg_cron + service key, jalankan terpisah setelah ini).
-- ============================================================

-- ################ telsaone-chat.sql ################
-- Jalankan sekali di Supabase > SQL Editor.
-- Membuat: profil publik (nama + foto), pesan chat, dan bucket foto profil.

-- 1) Profil publik (diisi otomatis oleh aplikasi dari data login)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nama text not null default 'Pengguna',
  avatar_icon text not null default '',
  avatar_bg text not null default '#ffe45e',
  avatar_url text not null default '',
  bio text not null default '',
  joined_at timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

drop policy if exists "profil dibaca semua" on public.profiles;
create policy "profil dibaca semua" on public.profiles for select using (true);
drop policy if exists "profil sendiri insert" on public.profiles;
create policy "profil sendiri insert" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "profil sendiri update" on public.profiles;
create policy "profil sendiri update" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- 2) Pesan chat: semua orang boleh membaca, hanya yang login boleh mengirim
create table if not exists public.messages (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(btrim(content)) between 1 and 500),
  created_at timestamptz not null default now()
);
create index if not exists messages_created_idx on public.messages (created_at desc);
alter table public.messages enable row level security;

drop policy if exists "pesan dibaca semua" on public.messages;
create policy "pesan dibaca semua" on public.messages for select using (true);
drop policy if exists "pesan kirim sendiri" on public.messages;
create policy "pesan kirim sendiri" on public.messages for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "pesan hapus sendiri" on public.messages;
create policy "pesan hapus sendiri" on public.messages for delete to authenticated using (auth.uid() = user_id);

-- Realtime (pesan baru muncul langsung di semua perangkat)
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null; end $$;

-- 3) Bucket foto profil (publik dibaca, hanya pemilik yang boleh unggah/hapus)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 1048576, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists "avatar dibaca semua" on storage.objects;
create policy "avatar dibaca semua" on storage.objects for select using (bucket_id = 'avatars');
drop policy if exists "avatar unggah sendiri" on storage.objects;
create policy "avatar unggah sendiri" on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "avatar ubah sendiri" on storage.objects;
create policy "avatar ubah sendiri" on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "avatar hapus sendiri" on storage.objects;
create policy "avatar hapus sendiri" on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);


-- ################ telsaone-profil-stat.sql ################
-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-chat.sql).
-- Menambah bio dan tanggal bergabung ke profil publik, dipakai kartu statistik di halaman chat.

alter table public.profiles add column if not exists bio text not null default '';
alter table public.profiles add column if not exists joined_at timestamptz;

-- Isi data untuk pengguna yang sudah ada
update public.profiles p
set joined_at = coalesce(p.joined_at, u.created_at),
    bio = case when p.bio = '' then coalesce(left(u.raw_user_meta_data ->> 'bio', 120), '') else p.bio end
from auth.users u
where u.id = p.id;


-- ################ telsaone-admin.sql ################
-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-chat.sql).
-- Admin web = akun Google dengan email GANTI_DENGAN_EMAIL_ADMIN.

-- Fungsi pengecekan admin (dibaca dari token login, tidak bisa dipalsukan pengguna)
create or replace function public.is_admin()
returns boolean language sql stable as $$
  select coalesce(
    lower(auth.jwt() ->> 'email') = 'GANTI_DENGAN_EMAIL_ADMIN'
    and (auth.jwt() -> 'app_metadata' -> 'providers') @> '["google"]'::jsonb,
    false);
$$;

-- Isi web (musik, media, tautan, teks): semua orang boleh membaca, hanya admin yang boleh mengubah
create table if not exists public.site_content (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.site_content enable row level security;

drop policy if exists "konten dibaca semua" on public.site_content;
create policy "konten dibaca semua" on public.site_content for select using (true);
drop policy if exists "konten admin insert" on public.site_content;
create policy "konten admin insert" on public.site_content for insert to authenticated with check (public.is_admin());
drop policy if exists "konten admin update" on public.site_content;
create policy "konten admin update" on public.site_content for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "konten admin delete" on public.site_content;
create policy "konten admin delete" on public.site_content for delete to authenticated using (public.is_admin());

-- Bucket file musik/gambar/video (maks 50 MB per file)
insert into storage.buckets (id, name, public, file_size_limit)
values ('konten', 'konten', true, 52428800)
on conflict (id) do nothing;

drop policy if exists "konten file dibaca semua" on storage.objects;
create policy "konten file dibaca semua" on storage.objects for select using (bucket_id = 'konten');
drop policy if exists "konten file admin insert" on storage.objects;
create policy "konten file admin insert" on storage.objects for insert to authenticated with check (bucket_id = 'konten' and public.is_admin());
drop policy if exists "konten file admin update" on storage.objects;
create policy "konten file admin update" on storage.objects for update to authenticated using (bucket_id = 'konten' and public.is_admin());
drop policy if exists "konten file admin delete" on storage.objects;
create policy "konten file admin delete" on storage.objects for delete to authenticated using (bucket_id = 'konten' and public.is_admin());

-- Admin boleh menghapus pesan chat siapa saja
drop policy if exists "pesan hapus admin" on public.messages;
create policy "pesan hapus admin" on public.messages for delete to authenticated using (public.is_admin());


-- ################ telsaone-game.sql ################
-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-chat.sql dan telsaone-admin.sql).
-- Membuat: status game (terbit / arsip, diatur admin) dan papan peringkat publik per game.

-- 1) Status game: semua orang boleh membaca, hanya admin yang boleh mengubah
create table if not exists public.games (
  id text primary key,
  judul text not null,
  status text not null default 'published' check (status in ('published', 'archived')),
  updated_at timestamptz not null default now()
);
alter table public.games enable row level security;

drop policy if exists "game dibaca semua" on public.games;
create policy "game dibaca semua" on public.games for select using (true);
drop policy if exists "game admin insert" on public.games;
create policy "game admin insert" on public.games for insert to authenticated with check (public.is_admin());
drop policy if exists "game admin update" on public.games;
create policy "game admin update" on public.games for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "game admin delete" on public.games;
create policy "game admin delete" on public.games for delete to authenticated using (public.is_admin());

insert into public.games (id, judul, status) values ('brick', 'Brick Breaker', 'published')
on conflict (id) do nothing;

-- 2) Skor terbaik tiap pemain per game (satu baris per pemain per game)
create table if not exists public.game_scores (
  game_id text not null,
  user_id uuid not null references public.profiles(id) on delete cascade,
  skor int not null default 0 check (skor >= 0),
  level int not null default 1,
  plays int not null default 0,
  best_at timestamptz not null default now(),
  last_played timestamptz not null default now(),
  primary key (game_id, user_id)
);
create index if not exists game_scores_rank_idx on public.game_scores (game_id, skor desc, best_at);
alter table public.game_scores enable row level security;

-- Papan peringkat publik: semua orang boleh membaca
drop policy if exists "skor dibaca semua" on public.game_scores;
create policy "skor dibaca semua" on public.game_scores for select using (true);
-- Pemain TIDAK menulis langsung ke tabel; hanya lewat fungsi kirim_skor di bawah.
-- Admin boleh menghapus skor (moderasi)
drop policy if exists "skor hapus admin" on public.game_scores;
create policy "skor hapus admin" on public.game_scores for delete to authenticated using (public.is_admin());

-- 3) Kirim skor: hanya untuk yang login, game yang diarsipkan ditolak, skor terbaik disimpan otomatis
create or replace function public.kirim_skor(p_game text, p_skor int, p_level int)
returns int
language plpgsql
security definer
set search_path = public
as $$
declare
  terbaik int;
begin
  if auth.uid() is null then
    raise exception 'Harus login';
  end if;
  if p_skor is null or p_skor < 0 or p_skor > 1000000 then
    raise exception 'Skor tidak valid';
  end if;
  if exists (select 1 from public.games where id = p_game and status = 'archived') then
    raise exception 'Game sudah diarsipkan';
  end if;

  insert into public.game_scores as t (game_id, user_id, skor, level, plays)
  values (p_game, auth.uid(), p_skor, greatest(coalesce(p_level, 1), 1), 1)
  on conflict (game_id, user_id) do update set
    plays = t.plays + 1,
    last_played = now(),
    skor = greatest(t.skor, excluded.skor),
    level = case when excluded.skor > t.skor then excluded.level else t.level end,
    best_at = case when excluded.skor > t.skor then now() else t.best_at end;

  select skor into terbaik from public.game_scores where game_id = p_game and user_id = auth.uid();
  return terbaik;
end;
$$;

revoke all on function public.kirim_skor(text, int, int) from public;
grant execute on function public.kirim_skor(text, int, int) to authenticated;


-- ################ telsaone-hadiah.sql ################
-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-chat.sql, telsaone-admin.sql, dan telsaone-game.sql).
-- Hadiah Dana Kaget: pemain peringkat 1 yang TIDAK TERGESER selama N jam (bawaan 24) mendapat satu link Dana Kaget.
-- Link diunggah admin lewat panel Admin > HADIAH. Link bersifat rahasia: tabelnya hanya bisa dibaca admin,
-- pemenang menerimanya lewat fungsi hadiah_saya() (hanya link miliknya sendiri).
-- Aman dijalankan ulang.

-- 1) Siapa yang memegang peringkat 1 dan sejak kapan (publik, tidak berisi rahasia)
create table if not exists public.juara_game (
  game_id text primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  sejak timestamptz not null default now(),
  hadiah_diberikan boolean not null default false
);
alter table public.juara_game enable row level security;
drop policy if exists "juara dibaca semua" on public.juara_game;
create policy "juara dibaca semua" on public.juara_game for select using (true);
-- Tidak ada policy tulis: hanya fungsi di bawah yang mengubahnya.

-- 2) Stok link Dana Kaget (RAHASIA: hanya admin)
create table if not exists public.dana_kaget_link (
  id bigint generated always as identity primary key,
  url text not null unique check (url ~ '^https://[^[:space:]]+$' and length(url) <= 500),
  dibuat timestamptz not null default now()
);
alter table public.dana_kaget_link enable row level security;
drop policy if exists "link admin baca" on public.dana_kaget_link;
create policy "link admin baca" on public.dana_kaget_link for select to authenticated using (public.is_admin());
drop policy if exists "link admin tambah" on public.dana_kaget_link;
create policy "link admin tambah" on public.dana_kaget_link for insert to authenticated with check (public.is_admin());
drop policy if exists "link admin hapus" on public.dana_kaget_link;
create policy "link admin hapus" on public.dana_kaget_link for delete to authenticated using (public.is_admin());

-- 3) Catatan pemenang. link_id kosong = menang tapi stok link habis (diisi otomatis saat admin menambah link)
create table if not exists public.dana_kaget_hadiah (
  id bigint generated always as identity primary key,
  game_id text not null,
  user_id uuid not null references public.profiles(id) on delete cascade,
  link_id bigint unique references public.dana_kaget_link(id) on delete restrict,
  menang_at timestamptz not null default now(),
  dilihat_at timestamptz
);
alter table public.dana_kaget_hadiah enable row level security;
drop policy if exists "hadiah admin baca" on public.dana_kaget_hadiah;
create policy "hadiah admin baca" on public.dana_kaget_hadiah for select to authenticated using (public.is_admin());
-- Pemain membaca hadiahnya lewat fungsi hadiah_saya(), bukan langsung dari tabel.

-- 4) Pengaturan (dibaca dari site_content, kunci 'dana_kaget', diubah admin di panel)
create or replace function public.jam_kaget()
returns int language sql stable security definer set search_path = public as $$
  select coalesce(
    (select case when value->>'jam' ~ '^[0-9]{1,4}$' then least(greatest((value->>'jam')::int, 1), 720) end
       from public.site_content where key = 'dana_kaget'),
    24);
$$;

create or replace function public.kaget_aktif()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select value->>'aktif' from public.site_content where key = 'dana_kaget'), 'true') <> 'false';
$$;

-- 5) Isi hadiah yang menunggu link dengan stok link yang masih bebas (urut paling lama)
create or replace function public.isi_hadiah_tertunda()
returns void language plpgsql security definer set search_path = public as $$
declare h record; l bigint;
begin
  perform pg_advisory_xact_lock(7001);
  for h in select id from public.dana_kaget_hadiah where link_id is null order by id loop
    l := null;
    select k.id into l from public.dana_kaget_link k
      where not exists (select 1 from public.dana_kaget_hadiah x where x.link_id = k.id)
      order by k.id limit 1;
    exit when l is null;
    update public.dana_kaget_hadiah set link_id = l where id = h.id;
  end loop;
end;
$$;

-- 6) Catat pemenang (dan langsung pasangkan link jika stok ada)
create or replace function public.beri_hadiah(p_game text, p_user uuid)
returns boolean language plpgsql security definer set search_path = public as $$
begin
  if not public.kaget_aktif() then return false; end if;
  insert into public.dana_kaget_hadiah (game_id, user_id) values (p_game, p_user);
  perform public.isi_hadiah_tertunda();
  return true;
end;
$$;

-- 7) Sinkronkan pemegang peringkat 1 dengan papan peringkat.
--    Peringkat 1 = skor tertinggi (seri dimenangkan yang lebih dulu mencapainya). Hitungan mulai ulang
--    hanya jika orang LAIN merebut puncak. Jika pemegang lama sudah bertahan cukup lama sebelum tergeser,
--    ia tetap mendapat hadiahnya (kecuali skornya dihapus admin).
create or replace function public.sinkron_juara(p_game text)
returns void language plpgsql security definer set search_path = public as $$
declare top_user uuid; cur public.juara_game%rowtype;
begin
  perform pg_advisory_xact_lock(7001);
  select user_id into top_user from public.game_scores
    where game_id = p_game and skor > 0 order by skor desc, best_at asc limit 1;
  select * into cur from public.juara_game where game_id = p_game;

  if top_user is null then
    delete from public.juara_game where game_id = p_game;
    return;
  end if;

  if cur.game_id is null then
    insert into public.juara_game (game_id, user_id) values (p_game, top_user);
  elsif cur.user_id <> top_user then
    if not cur.hadiah_diberikan
       and now() - cur.sejak >= make_interval(hours => public.jam_kaget())
       and exists (select 1 from public.game_scores where game_id = p_game and user_id = cur.user_id and skor > 0) then
      perform public.beri_hadiah(p_game, cur.user_id);
    end if;
    update public.juara_game set user_id = top_user, sejak = now(), hadiah_diberikan = false where game_id = p_game;
  end if;
end;
$$;

-- 8) Periksa semua game: beri hadiah ke pemegang puncak yang sudah cukup lama bertahan.
--    Dipanggil otomatis oleh web (saat pengguna login / membuka web) dan oleh panel admin.
create or replace function public.proses_dana_kaget()
returns void language plpgsql security definer set search_path = public as $$
declare g record; j public.juara_game%rowtype;
begin
  if auth.uid() is null then return; end if;
  perform pg_advisory_xact_lock(7001);
  for g in select distinct game_id from public.game_scores loop
    if exists (select 1 from public.games where id = g.game_id and status = 'archived') then continue; end if;
    perform public.sinkron_juara(g.game_id);
    select * into j from public.juara_game where game_id = g.game_id;
    if j.game_id is not null and not j.hadiah_diberikan
       and now() - j.sejak >= make_interval(hours => public.jam_kaget()) then
      if public.beri_hadiah(g.game_id, j.user_id) then
        update public.juara_game set hadiah_diberikan = true where game_id = g.game_id;
      end if;
    end if;
  end loop;
  perform public.isi_hadiah_tertunda();
end;
$$;

-- 9) Hadiah milik pemain yang login dan belum dibuka (berisi link-nya)
create or replace function public.hadiah_saya()
returns table (id bigint, game_id text, url text, menang_at timestamptz)
language sql stable security definer set search_path = public as $$
  select h.id, h.game_id, k.url, h.menang_at
  from public.dana_kaget_hadiah h
  join public.dana_kaget_link k on k.id = h.link_id
  where h.user_id = auth.uid() and h.dilihat_at is null
  order by h.id;
$$;

create or replace function public.tandai_hadiah_dilihat(p_id bigint)
returns void language sql security definer set search_path = public as $$
  update public.dana_kaget_hadiah set dilihat_at = now()
  where id = p_id and user_id = auth.uid() and dilihat_at is null;
$$;

-- 10) kirim_skor: sama seperti sebelumnya, ditambah sinkron pemegang peringkat 1 setiap skor masuk
create or replace function public.kirim_skor(p_game text, p_skor int, p_level int)
returns int
language plpgsql
security definer
set search_path = public
as $$
declare
  terbaik int;
begin
  if auth.uid() is null then
    raise exception 'Harus login';
  end if;
  if p_skor is null or p_skor < 0 or p_skor > 1000000 then
    raise exception 'Skor tidak valid';
  end if;
  if exists (select 1 from public.games where id = p_game and status = 'archived') then
    raise exception 'Game sudah diarsipkan';
  end if;

  insert into public.game_scores as t (game_id, user_id, skor, level, plays)
  values (p_game, auth.uid(), p_skor, greatest(coalesce(p_level, 1), 1), 1)
  on conflict (game_id, user_id) do update set
    plays = t.plays + 1,
    last_played = now(),
    skor = greatest(t.skor, excluded.skor),
    level = case when excluded.skor > t.skor then excluded.level else t.level end,
    best_at = case when excluded.skor > t.skor then now() else t.best_at end;

  perform public.sinkron_juara(p_game);

  select skor into terbaik from public.game_scores where game_id = p_game and user_id = auth.uid();
  return terbaik;
end;
$$;

-- 11) Izin eksekusi. Fungsi internal TIDAK boleh dipanggil langsung oleh pengguna.
revoke all on function public.jam_kaget() from public, anon, authenticated;
revoke all on function public.kaget_aktif() from public, anon, authenticated;
revoke all on function public.isi_hadiah_tertunda() from public, anon, authenticated;
revoke all on function public.beri_hadiah(text, uuid) from public, anon, authenticated;
revoke all on function public.sinkron_juara(text) from public, anon, authenticated;

revoke all on function public.proses_dana_kaget() from public, anon;
grant execute on function public.proses_dana_kaget() to authenticated;
revoke all on function public.hadiah_saya() from public, anon;
grant execute on function public.hadiah_saya() to authenticated;
revoke all on function public.tandai_hadiah_dilihat(bigint) from public, anon;
grant execute on function public.tandai_hadiah_dilihat(bigint) to authenticated;
revoke all on function public.kirim_skor(text, int, int) from public, anon;
grant execute on function public.kirim_skor(text, int, int) to authenticated;


-- ################ telsaone-level.sql ################
-- Jalankan sekali di Supabase > SQL Editor SETELAH telsaone-hadiah.sql. Aman dijalankan ulang.
-- Menambah: (1) Dana Kaget per level yang diselesaikan, (2) reset skor juara otomatis / manual dari panel admin.
-- Link tetap diunggah lewat Admin > HADIAH (satu stok bersama dengan hadiah juara).

-- 1) Jenis hadiah: 'juara' (peringkat 1 bertahan) atau 'level' (menyelesaikan level)
alter table public.dana_kaget_hadiah add column if not exists jenis text not null default 'juara';
alter table public.dana_kaget_hadiah add column if not exists level int;
create unique index if not exists dana_kaget_level_unik on public.dana_kaget_hadiah (user_id, game_id, level) where jenis = 'level';

-- 2) Level yang sudah diselesaikan tiap pemain (rahasia: hanya admin yang bisa membaca)
create table if not exists public.level_selesai (
  game_id text not null,
  user_id uuid not null references public.profiles(id) on delete cascade,
  level int not null check (level between 1 and 500),
  selesai_at timestamptz not null default now(),
  primary key (game_id, user_id, level)
);
alter table public.level_selesai enable row level security;
drop policy if exists "level admin baca" on public.level_selesai;
create policy "level admin baca" on public.level_selesai for select to authenticated using (public.is_admin());

-- 3) Pengaturan dari site_content, kunci 'dana_kaget'
create or replace function public.level_aktif()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select value->>'level_aktif' from public.site_content where key = 'dana_kaget'), 'true') <> 'false';
$$;
create or replace function public.level_maks()
returns int language sql stable security definer set search_path = public as $$
  select coalesce((select case when value->>'level_maks' ~ '^[0-9]{1,3}$' then (value->>'level_maks')::int end
    from public.site_content where key = 'dana_kaget'), 10);
$$;
create or replace function public.reset_juara_aktif()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select value->>'reset_juara' from public.site_content where key = 'dana_kaget'), 'true') <> 'false';
$$;

-- 4) Pemain melapor level selesai. Harus berurutan (level 1, 2, 3, ...) dan minimal 12 detik sejak level sebelumnya.
create or replace function public.selesai_level(p_game text, p_level int)
returns void language plpgsql security definer set search_path = public as $$
declare baru int;
begin
  if auth.uid() is null then return; end if;
  if p_level is null or p_level < 1 or p_level > 500 then return; end if;
  if exists (select 1 from public.games where id = p_game and status = 'archived') then return; end if;
  if p_level > 1 and not exists (select 1 from public.level_selesai where game_id = p_game and user_id = auth.uid() and level = p_level - 1)
     and coalesce((select gs.level from public.game_scores gs where gs.game_id = p_game and gs.user_id = auth.uid()), 1) < p_level then return; end if;
  if exists (select 1 from public.level_selesai where game_id = p_game and user_id = auth.uid() and selesai_at > now() - interval '12 seconds') then return; end if;

  insert into public.level_selesai (game_id, user_id, level) values (p_game, auth.uid(), p_level) on conflict do nothing;
  get diagnostics baru = row_count;
  if baru = 0 or not public.level_aktif() or not public.kaget_aktif() or p_level > public.level_maks() then return; end if;

  insert into public.dana_kaget_hadiah (game_id, user_id, jenis, level) values (p_game, auth.uid(), 'level', p_level) on conflict do nothing;
  perform public.isi_hadiah_tertunda();
end;
$$;

-- 4b) Level tempat pemain melanjutkan: level terjauh yang pernah dicapai (selesai + 1, atau level di skor terbaiknya)
create or replace function public.level_saya(p_game text)
returns int language sql stable security definer set search_path = public as $$
  select greatest(
    coalesce((select max(level) + 1 from public.level_selesai where game_id = p_game and user_id = auth.uid()), 1),
    coalesce((select level from public.game_scores where game_id = p_game and user_id = auth.uid()), 1));
$$;
revoke all on function public.level_saya(text) from public, anon;
grant execute on function public.level_saya(text) to authenticated;

-- 5) hadiah_saya sekarang menyertakan jenis & level
drop function if exists public.hadiah_saya();
create function public.hadiah_saya()
returns table (id bigint, game_id text, url text, menang_at timestamptz, jenis text, level int)
language sql stable security definer set search_path = public as $$
  select h.id, h.game_id, k.url, h.menang_at, h.jenis, h.level
  from public.dana_kaget_hadiah h
  join public.dana_kaget_link k on k.id = h.link_id
  where h.user_id = auth.uid() and h.dilihat_at is null
  order by h.id;
$$;

-- 6) Setelah juara menerima hadiah, skornya direset ke 0 (jika pengaturan "reset otomatis" aktif).
--    Ronde baru dimulai: peringkat 1 berikutnya mulai menghitung jam dari nol.
create or replace function public.proses_dana_kaget()
returns void language plpgsql security definer set search_path = public as $$
declare g record; j public.juara_game%rowtype;
begin
  if auth.uid() is null then return; end if;
  perform pg_advisory_xact_lock(7001);
  for g in select distinct game_id from public.game_scores loop
    if exists (select 1 from public.games where id = g.game_id and status = 'archived') then continue; end if;
    perform public.sinkron_juara(g.game_id);
    select * into j from public.juara_game where game_id = g.game_id;
    if j.game_id is not null and not j.hadiah_diberikan
       and now() - j.sejak >= make_interval(hours => public.jam_kaget()) then
      if public.beri_hadiah(g.game_id, j.user_id) then
        update public.juara_game set hadiah_diberikan = true where game_id = g.game_id;
        if public.reset_juara_aktif() then
          update public.game_scores set skor = 0, level = 1 where game_id = g.game_id and user_id = j.user_id;
          delete from public.juara_game where game_id = g.game_id;
          perform public.sinkron_juara(g.game_id);
        end if;
      end if;
    end if;
  end loop;
  perform public.isi_hadiah_tertunda();
end;
$$;

-- 7) Reset manual oleh admin: 'juara' = skor pemegang peringkat 1 jadi 0, 'semua' = hapus semua skor game itu
create or replace function public.reset_skor_game(p_game text, p_mode text)
returns void language plpgsql security definer set search_path = public as $$
declare u uuid;
begin
  if not public.is_admin() then raise exception 'Hanya admin'; end if;
  perform pg_advisory_xact_lock(7001);
  if p_mode = 'semua' then
    delete from public.game_scores where game_id = p_game;
  else
    select user_id into u from public.juara_game where game_id = p_game;
    if u is not null then update public.game_scores set skor = 0, level = 1 where game_id = p_game and user_id = u; end if;
  end if;
  delete from public.juara_game where game_id = p_game;
  perform public.sinkron_juara(p_game);
end;
$$;

revoke all on function public.level_aktif() from public, anon, authenticated;
revoke all on function public.level_maks() from public, anon, authenticated;
revoke all on function public.reset_juara_aktif() from public, anon, authenticated;
revoke all on function public.selesai_level(text, int) from public, anon;
grant execute on function public.selesai_level(text, int) to authenticated;
revoke all on function public.hadiah_saya() from public, anon;
grant execute on function public.hadiah_saya() to authenticated;
revoke all on function public.proses_dana_kaget() from public, anon;
grant execute on function public.proses_dana_kaget() to authenticated;
revoke all on function public.reset_skor_game(text, text) from public, anon;
grant execute on function public.reset_skor_game(text, text) to authenticated;

-- Muat ulang cache skema API Supabase agar fungsi baru langsung dikenali
notify pgrst, 'reload schema';


-- ################ telsaone-like.sql ################
-- Suka untuk website: satu akun hanya bisa satu suka (kunci utama = user_id).
-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-chat.sql). Aman dijalankan ulang.
create table if not exists public.site_likes (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.site_likes enable row level security;
-- Tidak ada akses langsung ke tabel; semua lewat dua fungsi di bawah.

-- Jumlah suka dan apakah akun ini sudah menyukai (boleh dipanggil siapa saja)
create or replace function public.info_suka()
returns table (jumlah int, sudah boolean) language sql stable security definer set search_path = public as $$
  select (select count(*)::int from public.site_likes),
         coalesce((select true from public.site_likes where user_id = auth.uid()), false);
$$;

-- Memberi suka: hanya akun yang login, dan hanya sekali (pemberian kedua tidak menambah hitungan)
create or replace function public.suka_situs()
returns int language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Masuk dulu untuk memberi suka.'; end if;
  insert into public.site_likes (user_id) values (auth.uid()) on conflict do nothing;
  return (select count(*)::int from public.site_likes);
end;
$$;

revoke all on function public.info_suka() from public;
revoke all on function public.suka_situs() from public, anon;
grant execute on function public.info_suka() to anon, authenticated;
grant execute on function public.suka_situs() to authenticated;
notify pgrst, 'reload schema';


-- ################ telsaone-story.sql ################
-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-chat.sql dan telsaone-admin.sql). Aman dijalankan ulang.
-- Story pengguna: foto/video, tampil publik selama 24 jam, lalu hilang otomatis.

-- 1) Bucket file story (publik dibaca; tiap pengguna hanya boleh unggah ke folder miliknya)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('stories', 'stories', true, 31457280,
  array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime'])
on conflict (id) do update set file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

-- 2) Tabel story
create table if not exists public.stories (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  media_path text not null,
  media_url text not null,
  media_type text not null check (media_type in ('image', 'video')),
  caption text not null default '' check (char_length(caption) <= 140),
  created_at timestamptz not null default now()
);
create index if not exists stories_created_idx on public.stories (created_at desc);
alter table public.stories enable row level security;

-- Publik hanya melihat story yang umurnya < 24 jam (pemilik dan admin tetap bisa melihat sisa yang kedaluwarsa untuk dibersihkan)
drop policy if exists "story dibaca publik 24 jam" on public.stories;
create policy "story dibaca publik 24 jam" on public.stories for select
  using (created_at > now() - interval '24 hours' or user_id = auth.uid() or public.is_admin());
drop policy if exists "story unggah sendiri" on public.stories;
create policy "story unggah sendiri" on public.stories for insert to authenticated
  with check (user_id = auth.uid() and split_part(media_path, '/', 1) = auth.uid()::text);
drop policy if exists "story hapus sendiri atau admin" on public.stories;
create policy "story hapus sendiri atau admin" on public.stories for delete to authenticated
  using (user_id = auth.uid() or public.is_admin());

-- Tidak ada batas jumlah story (hanya ukuran file yang dibatasi)
create or replace function public.batas_story()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  return new; -- tanpa batas jumlah story
end;
$$;
drop trigger if exists batas_story on public.stories;
create trigger batas_story before insert on public.stories for each row execute function public.batas_story();

-- 3) Pembersihan otomatis: siapa pun yang membuka situs ikut membersihkan story yang sudah > 24 jam
create or replace function public.story_kedaluwarsa(p_path text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.stories where media_path = p_path and created_at < now() - interval '24 hours');
$$;
create or replace function public.daftar_story_kedaluwarsa()
returns table (id bigint, media_path text) language sql stable security definer set search_path = public as $$
  select s.id, s.media_path from public.stories s where s.created_at < now() - interval '24 hours' order by s.created_at limit 30;
$$;
create or replace function public.hapus_story_kedaluwarsa(p_ids bigint[])
returns void language sql security definer set search_path = public as $$
  delete from public.stories where id = any(p_ids) and created_at < now() - interval '24 hours';
$$;
grant execute on function public.story_kedaluwarsa(text) to anon, authenticated;
grant execute on function public.daftar_story_kedaluwarsa() to anon, authenticated;
grant execute on function public.hapus_story_kedaluwarsa(bigint[]) to anon, authenticated;

-- 4) Aturan file di storage
drop policy if exists "story file dibaca semua" on storage.objects;
create policy "story file dibaca semua" on storage.objects for select using (bucket_id = 'stories');
drop policy if exists "story file unggah sendiri" on storage.objects;
create policy "story file unggah sendiri" on storage.objects for insert to authenticated
  with check (bucket_id = 'stories' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "story file hapus" on storage.objects;
create policy "story file hapus" on storage.objects for delete to anon, authenticated
  using (bucket_id = 'stories' and (
    (storage.foldername(name))[1] = auth.uid()::text
    or public.is_admin()
    or public.story_kedaluwarsa(name)));

notify pgrst, 'reload schema';


-- ################ telsaone-story-durasi.sql ################
-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-story.sql). Aman dijalankan ulang.
-- Durasi story bisa diatur admin: 1 jam ... 7 hari, atau PERMANEN (tidak pernah dihapus).
-- Pengguna biasa tetap 24 jam.

-- 1) Kolom durasi. expires_at = kapan hilang; permanen = true berarti tidak pernah hilang (expires_at kosong).
alter table public.stories add column if not exists expires_at timestamptz;
alter table public.stories add column if not exists permanen boolean not null default false;
update public.stories set expires_at = created_at + interval '24 hours' where expires_at is null and not permanen;
create index if not exists stories_expires_idx on public.stories (expires_at);

-- 2) Saat story dibuat: pengguna biasa dipaksa 24 jam; hanya admin yang boleh memilih durasi/permanen
create or replace function public.story_atur_durasi()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then
    new.permanen := false;
    new.expires_at := now() + interval '24 hours';
  elsif new.permanen then
    new.expires_at := null;
  else
    new.expires_at := least(greatest(coalesce(new.expires_at, now() + interval '24 hours'), now() + interval '1 minute'), now() + interval '365 days');
  end if;
  return new;
end;
$$;
drop trigger if exists story_atur_durasi on public.stories;
create trigger story_atur_durasi before insert on public.stories for each row execute function public.story_atur_durasi();

-- 3) Ubah durasi story yang sudah terbit (khusus admin). p_permanen = true -> permanen; selain itu p_jam jam dari SEKARANG.
create or replace function public.atur_durasi_story(p_id bigint, p_jam int, p_permanen boolean default false)
returns timestamptz language plpgsql security definer set search_path = public as $$
declare hasil timestamptz;
begin
  if not public.is_admin() then raise exception 'Hanya admin yang boleh mengatur durasi story.'; end if;
  if p_permanen then
    update public.stories set permanen = true, expires_at = null, hapus_req = null, hapus_at = null where id = p_id;
    return null;
  end if;
  if p_jam is null or p_jam < 1 or p_jam > 8760 then raise exception 'Durasi tidak valid.'; end if;
  hasil := now() + make_interval(hours => p_jam);
  update public.stories set permanen = false, expires_at = hasil, hapus_req = null, hapus_at = null where id = p_id;
  return hasil;
exception when undefined_column then
  -- kolom hapus_req/hapus_at belum ada (telsaone-story-cron.sql belum dijalankan)
  if p_permanen then
    update public.stories set permanen = true, expires_at = null where id = p_id;
    return null;
  end if;
  hasil := now() + make_interval(hours => p_jam);
  update public.stories set permanen = false, expires_at = hasil where id = p_id;
  return hasil;
end;
$$;
revoke all on function public.atur_durasi_story(bigint, int, boolean) from public, anon;
grant execute on function public.atur_durasi_story(bigint, int, boolean) to authenticated;

-- 4) Terapkan durasi ke semua aturan lama (baca publik, batas, pembersihan)
drop policy if exists "story dibaca publik 24 jam" on public.stories;
drop policy if exists "story dibaca publik" on public.stories;
create policy "story dibaca publik" on public.stories for select
  using (permanen or expires_at > now() or user_id = auth.uid() or public.is_admin());

-- Tidak ada batas jumlah story (hanya ukuran file yang dibatasi)
create or replace function public.batas_story()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  return new; -- tanpa batas jumlah story
end;
$$;

create or replace function public.story_kedaluwarsa(p_path text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.stories where media_path = p_path and not permanen and expires_at < now());
$$;
create or replace function public.daftar_story_kedaluwarsa()
returns table (id bigint, media_path text) language sql stable security definer set search_path = public as $$
  select s.id, s.media_path from public.stories s where not s.permanen and s.expires_at < now() order by s.expires_at limit 30;
$$;
create or replace function public.hapus_story_kedaluwarsa(p_ids bigint[])
returns void language sql security definer set search_path = public as $$
  delete from public.stories where id = any(p_ids) and not permanen and expires_at < now();
$$;

notify pgrst, 'reload schema';


-- ################ telsaone-password-email.sql ################
-- OPSIONAL tapi disarankan. Jalankan sekali di Supabase > SQL Editor. Aman dijalankan ulang.
-- Password hanya boleh dibuat/diganti untuk akun yang punya login email.
-- Akun yang hanya masuk lewat Google/GitHub tidak bisa diberi password (reset/ganti ditolak server).
create or replace function public.blok_password_non_email()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.encrypted_password is distinct from old.encrypted_password
     and coalesce(new.encrypted_password, '') <> ''
     and not exists (select 1 from auth.identities i where i.user_id = new.id and i.provider = 'email') then
    raise exception 'Akun ini masuk lewat Google/GitHub dan tidak memakai password.';
  end if;
  return new;
end;
$$;

drop trigger if exists blok_password_non_email on auth.users;
create trigger blok_password_non_email
  before update of encrypted_password on auth.users
  for each row execute function public.blok_password_non_email();


-- ============================================================
-- Juara 1 ditahan di papan N jam setelah menerima hadiah (telsaone-juara-tahan.sql)
-- ============================================================
-- Jalankan sekali di Supabase > SQL Editor SETELAH telsaone-level.sql. Aman dijalankan ulang.
-- Juara 1 TIDAK langsung hilang dari papan peringkat setelah menerima hadiah: skornya ditahan N jam
-- (bawaan 24) baru direset ke 0. Lama penahanan diatur admin di Admin > HADIAH ("Tahan juara di papan (jam)").
-- 0 = langsung direset seperti sebelumnya. Jika di masa tahan puncak direbut orang lain, juara lama tidak direset.

-- 1) Kapan skor juara boleh direset (diisi saat hadiah diberikan)
alter table public.juara_game add column if not exists reset_at timestamptz;

-- 2) Pengaturan dari site_content, kunci 'dana_kaget' (0 sampai 720 jam)
create or replace function public.tahan_jam()
returns int language sql stable security definer set search_path = public as $$
  select coalesce(
    (select case when value->>'tahan_jam' ~ '^[0-9]{1,3}$' then least((value->>'tahan_jam')::int, 720) end
       from public.site_content where key = 'dana_kaget'),
    24);
$$;
create or replace function public.tahan_permanen()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select value->>'tahan_permanen' from public.site_content where key = 'dana_kaget'), 'false') = 'true';
$$;
revoke all on function public.tahan_jam() from public, anon, authenticated;
revoke all on function public.tahan_permanen() from public, anon, authenticated;

-- 3) sinkron_juara: sama seperti sebelumnya, tetapi ganti juara = hitungan tahan dibatalkan (reset_at kosong)
create or replace function public.sinkron_juara(p_game text)
returns void language plpgsql security definer set search_path = public as $$
declare top_user uuid; cur public.juara_game%rowtype;
begin
  perform pg_advisory_xact_lock(7001);
  select user_id into top_user from public.game_scores
    where game_id = p_game and skor > 0 order by skor desc, best_at asc limit 1;
  select * into cur from public.juara_game where game_id = p_game;

  if top_user is null then
    delete from public.juara_game where game_id = p_game;
    return;
  end if;

  if cur.game_id is null then
    insert into public.juara_game (game_id, user_id) values (p_game, top_user);
  elsif cur.user_id <> top_user then
    if not cur.hadiah_diberikan
       and now() - cur.sejak >= make_interval(hours => public.jam_kaget())
       and exists (select 1 from public.game_scores where game_id = p_game and user_id = cur.user_id and skor > 0) then
      perform public.beri_hadiah(p_game, cur.user_id);
    end if;
    update public.juara_game set user_id = top_user, sejak = now(), hadiah_diberikan = false, reset_at = null where game_id = p_game;
  end if;
end;
$$;
revoke all on function public.sinkron_juara(text) from public, anon, authenticated;

-- 4) proses_dana_kaget: hadiah diberikan -> juara tetap di papan sampai reset_at, baru skornya jadi 0
create or replace function public.proses_dana_kaget()
returns void language plpgsql security definer set search_path = public as $$
declare g record; j public.juara_game%rowtype;
begin
  if auth.uid() is null then return; end if;
  perform pg_advisory_xact_lock(7001);
  for g in select distinct game_id from public.game_scores loop
    if exists (select 1 from public.games where id = g.game_id and status = 'archived') then continue; end if;
    perform public.sinkron_juara(g.game_id);
    select * into j from public.juara_game where game_id = g.game_id;

    if j.game_id is not null and not j.hadiah_diberikan
       and now() - j.sejak >= make_interval(hours => public.jam_kaget()) then
      if public.beri_hadiah(g.game_id, j.user_id) then
        update public.juara_game
          set hadiah_diberikan = true, reset_at = now() + make_interval(hours => public.tahan_jam())
          where game_id = g.game_id;
        select * into j from public.juara_game where game_id = g.game_id;
      end if;
    end if;

    -- Masa tahan selesai: baru skor juara direset (jika "reset otomatis" aktif dan tidak permanen)
    if j.game_id is not null and j.hadiah_diberikan and j.reset_at is not null and now() >= j.reset_at
       and public.reset_juara_aktif() and not public.tahan_permanen() then
      update public.game_scores set skor = 0, level = 1 where game_id = g.game_id and user_id = j.user_id;
      delete from public.juara_game where game_id = g.game_id;
      perform public.sinkron_juara(g.game_id);
    end if;
  end loop;
  perform public.isi_hadiah_tertunda();
end;
$$;
revoke all on function public.proses_dana_kaget() from public, anon;
grant execute on function public.proses_dana_kaget() to authenticated;

notify pgrst, 'reload schema';
