-- Jalankan sekali di Supabase > SQL Editor SETELAH telsaone-level.sql. Aman dijalankan ulang.
-- Juara 1 TIDAK langsung hilang dari papan peringkat setelah menerima hadiah: skornya ditahan N jam
-- (bawaan 24) baru direset ke 0. Lama penahanan diatur admin di Admin > HADIAH ("Tahan juara di papan (jam)").
-- 0 = langsung direset seperti sebelumnya. Opsi "permanen" (tahan_permanen) = juara tidak pernah direset otomatis. Jika di masa tahan puncak direbut orang lain, juara lama tidak direset.

-- 1) Kapan skor juara boleh direset (diisi saat hadiah diberikan)
alter table public.juara_game add column if not exists reset_at timestamptz;

-- 2) Pengaturan dari site_content, kunci 'dana_kaget' (0 sampai 720 jam)
create or replace function public.tahan_jam()
returns int language sql stable security definer set search_path = public as $$
  select coalesce(
    (select case when value->>'tahan_jam' ~ '^[0-9]{1,3}$' then least((value->>'tahan_jam')::int, 720) end
       from public.site_content where key = 'dana_kaget'),
    24);
$$;
create or replace function public.tahan_permanen()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select value->>'tahan_permanen' from public.site_content where key = 'dana_kaget'), 'false') = 'true';
$$;
revoke all on function public.tahan_jam() from public, anon, authenticated;
revoke all on function public.tahan_permanen() from public, anon, authenticated;

-- 3) sinkron_juara: sama seperti sebelumnya, tetapi ganti juara = hitungan tahan dibatalkan (reset_at kosong)
create or replace function public.sinkron_juara(p_game text)
returns void language plpgsql security definer set search_path = public as $$
declare top_user uuid; cur public.juara_game%rowtype;
begin
  perform pg_advisory_xact_lock(7001);
  select user_id into top_user from public.game_scores
    where game_id = p_game and skor > 0 order by skor desc, best_at asc limit 1;
  select * into cur from public.juara_game where game_id = p_game;

  if top_user is null then
    delete from public.juara_game where game_id = p_game;
    return;
  end if;

  if cur.game_id is null then
    insert into public.juara_game (game_id, user_id) values (p_game, top_user);
  elsif cur.user_id <> top_user then
    if not cur.hadiah_diberikan
       and now() - cur.sejak >= make_interval(hours => public.jam_kaget())
       and exists (select 1 from public.game_scores where game_id = p_game and user_id = cur.user_id and skor > 0) then
      perform public.beri_hadiah(p_game, cur.user_id);
    end if;
    update public.juara_game set user_id = top_user, sejak = now(), hadiah_diberikan = false, reset_at = null where game_id = p_game;
  end if;
end;
$$;
revoke all on function public.sinkron_juara(text) from public, anon, authenticated;

-- 4) proses_dana_kaget: hadiah diberikan -> juara tetap di papan sampai reset_at, baru skornya jadi 0
create or replace function public.proses_dana_kaget()
returns void language plpgsql security definer set search_path = public as $$
declare g record; j public.juara_game%rowtype;
begin
  if auth.uid() is null then return; end if;
  perform pg_advisory_xact_lock(7001);
  for g in select distinct game_id from public.game_scores loop
    if exists (select 1 from public.games where id = g.game_id and status = 'archived') then continue; end if;
    perform public.sinkron_juara(g.game_id);
    select * into j from public.juara_game where game_id = g.game_id;

    if j.game_id is not null and not j.hadiah_diberikan
       and now() - j.sejak >= make_interval(hours => public.jam_kaget()) then
      if public.beri_hadiah(g.game_id, j.user_id) then
        update public.juara_game
          set hadiah_diberikan = true, reset_at = now() + make_interval(hours => public.tahan_jam())
          where game_id = g.game_id;
        select * into j from public.juara_game where game_id = g.game_id;
      end if;
    end if;

    -- Masa tahan selesai: baru skor juara direset (jika "reset otomatis" aktif dan tidak permanen)
    if j.game_id is not null and j.hadiah_diberikan and j.reset_at is not null and now() >= j.reset_at
       and public.reset_juara_aktif() and not public.tahan_permanen() then
      update public.game_scores set skor = 0, level = 1 where game_id = g.game_id and user_id = j.user_id;
      delete from public.juara_game where game_id = g.game_id;
      perform public.sinkron_juara(g.game_id);
    end if;
  end loop;
  perform public.isi_hadiah_tertunda();
end;
$$;
revoke all on function public.proses_dana_kaget() from public, anon;
grant execute on function public.proses_dana_kaget() to authenticated;

notify pgrst, 'reload schema';
