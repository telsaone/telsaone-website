-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-chat.sql, telsaone-admin.sql, dan telsaone-game.sql).
-- Hadiah Dana Kaget: pemain peringkat 1 yang TIDAK TERGESER selama N jam (bawaan 24) mendapat satu link Dana Kaget.
-- Link diunggah admin lewat panel Admin > HADIAH. Link bersifat rahasia: tabelnya hanya bisa dibaca admin,
-- pemenang menerimanya lewat fungsi hadiah_saya() (hanya link miliknya sendiri).
-- Aman dijalankan ulang.

-- 1) Siapa yang memegang peringkat 1 dan sejak kapan (publik, tidak berisi rahasia)
create table if not exists public.juara_game (
  game_id text primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  sejak timestamptz not null default now(),
  hadiah_diberikan boolean not null default false
);
alter table public.juara_game enable row level security;
drop policy if exists "juara dibaca semua" on public.juara_game;
create policy "juara dibaca semua" on public.juara_game for select using (true);
-- Tidak ada policy tulis: hanya fungsi di bawah yang mengubahnya.

-- 2) Stok link Dana Kaget (RAHASIA: hanya admin)
create table if not exists public.dana_kaget_link (
  id bigint generated always as identity primary key,
  url text not null unique check (url ~ '^https://[^[:space:]]+$' and length(url) <= 500),
  dibuat timestamptz not null default now()
);
alter table public.dana_kaget_link enable row level security;
drop policy if exists "link admin baca" on public.dana_kaget_link;
create policy "link admin baca" on public.dana_kaget_link for select to authenticated using (public.is_admin());
drop policy if exists "link admin tambah" on public.dana_kaget_link;
create policy "link admin tambah" on public.dana_kaget_link for insert to authenticated with check (public.is_admin());
drop policy if exists "link admin hapus" on public.dana_kaget_link;
create policy "link admin hapus" on public.dana_kaget_link for delete to authenticated using (public.is_admin());

-- 3) Catatan pemenang. link_id kosong = menang tapi stok link habis (diisi otomatis saat admin menambah link)
create table if not exists public.dana_kaget_hadiah (
  id bigint generated always as identity primary key,
  game_id text not null,
  user_id uuid not null references public.profiles(id) on delete cascade,
  link_id bigint unique references public.dana_kaget_link(id) on delete restrict,
  menang_at timestamptz not null default now(),
  dilihat_at timestamptz
);
alter table public.dana_kaget_hadiah enable row level security;
drop policy if exists "hadiah admin baca" on public.dana_kaget_hadiah;
create policy "hadiah admin baca" on public.dana_kaget_hadiah for select to authenticated using (public.is_admin());
-- Pemain membaca hadiahnya lewat fungsi hadiah_saya(), bukan langsung dari tabel.

-- 4) Pengaturan (dibaca dari site_content, kunci 'dana_kaget', diubah admin di panel)
create or replace function public.jam_kaget()
returns int language sql stable security definer set search_path = public as $$
  select coalesce(
    (select case when value->>'jam' ~ '^[0-9]{1,4}$' then least(greatest((value->>'jam')::int, 1), 720) end
       from public.site_content where key = 'dana_kaget'),
    24);
$$;

create or replace function public.kaget_aktif()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select value->>'aktif' from public.site_content where key = 'dana_kaget'), 'true') <> 'false';
$$;

-- 5) Isi hadiah yang menunggu link dengan stok link yang masih bebas (urut paling lama)
create or replace function public.isi_hadiah_tertunda()
returns void language plpgsql security definer set search_path = public as $$
declare h record; l bigint;
begin
  perform pg_advisory_xact_lock(7001);
  for h in select id from public.dana_kaget_hadiah where link_id is null order by id loop
    l := null;
    select k.id into l from public.dana_kaget_link k
      where not exists (select 1 from public.dana_kaget_hadiah x where x.link_id = k.id)
      order by k.id limit 1;
    exit when l is null;
    update public.dana_kaget_hadiah set link_id = l where id = h.id;
  end loop;
end;
$$;

-- 6) Catat pemenang (dan langsung pasangkan link jika stok ada)
create or replace function public.beri_hadiah(p_game text, p_user uuid)
returns boolean language plpgsql security definer set search_path = public as $$
begin
  if not public.kaget_aktif() then return false; end if;
  insert into public.dana_kaget_hadiah (game_id, user_id) values (p_game, p_user);
  perform public.isi_hadiah_tertunda();
  return true;
end;
$$;

-- 7) Sinkronkan pemegang peringkat 1 dengan papan peringkat.
--    Peringkat 1 = skor tertinggi (seri dimenangkan yang lebih dulu mencapainya). Hitungan mulai ulang
--    hanya jika orang LAIN merebut puncak. Jika pemegang lama sudah bertahan cukup lama sebelum tergeser,
--    ia tetap mendapat hadiahnya (kecuali skornya dihapus admin).
create or replace function public.sinkron_juara(p_game text)
returns void language plpgsql security definer set search_path = public as $$
declare top_user uuid; cur public.juara_game%rowtype;
begin
  perform pg_advisory_xact_lock(7001);
  select user_id into top_user from public.game_scores
    where game_id = p_game and skor > 0 order by skor desc, best_at asc limit 1;
  select * into cur from public.juara_game where game_id = p_game;

  if top_user is null then
    delete from public.juara_game where game_id = p_game;
    return;
  end if;

  if cur.game_id is null then
    insert into public.juara_game (game_id, user_id) values (p_game, top_user);
  elsif cur.user_id <> top_user then
    if not cur.hadiah_diberikan
       and now() - cur.sejak >= make_interval(hours => public.jam_kaget())
       and exists (select 1 from public.game_scores where game_id = p_game and user_id = cur.user_id and skor > 0) then
      perform public.beri_hadiah(p_game, cur.user_id);
    end if;
    update public.juara_game set user_id = top_user, sejak = now(), hadiah_diberikan = false where game_id = p_game;
  end if;
end;
$$;

-- 8) Periksa semua game: beri hadiah ke pemegang puncak yang sudah cukup lama bertahan.
--    Dipanggil otomatis oleh web (saat pengguna login / membuka web) dan oleh panel admin.
create or replace function public.proses_dana_kaget()
returns void language plpgsql security definer set search_path = public as $$
declare g record; j public.juara_game%rowtype;
begin
  if auth.uid() is null then return; end if;
  perform pg_advisory_xact_lock(7001);
  for g in select distinct game_id from public.game_scores loop
    if exists (select 1 from public.games where id = g.game_id and status = 'archived') then continue; end if;
    perform public.sinkron_juara(g.game_id);
    select * into j from public.juara_game where game_id = g.game_id;
    if j.game_id is not null and not j.hadiah_diberikan
       and now() - j.sejak >= make_interval(hours => public.jam_kaget()) then
      if public.beri_hadiah(g.game_id, j.user_id) then
        update public.juara_game set hadiah_diberikan = true where game_id = g.game_id;
      end if;
    end if;
  end loop;
  perform public.isi_hadiah_tertunda();
end;
$$;

-- 9) Hadiah milik pemain yang login dan belum dibuka (berisi link-nya)
create or replace function public.hadiah_saya()
returns table (id bigint, game_id text, url text, menang_at timestamptz)
language sql stable security definer set search_path = public as $$
  select h.id, h.game_id, k.url, h.menang_at
  from public.dana_kaget_hadiah h
  join public.dana_kaget_link k on k.id = h.link_id
  where h.user_id = auth.uid() and h.dilihat_at is null
  order by h.id;
$$;

create or replace function public.tandai_hadiah_dilihat(p_id bigint)
returns void language sql security definer set search_path = public as $$
  update public.dana_kaget_hadiah set dilihat_at = now()
  where id = p_id and user_id = auth.uid() and dilihat_at is null;
$$;

-- 10) kirim_skor: sama seperti sebelumnya, ditambah sinkron pemegang peringkat 1 setiap skor masuk
create or replace function public.kirim_skor(p_game text, p_skor int, p_level int)
returns int
language plpgsql
security definer
set search_path = public
as $$
declare
  terbaik int;
begin
  if auth.uid() is null then
    raise exception 'Harus login';
  end if;
  if p_skor is null or p_skor < 0 or p_skor > 1000000 then
    raise exception 'Skor tidak valid';
  end if;
  if exists (select 1 from public.games where id = p_game and status = 'archived') then
    raise exception 'Game sudah diarsipkan';
  end if;

  insert into public.game_scores as t (game_id, user_id, skor, level, plays)
  values (p_game, auth.uid(), p_skor, greatest(coalesce(p_level, 1), 1), 1)
  on conflict (game_id, user_id) do update set
    plays = t.plays + 1,
    last_played = now(),
    skor = greatest(t.skor, excluded.skor),
    level = case when excluded.skor > t.skor then excluded.level else t.level end,
    best_at = case when excluded.skor > t.skor then now() else t.best_at end;

  perform public.sinkron_juara(p_game);

  select skor into terbaik from public.game_scores where game_id = p_game and user_id = auth.uid();
  return terbaik;
end;
$$;

-- 11) Izin eksekusi. Fungsi internal TIDAK boleh dipanggil langsung oleh pengguna.
revoke all on function public.jam_kaget() from public, anon, authenticated;
revoke all on function public.kaget_aktif() from public, anon, authenticated;
revoke all on function public.isi_hadiah_tertunda() from public, anon, authenticated;
revoke all on function public.beri_hadiah(text, uuid) from public, anon, authenticated;
revoke all on function public.sinkron_juara(text) from public, anon, authenticated;

revoke all on function public.proses_dana_kaget() from public, anon;
grant execute on function public.proses_dana_kaget() to authenticated;
revoke all on function public.hadiah_saya() from public, anon;
grant execute on function public.hadiah_saya() to authenticated;
revoke all on function public.tandai_hadiah_dilihat(bigint) from public, anon;
grant execute on function public.tandai_hadiah_dilihat(bigint) to authenticated;
revoke all on function public.kirim_skor(text, int, int) from public, anon;
grant execute on function public.kirim_skor(text, int, int) to authenticated;
