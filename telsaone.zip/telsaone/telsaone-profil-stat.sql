-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-chat.sql).
-- Menambah bio dan tanggal bergabung ke profil publik, dipakai kartu statistik di halaman chat.

alter table public.profiles add column if not exists bio text not null default '';
alter table public.profiles add column if not exists joined_at timestamptz;

-- Isi data untuk pengguna yang sudah ada
update public.profiles p
set joined_at = coalesce(p.joined_at, u.created_at),
    bio = case when p.bio = '' then coalesce(left(u.raw_user_meta_data ->> 'bio', 120), '') else p.bio end
from auth.users u
where u.id = p.id;
