-- Suka untuk website: satu akun hanya bisa satu suka (kunci utama = user_id).
-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-chat.sql). Aman dijalankan ulang.
create table if not exists public.site_likes (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.site_likes enable row level security;
-- Tidak ada akses langsung ke tabel; semua lewat dua fungsi di bawah.

-- Jumlah suka dan apakah akun ini sudah menyukai (boleh dipanggil siapa saja)
create or replace function public.info_suka()
returns table (jumlah int, sudah boolean) language sql stable security definer set search_path = public as $$
  select (select count(*)::int from public.site_likes),
         coalesce((select true from public.site_likes where user_id = auth.uid()), false);
$$;

-- Memberi suka: hanya akun yang login, dan hanya sekali (pemberian kedua tidak menambah hitungan)
create or replace function public.suka_situs()
returns int language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Masuk dulu untuk memberi suka.'; end if;
  insert into public.site_likes (user_id) values (auth.uid()) on conflict do nothing;
  return (select count(*)::int from public.site_likes);
end;
$$;

revoke all on function public.info_suka() from public;
revoke all on function public.suka_situs() from public, anon;
grant execute on function public.info_suka() to anon, authenticated;
grant execute on function public.suka_situs() to authenticated;
notify pgrst, 'reload schema';
