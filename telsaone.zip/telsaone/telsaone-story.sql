-- Jalankan sekali di Supabase > SQL Editor (setelah telsaone-chat.sql dan telsaone-admin.sql). Aman dijalankan ulang.
-- Story pengguna: foto/video, tampil publik selama 24 jam, lalu hilang otomatis.

-- 1) Bucket file story (publik dibaca; tiap pengguna hanya boleh unggah ke folder miliknya)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('stories', 'stories', true, 31457280,
  array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime'])
on conflict (id) do update set file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

-- 2) Tabel story
create table if not exists public.stories (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  media_path text not null,
  media_url text not null,
  media_type text not null check (media_type in ('image', 'video')),
  caption text not null default '' check (char_length(caption) <= 140),
  created_at timestamptz not null default now()
);
create index if not exists stories_created_idx on public.stories (created_at desc);
alter table public.stories enable row level security;

-- Publik hanya melihat story yang umurnya < 24 jam (pemilik dan admin tetap bisa melihat sisa yang kedaluwarsa untuk dibersihkan)
drop policy if exists "story dibaca publik 24 jam" on public.stories;
create policy "story dibaca publik 24 jam" on public.stories for select
  using (created_at > now() - interval '24 hours' or user_id = auth.uid() or public.is_admin());
drop policy if exists "story unggah sendiri" on public.stories;
create policy "story unggah sendiri" on public.stories for insert to authenticated
  with check (user_id = auth.uid() and split_part(media_path, '/', 1) = auth.uid()::text);
drop policy if exists "story hapus sendiri atau admin" on public.stories;
create policy "story hapus sendiri atau admin" on public.stories for delete to authenticated
  using (user_id = auth.uid() or public.is_admin());

-- Maksimal 10 story aktif per pengguna (anti-spam)
create or replace function public.batas_story()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.stories where user_id = new.user_id and created_at > now() - interval '24 hours') >= 10 then
    raise exception 'Maksimal 10 story aktif dalam 24 jam.';
  end if;
  return new;
end;
$$;
drop trigger if exists batas_story on public.stories;
create trigger batas_story before insert on public.stories for each row execute function public.batas_story();

-- 3) Pembersihan otomatis: siapa pun yang membuka situs ikut membersihkan story yang sudah > 24 jam
create or replace function public.story_kedaluwarsa(p_path text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.stories where media_path = p_path and created_at < now() - interval '24 hours');
$$;
create or replace function public.daftar_story_kedaluwarsa()
returns table (id bigint, media_path text) language sql stable security definer set search_path = public as $$
  select s.id, s.media_path from public.stories s where s.created_at < now() - interval '24 hours' order by s.created_at limit 30;
$$;
create or replace function public.hapus_story_kedaluwarsa(p_ids bigint[])
returns void language sql security definer set search_path = public as $$
  delete from public.stories where id = any(p_ids) and created_at < now() - interval '24 hours';
$$;
grant execute on function public.story_kedaluwarsa(text) to anon, authenticated;
grant execute on function public.daftar_story_kedaluwarsa() to anon, authenticated;
grant execute on function public.hapus_story_kedaluwarsa(bigint[]) to anon, authenticated;

-- 4) Aturan file di storage
drop policy if exists "story file dibaca semua" on storage.objects;
create policy "story file dibaca semua" on storage.objects for select using (bucket_id = 'stories');
drop policy if exists "story file unggah sendiri" on storage.objects;
create policy "story file unggah sendiri" on storage.objects for insert to authenticated
  with check (bucket_id = 'stories' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "story file hapus" on storage.objects;
create policy "story file hapus" on storage.objects for delete to anon, authenticated
  using (bucket_id = 'stories' and (
    (storage.foldername(name))[1] = auth.uid()::text
    or public.is_admin()
    or public.story_kedaluwarsa(name)));

notify pgrst, 'reload schema';
