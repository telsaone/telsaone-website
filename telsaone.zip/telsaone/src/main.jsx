import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.jsx";
import { ContentProvider } from "./lib/content";
import { MusicProvider } from "./lib/music";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <ContentProvider>
      <MusicProvider>
        <App />
      </MusicProvider>
    </ContentProvider>
  </BrowserRouter>
);
