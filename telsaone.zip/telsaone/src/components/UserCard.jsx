import { useEffect, useState } from "react";
import { useContent } from "../lib/content";
import { CalendarDays, MessageCircle, X } from "lucide-react";
import { supabase } from "../lib/supabase";
import Avatar from "./Avatar";

const tglJoin = (v) => (v ? new Date(v).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }) : "-");

// Kartu statistik pengguna: nama, foto, bio, tanggal bergabung, jumlah pesan
export default function UserCard({ info, onClose }) {
  const { teks } = useContent();
  const [jumlah, setJumlah] = useState(null);

  useEffect(() => {
    const esc = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [onClose]);

  useEffect(() => {
    if (!supabase || !info?.id) return;
    let batal = false;
    supabase.from("messages").select("id", { count: "exact", head: true }).eq("user_id", info.id)
      .then(({ count, error }) => { if (!batal && !error) setJumlah(count); });
    return () => { batal = true; };
  }, [info?.id]);

  const stat = [
    { Icon: CalendarDays, label: "Bergabung", nilai: tglJoin(info.joined) },
    { Icon: MessageCircle, label: "Pesan", nilai: jumlah === null ? "..." : jumlah },
  ];

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/50 p-5" onClick={onClose} role="dialog" aria-modal="true" aria-label="Statistik pengguna">
      <div className="pop panel relative w-full max-w-sm p-6 text-center" style={{ transform: "none" }} onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} aria-label="Tutup" className="btn absolute right-3 top-3 flex bg-pink-200 p-1"><X size={18} strokeWidth={3} /></button>
        <div className="mx-auto flex w-fit"><Avatar user={info.user} size={96} /></div>
        <h2 className="mt-3 break-words font-comic text-4xl leading-none tracking-wide">{info.nama}</h2>
        <div className="bubble panel mt-6 rounded-2xl p-3 text-left" style={{ transform: "none", boxShadow: "4px 4px 0 #111" }}>
          <p className="break-words font-body font-bold text-neutral-700">{info.bio || teks.kartu_bio_kosong}</p>
        </div>
        <div className="mt-6 grid grid-cols-2 gap-3">
          {stat.map(({ Icon, label, nilai }) => (
            <div key={label} className="border-[3px] border-black bg-white p-3 shadow-[3px_3px_0_#111]">
              <div className="mx-auto flex h-9 w-9 items-center justify-center rounded-full border-[3px] border-black bg-yellow-300"><Icon size={18} strokeWidth={2.5} /></div>
              <p className="mt-1 font-comic text-base tracking-wide text-neutral-500">{label}</p>
              <p className="font-body text-sm font-bold">{nilai}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
