import { useCallback, useEffect, useState } from "react";
import { Crown, Eye, Gift, Link2, Plus, RefreshCw, Save, Trash2, Trophy } from "lucide-react";
import { supabase } from "../lib/supabase";
import { GAME_META } from "../lib/games";
import DanaKagetPopup from "./DanaKagetPopup";

const input = "w-full border-[3px] border-black bg-white px-3 py-2 font-body font-bold outline-none transition-shadow focus:shadow-[4px_4px_0_#111]";
const row = "inline-flex items-center justify-center gap-2";
const judulGame = (id) => GAME_META.find((g) => g.id === id)?.judul || id;
const waktu = (v) => {
  const d = new Date(v);
  return d.toLocaleDateString("id-ID", { day: "numeric", month: "short" }) + ", " + d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
};
const durasi = (ms) => {
  const m = Math.max(0, Math.floor(ms / 60000));
  return `${Math.floor(m / 60)} jam ${m % 60} mnt`;
};
const pendekkan = (u) => (u.length > 46 ? u.slice(0, 30) + "..." + u.slice(-12) : u);
const LINK_VALID = /^https:\/\/\S+$/;

function Kotak({ judul, Ikon, children }) {
  return (
    <div className="border-[3px] border-black bg-white p-4 shadow-[4px_4px_0_#111]">
      <h3 className="flex items-center gap-2 font-comic text-2xl tracking-wide"><Ikon size={22} strokeWidth={2.5} /> {judul}</h3>
      <div className="mt-3">{children}</div>
    </div>
  );
}

// Admin > HADIAH: link Dana Kaget, teks pop-up ucapan selamat, aturan (jam bertahan), dan riwayat pemenang
export default function HadiahAdmin({ kaget, refresh, onToast }) {
  const [data, setData] = useState(null); // { links, hadiah, juara }
  const [galat, setGalat] = useState("");
  const [form, setForm] = useState({ aktif: kaget.aktif, jam: String(kaget.jam), judul: kaget.judul, pesan: kaget.pesan, tombol: kaget.tombol,
    reset_juara: kaget.reset_juara, tahan_jam: String(kaget.tahan_jam), tahan_permanen: kaget.tahan_permanen, level_aktif: kaget.level_aktif, level_maks: String(kaget.level_maks), level_judul: kaget.level_judul, level_pesan: kaget.level_pesan });
  const [tempel, setTempel] = useState("");
  const [saving, setSaving] = useState(false);
  const [menambah, setMenambah] = useState(false);
  const [lihat, setLihat] = useState(false); // false | "juara" | "level"
  const [konfirm, setKonfirm] = useState("");
  const [hapus, setHapus] = useState(0);

  const muat = useCallback(async () => {
    if (!supabase) return setGalat("Supabase belum dikonfigurasi.");
    const [l, h, j] = await Promise.all([
      supabase.from("dana_kaget_link").select("id,url,dibuat").order("id"),
      supabase.from("dana_kaget_hadiah").select("id,game_id,link_id,menang_at,dilihat_at,jenis,level,profiles(nama)").order("id", { ascending: false }).limit(100),
      supabase.from("juara_game").select("game_id,sejak,hadiah_diberikan,profiles(nama)"),
    ]);
    if (l.error || h.error || j.error) {
      setGalat("Tabel hadiah belum lengkap. Jalankan telsaone-hadiah.sql lalu telsaone-level.sql di Supabase > SQL Editor.");
      setData({ links: [], hadiah: [], juara: [] });
      return;
    }
    setGalat("");
    setData({ links: l.data, hadiah: h.data, juara: j.data });
  }, []);
  useEffect(() => { muat(); }, [muat]);

  const simpan = async () => {
    const jam = Number(form.jam);
    if (!Number.isInteger(jam) || jam < 1 || jam > 720) return onToast("Lama bertahan harus 1 sampai 720 jam.");
    if (!form.judul.trim() || !form.pesan.trim() || !form.tombol.trim()) return onToast("Judul, pesan, dan tombol tidak boleh kosong.");
    const tahan = Number(form.tahan_jam);
    if (!Number.isInteger(tahan) || tahan < 0 || tahan > 720) return onToast("Lama tahan juara harus 0 sampai 720 jam.");
    const maks = Number(form.level_maks);
    if (!Number.isInteger(maks) || maks < 1 || maks > 500) return onToast("Hadiah level berlaku untuk level 1 sampai 500.");
    if (!form.level_judul.trim() || !form.level_pesan.trim()) return onToast("Judul dan pesan hadiah level tidak boleh kosong.");
    setSaving(true);
    const value = {
      aktif: form.aktif, jam, judul: form.judul.trim(), pesan: form.pesan.trim(), tombol: form.tombol.trim(),
      reset_juara: form.reset_juara, tahan_jam: tahan, tahan_permanen: form.tahan_permanen, level_aktif: form.level_aktif, level_maks: maks, level_judul: form.level_judul.trim(), level_pesan: form.level_pesan.trim(),
    };
    const { error } = await supabase.from("site_content").upsert({ key: "dana_kaget", value, updated_at: new Date().toISOString() });
    if (error) onToast(error.message || "Gagal menyimpan.");
    else { await refresh(); onToast("Pengaturan hadiah tersimpan!"); }
    setSaving(false);
  };

  const tambah = async () => {
    const baris = [...new Set(tempel.split(/\s+/).map((x) => x.trim()).filter(Boolean))];
    if (baris.length === 0) return onToast("Tempel dulu link-nya (satu link per baris).");
    const buruk = baris.filter((u) => !LINK_VALID.test(u) || u.length > 500);
    if (buruk.length) return onToast(`${buruk.length} link tidak valid. Harus diawali https:// (contoh: ${buruk[0].slice(0, 30)})`);
    const ada = new Set(data.links.map((x) => x.url));
    const baru = baris.filter((u) => !ada.has(u));
    if (baru.length === 0) return onToast("Semua link itu sudah ada.");
    setMenambah(true);
    const { error } = await supabase.from("dana_kaget_link").insert(baru.map((url) => ({ url })));
    if (error) onToast(error.message || "Gagal menambah link.");
    else {
      setTempel("");
      await supabase.rpc("proses_dana_kaget"); // jika ada pemenang yang menunggu link, langsung diisi
      await muat();
      onToast(`${baru.length} link ditambahkan${baris.length > baru.length ? `, ${baris.length - baru.length} sudah ada` : ""}.`);
    }
    setMenambah(false);
  };

  const hapusLink = async (id) => {
    if (hapus !== id) return setHapus(id);
    setHapus(0);
    const { error } = await supabase.from("dana_kaget_link").delete().eq("id", id);
    if (error) return onToast("Link yang sudah dipakai pemenang tidak bisa dihapus.");
    setData((d) => ({ ...d, links: d.links.filter((x) => x.id !== id) }));
  };

  const reset = async (mode) => {
    if (konfirm !== mode) return setKonfirm(mode);
    setKonfirm("");
    const { error } = await supabase.rpc("reset_skor_game", { p_game: "brick", p_mode: mode });
    if (error) return onToast(error.message || "Gagal mereset. Pastikan telsaone-level.sql sudah dijalankan.");
    onToast(mode === "semua" ? "Semua skor Brick Breaker direset." : "Skor juara direset ke 0.");
    muat();
  };

  if (data === null) return <p className="py-8 text-center font-comic text-2xl tracking-wide">MEMUAT...</p>;

  const dipakai = new Map(data.hadiah.filter((h) => h.link_id).map((h) => [h.link_id, h]));
  const tersedia = data.links.filter((l) => !dipakai.has(l.id)).length;
  const menunggu = data.hadiah.filter((h) => !h.link_id).length;
  const sampel = { id: 0, url: "https://link.dana.id/kaget?c=CONTOH" };

  return (
    <div className="space-y-5">
      {galat && <p className="border-[3px] border-dashed border-black bg-pink-100 p-3 font-body font-bold">{galat}</p>}

      <div className="grid grid-cols-3 gap-2">
        {[["LINK TERSEDIA", tersedia, "bg-green-200"], ["MENANG", data.hadiah.length, "bg-yellow-300"], ["MENUNGGU LINK", menunggu, menunggu ? "bg-pink-300" : "bg-sky-200"]].map(([l, n, bg]) => (
          <div key={l} className={`border-[3px] border-black px-2 py-1 text-center shadow-[3px_3px_0_#111] ${bg}`}>
            <div className="font-comic text-xs leading-none tracking-widest">{l}</div>
            <div className="mt-0.5 font-comic text-2xl leading-tight">{n}</div>
          </div>
        ))}
      </div>
      {tersedia === 0 && <p className="border-[3px] border-dashed border-black bg-yellow-100 p-3 font-body font-bold">Stok link habis. Tambahkan link di bawah agar pemenang berikutnya langsung dapat hadiah.</p>}

      <Kotak judul="PENGATURAN & POP-UP" Ikon={Gift}>
        <div className="space-y-3">
          <label className="flex items-center gap-2 font-body font-bold">
            <input type="checkbox" checked={form.aktif} onChange={(e) => setForm({ ...form, aktif: e.target.checked })} className="h-5 w-5 accent-black" />
            Hadiah aktif (matikan untuk menjeda tanpa menghapus link)
          </label>
          <label className="block">
            <span className="font-comic text-lg tracking-wide">Lama bertahan di peringkat 1 (jam)</span>
            <input type="number" min={1} max={720} value={form.jam} onChange={(e) => setForm({ ...form, jam: e.target.value })} className={input} />
          </label>
          <label className="block">
            <span className="font-comic text-lg tracking-wide">Judul pop-up</span>
            <input value={form.judul} maxLength={60} onChange={(e) => setForm({ ...form, judul: e.target.value })} className={input} />
          </label>
          <label className="block">
            <span className="font-comic text-lg tracking-wide">Pesan ucapan selamat</span>
            <textarea value={form.pesan} rows={4} maxLength={600} onChange={(e) => setForm({ ...form, pesan: e.target.value })} className={input} />
            <span className="font-body text-sm font-bold text-neutral-500">Bisa dipakai: {"{nama}"} nama pemenang, {"{game}"} nama game, {"{jam}"} lama bertahan.</span>
          </label>
          <label className="block">
            <span className="font-comic text-lg tracking-wide">Teks tombol</span>
            <input value={form.tombol} maxLength={30} onChange={(e) => setForm({ ...form, tombol: e.target.value })} className={input} />
          </label>
          <label className="flex items-center gap-2 font-body font-bold">
            <input type="checkbox" checked={form.reset_juara} onChange={(e) => setForm({ ...form, reset_juara: e.target.checked })} className="h-5 w-5 accent-black" />
            Reset otomatis: setelah juara menerima hadiah dan masa tahan di bawah selesai, skornya jadi 0 dan hitungan jam dimulai dari awal
          </label>
          <label className="flex items-center gap-2 font-body font-bold">
            <input type="checkbox" checked={form.tahan_permanen} onChange={(e) => setForm({ ...form, tahan_permanen: e.target.checked })} className="h-5 w-5 accent-black" />
            Permanen: juara tidak pernah hilang / direset otomatis (hanya tergeser jika direbut orang lain)
          </label>
          <label className={`block ${form.tahan_permanen ? "opacity-50" : ""}`}>
            <span className="font-comic text-lg tracking-wide">Tahan juara di papan setelah hadiah (jam)</span>
            <input type="number" min={0} max={720} disabled={form.tahan_permanen} value={form.tahan_jam} onChange={(e) => setForm({ ...form, tahan_jam: e.target.value })} className={input} />
            <span className="font-body text-sm font-bold text-neutral-500">Selama masa ini juara tetap tampil di papan peringkat (bawaan 24 jam). 0 = langsung direset. Jika puncak direbut orang lain di masa tahan, skor juara lama tidak direset. Butuh telsaone-juara-tahan.sql.</span>
          </label>
          <div className="border-t-[3px] border-dashed border-black pt-3">
            <label className="flex items-center gap-2 font-body font-bold">
              <input type="checkbox" checked={form.level_aktif} onChange={(e) => setForm({ ...form, level_aktif: e.target.checked })} className="h-5 w-5 accent-black" />
              Hadiah per level aktif (tiap pemain 1 link per level yang pertama kali diselesaikan)
            </label>
            <label className="mt-2 block">
              <span className="font-comic text-lg tracking-wide">Hadiah berlaku sampai level</span>
              <input type="number" min={1} max={500} value={form.level_maks} onChange={(e) => setForm({ ...form, level_maks: e.target.value })} className={input} />
            </label>
            <label className="mt-2 block">
              <span className="font-comic text-lg tracking-wide">Judul pop-up level</span>
              <input value={form.level_judul} maxLength={60} onChange={(e) => setForm({ ...form, level_judul: e.target.value })} className={input} />
            </label>
            <label className="mt-2 block">
              <span className="font-comic text-lg tracking-wide">Pesan hadiah level</span>
              <textarea value={form.level_pesan} rows={3} maxLength={600} onChange={(e) => setForm({ ...form, level_pesan: e.target.value })} className={input} />
              <span className="font-body text-sm font-bold text-neutral-500">Bisa dipakai: {"{nama}"}, {"{game}"}, {"{level}"} nomor level.</span>
            </label>
          </div>
          <div className="flex flex-wrap gap-3">
            <button type="button" onClick={simpan} disabled={saving} className={`btn ${row} bg-yellow-300 px-5 py-2 text-xl disabled:opacity-60`}><Save size={20} strokeWidth={2.5} /> {saving ? "MENYIMPAN..." : "SIMPAN"}</button>
            <button type="button" onClick={() => setLihat("juara")} className={`btn ${row} bg-sky-200 px-5 py-2 text-xl`}><Eye size={20} strokeWidth={2.5} /> PRATINJAU JUARA</button>
            <button type="button" onClick={() => setLihat("level")} className={`btn ${row} bg-sky-200 px-5 py-2 text-xl`}><Eye size={20} strokeWidth={2.5} /> PRATINJAU LEVEL</button>
          </div>
        </div>
      </Kotak>

      <Kotak judul="RESET PERINGKAT BRICK BREAKER" Ikon={RefreshCw}>
        <p className="font-body text-sm font-bold text-neutral-500">Reset manual kapan saja, tanpa menunggu jam hadiah. Ketuk dua kali untuk mengonfirmasi.</p>
        <div className="mt-2 flex flex-wrap gap-3">
          <button type="button" onClick={() => reset("juara")} className={`btn ${row} ${konfirm === "juara" ? "bg-red-300" : "bg-yellow-300"} px-4 py-2 text-lg`}><Crown size={18} strokeWidth={2.5} /> {konfirm === "juara" ? "YAKIN? SKOR JUARA JADI 0" : "RESET SKOR JUARA 1"}</button>
          <button type="button" onClick={() => reset("semua")} className={`btn ${row} ${konfirm === "semua" ? "bg-red-300" : "bg-pink-200"} px-4 py-2 text-lg`}><Trash2 size={18} strokeWidth={2.5} /> {konfirm === "semua" ? "YAKIN? HAPUS SEMUA SKOR" : "RESET SEMUA SKOR"}</button>
        </div>
      </Kotak>

      <Kotak judul="TAMBAH LINK DANA KAGET" Ikon={Plus}>
        <textarea value={tempel} onChange={(e) => setTempel(e.target.value)} rows={4} placeholder={"https://link.dana.id/kaget?c=...\nhttps://link.dana.id/kaget?c=..."} className={input} />
        <p className="font-body text-sm font-bold text-neutral-500">Satu link per baris. Tiap link hanya dikirim ke satu pemenang. Pemenang menerimanya lewat pop-up; link tidak pernah tampil di halaman publik.</p>
        <button type="button" onClick={tambah} disabled={menambah} className={`btn ${row} mt-2 bg-green-300 px-5 py-2 text-xl disabled:opacity-60`}><Plus size={20} strokeWidth={3} /> {menambah ? "MENAMBAH..." : "TAMBAH LINK"}</button>
      </Kotak>

      <Kotak judul={`DAFTAR LINK (${data.links.length})`} Ikon={Link2}>
        {data.links.length === 0 ? (
          <p className="border-[3px] border-dashed border-black p-3 text-center font-body font-bold text-neutral-500">Belum ada link.</p>
        ) : (
          <ul className="papan-scroll max-h-72 space-y-1.5 overflow-y-auto pr-2">
            {data.links.map((l) => {
              const h = dipakai.get(l.id);
              return (
                <li key={l.id} className="flex items-center gap-2 border-2 border-black bg-neutral-50 px-2 py-1">
                  <span className="min-w-0 flex-1 truncate font-body text-sm font-bold">{pendekkan(l.url)}</span>
                  <span className={`shrink-0 border-2 border-black px-1.5 font-comic text-sm tracking-wider ${h ? "bg-zinc-200" : "bg-green-200"}`}>
                    {h ? `DIPAKAI ${h.profiles?.nama || ""}`.trim() : "TERSEDIA"}
                  </span>
                  {!h && (
                    <button type="button" onClick={() => hapusLink(l.id)} aria-label="Hapus link" className={`btn flex items-center gap-1 px-1.5 py-0.5 text-sm ${hapus === l.id ? "bg-red-300" : "bg-pink-200"}`}>
                      <Trash2 size={15} strokeWidth={3} /> {hapus === l.id ? "YAKIN?" : ""}
                    </button>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </Kotak>

      <Kotak judul="PEMEGANG PERINGKAT 1" Ikon={Crown}>
        {data.juara.length === 0 ? (
          <p className="font-body text-sm font-bold text-neutral-500">Belum ada juara.</p>
        ) : (
          <ul className="space-y-1.5">
            {data.juara.map((j) => (
              <li key={j.game_id} className="border-2 border-black bg-yellow-100 px-2 py-1 font-body text-sm font-bold">
                <span className="font-comic text-lg tracking-wide">{judulGame(j.game_id)}</span>: {j.profiles?.nama || "Pengguna"}, bertahan {durasi(Date.now() - new Date(j.sejak).getTime())}
                {j.hadiah_diberikan ? " (hadiah sudah diberikan)" : ""}
              </li>
            ))}
          </ul>
        )}
      </Kotak>

      <Kotak judul="RIWAYAT PEMENANG" Ikon={Trophy}>
        {data.hadiah.length === 0 ? (
          <p className="font-body text-sm font-bold text-neutral-500">Belum ada pemenang.</p>
        ) : (
          <ul className="papan-scroll max-h-72 space-y-1.5 overflow-y-auto pr-2">
            {data.hadiah.map((h) => (
              <li key={h.id} className="flex items-center gap-2 border-2 border-black bg-neutral-50 px-2 py-1">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-comic text-lg leading-tight tracking-wide">{h.profiles?.nama || "Pengguna"}</p>
                  <p className="font-body text-xs font-bold text-neutral-500">{judulGame(h.game_id)} · {h.jenis === "level" ? `Level ${h.level}` : "Juara 1"} · {waktu(h.menang_at)}</p>
                </div>
                <span className={`shrink-0 border-2 border-black px-1.5 font-comic text-sm tracking-wider ${!h.link_id ? "bg-pink-300" : h.dilihat_at ? "bg-green-200" : "bg-yellow-200"}`}>
                  {!h.link_id ? "MENUNGGU LINK" : h.dilihat_at ? "SUDAH DIBUKA" : "BELUM DIBUKA"}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Kotak>

      <button type="button" onClick={muat} className={`btn ${row} bg-sky-200 px-4 py-1 text-lg`}><RefreshCw size={18} strokeWidth={2.5} /> SEGARKAN</button>

      {lihat && (
        <DanaKagetPopup
          pratinjau
          hadiah={lihat === "level" ? { ...sampel, jenis: "level", level: 3 } : sampel}
          kaget={{ ...form, jam: Number(form.jam) || kaget.jam }}
          nama="Budi"
          gameJudul={GAME_META[0]?.judul || "Game"}
          onTunda={() => setLihat(false)}
          onSelesai={() => setLihat(false)}
        />
      )}
    </div>
  );
}
