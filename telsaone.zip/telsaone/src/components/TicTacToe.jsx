import { useCallback, useEffect, useRef, useState } from "react";
import { Bot, Repeat, Users } from "lucide-react";
import { Kotak, TombolAtas, InfoMasuk } from "./gamekit";

// Tic Tac Toe: lawan komputer (3 tingkat) atau main berdua di satu layar.
// Poin peringkat = jumlah poin selama kamu bermain melawan komputer (menang / seri di tingkat lebih sulit = poin lebih besar).
const GARIS = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
const TINGKAT = [
  { id: 1, label: "MUDAH", menang: 10, seri: 0, ket: "Santai, komputer sering salah langkah", bg: "bg-green-200" },
  { id: 2, label: "SEDANG", menang: 25, seri: 5, ket: "Lumayan menantang", bg: "bg-yellow-300" },
  { id: 3, label: "SULIT", menang: 60, seri: 15, ket: "Komputer hampir tidak pernah kalah", bg: "bg-pink-200" },
];
const WARNA = { X: "#fb7185", O: "#38bdf8" };

function cek(b) {
  for (const [x, y, z] of GARIS) if (b[x] && b[x] === b[y] && b[x] === b[z]) return { w: b[x], garis: [x, y, z] };
  return b.every(Boolean) ? { w: "seri", garis: [] } : null;
}

// Minimax + pemangkasan alpha-beta: cepat, tidak membuat HP tersendat
function minimax(b, giliran, ai, kedalaman, alfa = -Infinity, beta = Infinity) {
  const p = cek(b);
  if (p) return p.w === "seri" ? 0 : p.w === ai ? 10 - kedalaman : kedalaman - 10;
  const lawan = ai === "X" ? "O" : "X";
  const maks = giliran === ai;
  let terbaik = maks ? -Infinity : Infinity;
  for (let i = 0; i < 9; i++) {
    if (b[i]) continue;
    b[i] = giliran;
    const s = minimax(b, maks ? lawan : ai, ai, kedalaman + 1, alfa, beta);
    b[i] = null;
    if (maks) { terbaik = Math.max(terbaik, s); alfa = Math.max(alfa, s); } else { terbaik = Math.min(terbaik, s); beta = Math.min(beta, s); }
    if (beta <= alfa) break;
  }
  return terbaik;
}

function langkahAI(b, tingkat, ai = "O") {
  const kosong = [];
  b.forEach((v, i) => { if (!v) kosong.push(i); });
  if (!kosong.length) return -1;
  const acak = () => kosong[Math.floor(Math.random() * kosong.length)];
  if (tingkat === 1) return acak();
  if (tingkat === 2 && Math.random() < 0.4) return acak();
  // papan masih kosong: semua pembuka terbaik (tengah / sudut) sama bagusnya, tak perlu menghitung apa pun
  if (kosong.length === 9) return [0, 2, 4, 6, 8][Math.floor(Math.random() * 5)];
  // langkah terbaik (acak di antara yang sama bagusnya supaya tidak monoton)
  const lawan = ai === "X" ? "O" : "X";
  let skorTerbaik = -Infinity, pilihan = [];
  for (const i of kosong) {
    const c = b.slice();
    c[i] = ai;
    const s = minimax(c, lawan, ai, 1);
    if (s > skorTerbaik) { skorTerbaik = s; pilihan = [i]; } else if (s === skorTerbaik) pilihan.push(i);
  }
  return pilihan[Math.floor(Math.random() * pilihan.length)];
}

// Tanda X / O digambar dengan garis (animasi menggambar), berbingkai hitam ala stiker
function Tanda({ nilai, menang }) {
  const warna = WARNA[nilai];
  const garis = (props) => (
    <>
      <path {...props} stroke="#111" strokeWidth="19" className="ttt-gambar" pathLength="1" />
      <path {...props} stroke={warna} strokeWidth="10" className="ttt-gambar" pathLength="1" />
    </>
  );
  return (
    <svg viewBox="0 0 100 100" className={`h-full w-full ${menang ? "ttt-denyut" : ""}`} fill="none" strokeLinecap="round" aria-hidden="true">
      {nilai === "X" ? (
        <>
          {garis({ d: "M24 24 L76 76" })}
          {garis({ d: "M76 24 L24 76", style: { animationDelay: ".12s" } })}
        </>
      ) : (
        garis({ d: "M50 24 A26 26 0 1 1 49.9 24", transform: "rotate(0 50 50)" })
      )}
    </svg>
  );
}

export default function TicTacToe({ onBack, user, onLogin, onSelesai }) {
  const [layar, setLayar] = useState("menu"); // menu (pilih lawan) | tingkat (pilih tingkat, hanya vs komputer) | main
  const [mode, setMode] = useState("cpu"); // cpu | duo
  const [tingkat, setTingkat] = useState(2);
  const [papan, setPapan] = useState(Array(9).fill(null));
  const [giliran, setGiliran] = useState("X");
  const [awal, setAwal] = useState("X");
  const [hasil, setHasil] = useState(null); // { w, garis, poin }
  const [tally, setTally] = useState({ X: 0, O: 0, seri: 0 });
  const [poin, setPoin] = useState(0);
  const poinRef = useRef(0);
  const maxTingkat = useRef(1);
  const laporRef = useRef(onSelesai);
  laporRef.current = onSelesai;

  const simpanPoin = useCallback((tambah, lv) => {
    poinRef.current += tambah;
    maxTingkat.current = Math.max(maxTingkat.current, lv);
    setPoin(poinRef.current);
    if (tambah > 0) laporRef.current?.({ score: poinRef.current, level: maxTingkat.current });
  }, []);

  const main = (i, siapa) => {
    const b = papan.slice();
    b[i] = siapa;
    setPapan(b);
    const p = cek(b);
    if (!p) { setGiliran(siapa === "X" ? "O" : "X"); return; }
    let tambah = 0;
    if (mode === "cpu") {
      const t = TINGKAT[tingkat - 1];
      if (p.w === "X") tambah = t.menang;
      else if (p.w === "seri") tambah = t.seri;
      simpanPoin(tambah, tingkat);
    }
    setHasil({ ...p, poin: tambah });
    setTally((s) => (p.w === "seri" ? { ...s, seri: s.seri + 1 } : { ...s, [p.w]: s[p.w] + 1 }));
  };

  // Giliran komputer (O)
  useEffect(() => {
    if (mode !== "cpu" || hasil || giliran !== "O") return undefined;
    const t = setTimeout(() => {
      const m = langkahAI(papan, tingkat);
      if (m >= 0) main(m, "O");
    }, 480);
    return () => clearTimeout(t);
  }, [mode, hasil, giliran, papan, tingkat]); // eslint-disable-line react-hooks/exhaustive-deps

  const ketuk = (i) => {
    if (hasil || papan[i]) return;
    if (mode === "cpu" && giliran !== "X") return;
    main(i, giliran);
  };

  const ronde = () => {
    const a = awal === "X" ? "O" : "X"; // yang mulai bergantian tiap ronde
    setAwal(a);
    setGiliran(a);
    setPapan(Array(9).fill(null));
    setHasil(null);
  };
  const mulaiBaru = (m, t) => {
    setMode(m);
    if (t) setTingkat(t);
    setTally({ X: 0, O: 0, seri: 0 });
    setAwal("X"); setGiliran("X"); setPapan(Array(9).fill(null)); setHasil(null);
    setLayar("main");
  };
  const ulangSemua = () => {
    setTally({ X: 0, O: 0, seri: 0 });
    setAwal("X"); setGiliran("X"); setPapan(Array(9).fill(null)); setHasil(null);
  };

  const cpu = mode === "cpu";
  const namaX = cpu ? "KAMU (X)" : "PEMAIN X";
  const namaO = cpu ? "KOMPUTER (O)" : "PEMAIN O";
  let pesan = "";
  if (hasil) {
    if (hasil.w === "seri") pesan = "SERI!";
    else if (cpu) pesan = hasil.w === "X" ? "KAMU MENANG!" : "KOMPUTER MENANG";
    else pesan = `PEMAIN ${hasil.w} MENANG!`;
  } else if (cpu) pesan = giliran === "X" ? "GILIRANMU" : "KOMPUTER MIKIR...";
  else pesan = `GILIRAN PEMAIN ${giliran}`;

  const warnaPesan = hasil ? (hasil.w === "seri" ? "bg-sky-200" : cpu && hasil.w === "O" ? "bg-rose-200" : "bg-green-200") : "bg-yellow-300";
  const ctr = (i) => ({ x: 50 + (i % 3) * 100, y: 50 + Math.floor(i / 3) * 100 });

  if (layar !== "main") {
    return (
      <div className="mx-auto w-full max-w-[380px]">
        <TombolAtas onBack={layar === "tingkat" ? () => setLayar("menu") : onBack} />
        {layar === "menu" ? (
          <>
            <p className="mt-3 border-[3px] border-black bg-yellow-300 px-2 py-1 text-center font-comic text-2xl leading-tight tracking-wide shadow-[3px_3px_0_#111]">MAU MAIN SAMA SIAPA?</p>
            <button type="button" onClick={() => setLayar("tingkat")} className="btn mt-3 flex w-full items-center gap-3 bg-sky-200 px-3 py-3 text-left">
              <Bot size={30} strokeWidth={2.5} className="shrink-0" />
              <span><span className="block font-comic text-2xl leading-none tracking-wide">LAWAN KOMPUTER</span><span className="mt-1 block font-body text-sm font-bold leading-tight">Main sendiri. Menang dapat poin peringkat.</span></span>
            </button>
            <button type="button" onClick={() => mulaiBaru("duo")} className="btn mt-3 flex w-full items-center gap-3 bg-pink-200 px-3 py-3 text-left">
              <Users size={30} strokeWidth={2.5} className="shrink-0" />
              <span><span className="block font-comic text-2xl leading-none tracking-wide">2 PEMAIN</span><span className="mt-1 block font-body text-sm font-bold leading-tight">Main berdua gantian di satu layar (tanpa poin).</span></span>
            </button>
          </>
        ) : (
          <>
            <p className="mt-3 border-[3px] border-black bg-yellow-300 px-2 py-1 text-center font-comic text-2xl leading-tight tracking-wide shadow-[3px_3px_0_#111]">PILIH TINGKAT</p>
            {TINGKAT.map((t) => (
              <button key={t.id} type="button" onClick={() => mulaiBaru("cpu", t.id)} className={`btn mt-3 flex w-full items-center justify-between gap-3 px-3 py-2 text-left ${t.bg}`}>
                <span><span className="block font-comic text-2xl leading-none tracking-wide">{t.label}</span><span className="mt-1 block font-body text-sm font-bold leading-tight">{t.ket}</span></span>
                <span className="shrink-0 font-comic text-xl tracking-wide">+{t.menang}</span>
              </button>
            ))}
            <p className="mt-3 font-body text-xs font-bold leading-snug text-neutral-600">Angka di kanan = poin bila kamu menang. Makin sulit, makin besar poinnya.</p>
          </>
        )}
      </div>
    );
  }

  const namaTingkat = TINGKAT[tingkat - 1].label;

  return (
    <div className="mx-auto w-full max-w-[380px]">
      <style>{`
        @keyframes ttt-gambar { from { stroke-dashoffset: 1; } to { stroke-dashoffset: 0; } }
        @keyframes ttt-denyut { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.08); } }
        .ttt-gambar { stroke-dasharray: 1; stroke-dashoffset: 0; animation: ttt-gambar .26s ease-out both; }
        .ttt-denyut { animation: ttt-denyut .7s ease-in-out .3s 2; transform-origin: center; }
        .ttt-garis { stroke-dasharray: 1; animation: ttt-gambar .35s ease-out .15s both; }
        @media (prefers-reduced-motion: reduce) { .ttt-gambar, .ttt-denyut, .ttt-garis { animation: none; stroke-dashoffset: 0; } }
      `}</style>

      <div className="grid grid-cols-3 gap-2">
        <Kotak label={namaX} bg="bg-pink-200">{tally.X}</Kotak>
        <Kotak label="SERI" bg="bg-neutral-100">{tally.seri}</Kotak>
        <Kotak label={namaO} bg="bg-sky-200">{tally.O}</Kotak>
      </div>

      <TombolAtas onBack={onBack} onUlang={ulangSemua} ulangLabel="ULANG SKOR" />

      <div className="mt-3 flex items-center justify-between gap-2 border-[3px] border-black bg-white px-2 py-1 shadow-[3px_3px_0_#111]">
        <span className="inline-flex min-w-0 items-center gap-1.5 truncate font-comic text-lg tracking-wide">
          {cpu ? <Bot size={18} strokeWidth={2.5} /> : <Users size={18} strokeWidth={2.5} />}
          {cpu ? `VS KOMPUTER · ${namaTingkat}` : "2 PEMAIN"}
        </span>
        <button type="button" onClick={() => setLayar("menu")} className="btn inline-flex shrink-0 items-center gap-1 bg-sky-200 px-2 py-0 text-base">
          <Repeat size={14} strokeWidth={3} /> GANTI
        </button>
      </div>

      <p className={`mt-3 border-[3px] border-black px-2 py-1 text-center font-comic text-2xl leading-tight tracking-wide shadow-[3px_3px_0_#111] ${warnaPesan}`}>{pesan}</p>

      {/* Papan */}
      <div className="relative mt-3 aspect-square w-full border-4 border-black bg-white shadow-[6px_6px_0_#111]">
        <div className="grid h-full w-full grid-cols-3">
          {papan.map((v, i) => {
            const menangSel = hasil?.garis.includes(i);
            const pinggir = `${i % 3 !== 2 ? "border-r-4" : ""} ${i < 6 ? "border-b-4" : ""}`;
            const bisa = !hasil && !v && (!cpu || giliran === "X");
            return (
              <button
                key={i}
                type="button"
                onClick={() => ketuk(i)}
                aria-label={v ? `Kotak ${i + 1}: ${v}` : `Kotak ${i + 1} kosong`}
                className={`flex items-center justify-center border-black p-[14%] transition-colors ${pinggir} ${menangSel ? "bg-yellow-200" : bisa ? "hover:bg-neutral-100" : ""} ${bisa ? "cursor-pointer" : "cursor-default"}`}
              >
                {v && <Tanda nilai={v} menang={menangSel} />}
              </button>
            );
          })}
        </div>
        {hasil && hasil.garis.length > 0 && (
          <svg viewBox="0 0 300 300" className="pointer-events-none absolute inset-0 h-full w-full" fill="none" strokeLinecap="round" aria-hidden="true">
            <line x1={ctr(hasil.garis[0]).x} y1={ctr(hasil.garis[0]).y} x2={ctr(hasil.garis[2]).x} y2={ctr(hasil.garis[2]).y} stroke="#111" strokeWidth="9" pathLength="1" className="ttt-garis" />
          </svg>
        )}
      </div>

      {hasil && (
        <div className="pop mt-3 border-[3px] border-black bg-white p-3 text-center shadow-[4px_4px_0_#111]">
          {cpu && hasil.poin > 0 && <p className="font-comic text-xl tracking-wide text-green-700">+{hasil.poin} POIN</p>}
          {cpu && <p className="font-comic text-lg tracking-wide">TOTAL POIN: {poin}</p>}
          {cpu && <InfoMasuk user={user} onLogin={onLogin} />}
          <button onClick={ronde} className="btn mt-2 bg-yellow-300 px-4 py-1 text-xl">RONDE BERIKUTNYA</button>
        </div>
      )}
      {!hasil && cpu && poin > 0 && <p className="mt-3 text-center font-comic text-lg tracking-wide">TOTAL POIN: {poin}</p>}
      {!hasil && cpu && poin === 0 && !user && <InfoMasuk user={user} onLogin={onLogin} />}
      <p className="mt-3 font-body text-xs font-bold leading-snug text-neutral-600">
        {cpu
          ? "Menang melawan komputer memberi poin (makin sulit makin besar); seri di tingkat sedang & sulit juga dapat poin. Yang mulai bergantian tiap ronde."
          : "Mode 2 pemain tidak masuk peringkat. Yang mulai bergantian tiap ronde."}
      </p>
    </div>
  );
}
