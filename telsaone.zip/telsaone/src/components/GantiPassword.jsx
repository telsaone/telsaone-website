import { useEffect, useState } from "react";
import { useContent } from "../lib/content";
import { Sisip } from "../lib/sisip";
import { Lock, MailCheck, ShieldCheck, X } from "lucide-react";
import { supabase } from "../lib/supabase";
import { inAppReset } from "../lib/flag";
import { pakaiEmail } from "../lib/provider";

const input = "w-full border-[3px] border-black bg-white px-3 py-2 font-body font-bold outline-none transition-shadow focus:shadow-[4px_4px_0_#111]";
const row = "inline-flex items-center justify-center gap-2";
const pesan = (m = "") => (/rate limit|too many|seconds/i.test(m) ? "Terlalu banyak percobaan. Tunggu sebentar lalu coba lagi." : m);

// Alur: klik kotak -> kode verifikasi dikirim ke email -> masukkan kode -> isi password baru.
export default function GantiPassword({ email, onToast }) {
  const { teks } = useContent();
  const [step, setStep] = useState(0); // 0 tertutup, 1 verifikasi kode, 2 password baru
  const [kode, setKode] = useState("");
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [busy, setBusy] = useState(false);
  const [tunggu, setTunggu] = useState(0);

  useEffect(() => {
    if (tunggu <= 0) return;
    const t = setTimeout(() => setTunggu((n) => n - 1), 1000);
    return () => clearTimeout(t);
  }, [tunggu]);
  useEffect(() => () => { inAppReset.on = false; }, []);

  const tutup = () => { inAppReset.on = false; setStep(0); setKode(""); setPw(""); setPw2(""); setTunggu(0); };

  const kirim = async () => {
    if (!supabase || busy || tunggu > 0) return;
    setBusy(true);
    inAppReset.on = true;
    const { error } = await supabase.auth.resetPasswordForEmail(email);
    setBusy(false);
    if (error) { if (step === 0) inAppReset.on = false; return onToast(pesan(error.message)); }
    setTunggu(60);
    setStep(1);
    onToast(teks.gp_toast_kode);
  };

  const verifikasi = async (e) => {
    e.preventDefault();
    if (!kode.trim()) return onToast("Masukkan kode dari email Anda.");
    setBusy(true);
    const { error } = await supabase.auth.verifyOtp({ email, token: kode.trim(), type: "recovery" });
    setBusy(false);
    if (error) return onToast("Kode salah atau sudah kedaluwarsa.");
    setStep(2);
  };

  const simpan = async (e) => {
    e.preventDefault();
    if (pw.length < 6) return onToast("Password minimal 6 karakter.");
    if (pw !== pw2) return onToast("Konfirmasi password tidak sama.");
    setBusy(true);
    const { data: cek } = await supabase.auth.getUser();
    if (!pakaiEmail(cek?.user)) { setBusy(false); return onToast("Ganti password hanya untuk akun dengan login email."); }
    const { error } = await supabase.auth.updateUser({ password: pw });
    setBusy(false);
    if (error) return onToast(pesan(error.message));
    tutup();
    onToast(teks.gp_toast_sukses);
  };

  if (step === 0)
    return (
      <button type="button" onClick={kirim} disabled={busy}
        className="panel mt-3 flex w-full items-center gap-4 p-4 text-left disabled:opacity-60" style={{ transform: "none" }}>
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border-[3px] border-black bg-yellow-300"><Lock size={24} strokeWidth={2.5} /></span>
        <span className="min-w-0">
          <span className="block font-comic text-2xl tracking-wide">{busy ? teks.gp_mengirim : teks.gp_judul}</span>
          <span className="block font-body text-sm font-bold text-neutral-600">{teks.gp_info}</span>
        </span>
      </button>
    );

  return (
    <div className="slide-in mt-3 border-[3px] border-black bg-[#fdfbf4] p-4">
      <div className="mb-3 flex items-center justify-between gap-2">
        <p className="flex items-center gap-2 font-comic text-2xl tracking-wide">
          {step === 1 ? <MailCheck size={24} strokeWidth={2.5} /> : <ShieldCheck size={24} strokeWidth={2.5} />}
          {step === 1 ? teks.gp_verifikasi : teks.gp_baru}
        </p>
        <button type="button" onClick={tutup} aria-label="Batal" className="btn flex bg-white p-1"><X size={18} strokeWidth={3} /></button>
      </div>

      {step === 1 ? (
        <form onSubmit={verifikasi} className="space-y-3">
          <p className="font-body font-bold text-neutral-700"><Sisip teks={teks.gp_kode_info} nilai={{ email: <span className="break-all">{email}</span> }} /></p>
          <input value={kode} onChange={(e) => setKode(e.target.value)} inputMode="numeric" autoComplete="one-time-code" placeholder={teks.gp_ph_kode} className={`${input} text-center text-xl tracking-[0.3em]`} />
          <div className="flex flex-wrap gap-3">
            <button type="submit" disabled={busy} className={`btn ${row} bg-yellow-300 px-5 py-2 text-xl disabled:opacity-60`}>{busy ? teks.gp_tunggu : teks.gp_tombol_verifikasi}</button>
            <button type="button" onClick={kirim} disabled={busy || tunggu > 0} className={`btn ${row} bg-white px-5 py-2 text-xl disabled:opacity-60`}>{tunggu > 0 ? `${teks.gp_kirim_ulang} (${tunggu})` : teks.gp_kirim_ulang}</button>
          </div>
        </form>
      ) : (
        <form onSubmit={simpan} className="space-y-3">
          <p className="font-body font-bold text-green-700">{teks.gp_terverifikasi}</p>
          <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder={teks.gp_ph_baru} autoComplete="new-password" className={input} />
          <input type="password" value={pw2} onChange={(e) => setPw2(e.target.value)} placeholder={teks.gp_ph_ulang} autoComplete="new-password" className={input} />
          <button type="submit" disabled={busy} className={`btn ${row} bg-yellow-300 px-5 py-2 text-xl disabled:opacity-60`}>{busy ? teks.gp_menyimpan : teks.gp_simpan}</button>
        </form>
      )}
    </div>
  );
}
