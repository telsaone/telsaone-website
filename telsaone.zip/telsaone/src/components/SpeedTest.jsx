import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowDown, ArrowUp, Gauge, Play, RotateCcw, Square } from "lucide-react";
import Reveal from "./Reveal";

// Tes kecepatan internet sederhana (Mbps download & upload) lewat server Cloudflare.
const DOWN = "https://speed.cloudflare.com/__down?bytes=";
const UP = "https://speed.cloudflare.com/__up";
const DURASI_DOWN = 7000; // ms
const DURASI_UP = 6000;
const SKALA = [10, 25, 50, 100, 250, 500, 1000, 2500]; // batas atas bilah (Mbps), naik otomatis mengikuti hasil

const skalaUntuk = (v) => SKALA.find((s) => v * 1.12 <= s) || SKALA[SKALA.length - 1];
const fmt = (v) => (v >= 100 ? v.toFixed(0) : v.toFixed(1));

// Satu bilah kecepatan bergaya komik: kotak bersegmen yang terisi, dengan angka Mbps besar
function Bilah({ Icon, label, nilai, aktif, warna }) {
  const maks = skalaUntuk(nilai || 0);
  const persen = Math.min(100, ((nilai || 0) / maks) * 100);
  return (
    <div className="border-[3px] border-black bg-white p-3 shadow-[4px_4px_0_#111]">
      <div className="flex items-end justify-between gap-2">
        <span className="inline-flex items-center gap-2 font-comic text-xl tracking-wide">
          <span className="flex h-8 w-8 items-center justify-center rounded-full border-[3px] border-black" style={{ background: warna }}>
            <Icon size={18} strokeWidth={3} />
          </span>
          {label}
        </span>
        <span className="font-comic leading-none tracking-wide" aria-live="off">
          <span className={`text-4xl ${aktif ? "animate-pulse" : ""}`}>{nilai == null ? "--" : fmt(nilai)}</span>
          <span className="ml-1 text-lg text-neutral-600">Mbps</span>
        </span>
      </div>
      <div className="relative mt-3 h-7 overflow-hidden border-[3px] border-black bg-neutral-100"
        role="meter" aria-label={label} aria-valuemin={0} aria-valuemax={maks} aria-valuenow={Math.round(nilai || 0)}>
        <div className="h-full border-r-[3px] border-black transition-[width] duration-300 ease-out"
          style={{ width: `${persen}%`, background: warna, backgroundImage: "repeating-linear-gradient(-45deg, rgba(0,0,0,.14) 0 6px, transparent 6px 12px)" }} />
        {/* garis segmen */}
        <div className="pointer-events-none absolute inset-0" style={{ backgroundImage: "repeating-linear-gradient(90deg, transparent 0 calc(10% - 2px), rgba(0,0,0,.35) calc(10% - 2px) 10%)" }} />
      </div>
      <div className="mt-1 flex justify-between font-body text-xs font-bold text-neutral-500">
        <span>0</span><span>{maks / 2}</span><span>{maks} Mbps</span>
      </div>
    </div>
  );
}

export default function SpeedTest() {
  const [fase, setFase] = useState("diam"); // diam | down | up | selesai | gagal
  const [down, setDown] = useState(null);
  const [up, setUp] = useState(null);
  const stopRef = useRef(null);

  useEffect(() => () => stopRef.current?.(), []);

  const unduh = useCallback(async (ctl, lapor) => {
    const t0 = performance.now();
    let bytes = 0, t1 = null, b1 = 0;
    const jalur = async () => {
      while (performance.now() - t0 < DURASI_DOWN && !ctl.signal.aborted) {
        const res = await fetch(DOWN + 12_000_000 + "&r=" + Math.random(), { signal: ctl.signal, cache: "no-store" });
        if (!res.ok || !res.body) throw new Error("down");
        const rd = res.body.getReader();
        for (;;) {
          const { done, value } = await rd.read();
          if (done) break;
          bytes += value.length;
          const now = performance.now();
          if (t1 === null && now - t0 > 700) { t1 = now; b1 = bytes; } // abaikan 0,7 detik pertama (pemanasan koneksi)
          if (t1 !== null && now - t1 > 250) lapor(((bytes - b1) * 8) / ((now - t1) / 1000) / 1e6);
          if (now - t0 >= DURASI_DOWN) { rd.cancel().catch(() => {}); break; }
        }
      }
    };
    await Promise.all([jalur(), jalur(), jalur(), jalur()]);
    const akhir = performance.now();
    if (t1 === null) return (bytes * 8) / ((akhir - t0) / 1000) / 1e6;
    return ((bytes - b1) * 8) / ((akhir - t1) / 1000) / 1e6;
  }, []);

  const unggah = useCallback((ctl, lapor) => new Promise((resolve, reject) => {
    const blob = new Blob([new Uint8Array(1_500_000)]);
    const t0 = performance.now();
    const total = new Array(3).fill(0);
    let t1 = null, b1 = 0, selesai = false, aktif = 0;
    const jumlah = () => total.reduce((a, b) => a + b, 0);
    const akhiri = () => {
      if (selesai) return;
      selesai = true;
      xhrs.forEach((x) => x.abort());
      const now = performance.now(), b = jumlah();
      if (b === 0) return reject(new Error("up"));
      resolve(t1 === null ? (b * 8) / ((now - t0) / 1000) / 1e6 : ((b - b1) * 8) / ((now - t1) / 1000) / 1e6);
    };
    const xhrs = [];
    const kirim = (i) => {
      if (selesai) return;
      const x = new XMLHttpRequest();
      xhrs.push(x); aktif++;
      let terakhir = 0;
      x.open("POST", UP);
      x.upload.onprogress = (e) => {
        total[i] += e.loaded - terakhir; terakhir = e.loaded;
        const now = performance.now();
        if (t1 === null && now - t0 > 700) { t1 = now; b1 = jumlah(); }
        if (t1 !== null && now - t1 > 250) lapor(((jumlah() - b1) * 8) / ((now - t1) / 1000) / 1e6);
        if (now - t0 >= DURASI_UP) akhiri();
      };
      x.onload = () => { aktif--; kirim(i); };
      x.onerror = () => { aktif--; if (jumlah() === 0 && !selesai) { selesai = true; reject(new Error("up")); } else akhiri(); };
      x.send(blob);
    };
    ctl.signal.addEventListener("abort", () => { selesai = true; xhrs.forEach((x) => x.abort()); reject(new DOMException("abort", "AbortError")); });
    for (let i = 0; i < 3; i++) kirim(i);
    setTimeout(akhiri, DURASI_UP + 2500);
  }), []);

  const mulai = async () => {
    stopRef.current?.();
    const ctl = new AbortController();
    stopRef.current = () => ctl.abort();
    setDown(null); setUp(null);
    try {
      setFase("down");
      const d = await unduh(ctl, setDown);
      if (ctl.signal.aborted) return;
      setDown(d);
      setFase("up");
      const u = await unggah(ctl, setUp);
      if (ctl.signal.aborted) return;
      setUp(u);
      setFase("selesai");
    } catch (e) {
      if (e?.name === "AbortError" || ctl.signal.aborted) return setFase("diam");
      setFase("gagal");
    }
  };
  const henti = () => { stopRef.current?.(); setFase("diam"); };
  const jalan = fase === "down" || fase === "up";

  return (
    <Reveal>
      <div className="panel mt-8 p-6" style={{ transform: "none" }}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="flex items-center gap-2 font-comic text-3xl tracking-wide"><Gauge size={28} strokeWidth={2.5} /> SPEED TEST</h2>
          <span className="border-2 border-black bg-sky-200 px-2 font-comic tracking-wider">
            {fase === "down" ? "MENGUNDUH..." : fase === "up" ? "MENGUNGGAH..." : fase === "selesai" ? "SELESAI!" : "SIAP"}
          </span>
        </div>
        <p className="mt-1 font-body font-bold text-neutral-600">Cek kecepatan internet yang sedang kamu pakai sekarang.</p>

        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <Bilah Icon={ArrowDown} label="DOWNLOAD" nilai={down} aktif={fase === "down"} warna="#7ed6ff" />
          <Bilah Icon={ArrowUp} label="UPLOAD" nilai={up} aktif={fase === "up"} warna="#9df0a8" />
        </div>

        {fase === "gagal" && (
          <p role="alert" className="mt-3 border-[3px] border-black bg-pink-200 px-3 py-2 font-body font-bold">
            Tes gagal. Periksa koneksi internet atau matikan VPN / pemblokir iklan, lalu coba lagi.
          </p>
        )}

        <div className="mt-5 flex flex-wrap items-center gap-3">
          {jalan ? (
            <button onClick={henti} className="btn inline-flex items-center gap-2 bg-pink-200 px-5 py-2 text-xl"><Square size={18} strokeWidth={2.5} /> BERHENTI</button>
          ) : (
            <button onClick={mulai} className="btn inline-flex items-center gap-2 bg-yellow-300 px-5 py-2 text-xl">
              {fase === "selesai" || fase === "gagal" ? <><RotateCcw size={18} strokeWidth={2.5} /> ULANGI TES</> : <><Play size={18} strokeWidth={2.5} /> MULAI TES</>}
            </button>
          )}
          <span className="font-body text-xs font-bold text-neutral-500">Memakai data seluruhnya sekitar 50–100 MB tergantung kecepatanmu.</span>
        </div>
      </div>
    </Reveal>
  );
}
