import { useEffect, useState } from "react";
import { useContent } from "../lib/content";
import { Check, Copy, ExternalLink, Gift, Sparkles, Star, Trophy, X } from "lucide-react";
import { isiPesan } from "../lib/hadiah";

// Pop-up ucapan selamat + link Dana Kaget. Teks diatur admin (Admin > HADIAH).
// `selesai` dipanggil setelah link dibuka / disalin (hadiah dianggap sudah diterima);
// `tunda` hanya menutup untuk sementara, pop-up muncul lagi saat web dibuka berikutnya.
export default function DanaKagetPopup({ hadiah, kaget, nama, gameJudul, onTunda, onSelesai, pratinjau = false }) {
  const { teks } = useContent();
  const [tersalin, setTersalin] = useState(false);

  useEffect(() => {
    const esc = (e) => e.key === "Escape" && onTunda();
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [onTunda]);

  const level = hadiah.jenis === "level";
  const judul = level ? kaget.level_judul : kaget.judul;
  const pesan = isiPesan(level ? kaget.level_pesan : kaget.pesan, { nama: nama || "Juara", game: gameJudul, jam: kaget.jam, level: hadiah.level });

  const salin = async () => {
    try {
      await navigator.clipboard.writeText(hadiah.url);
      setTersalin(true);
      if (!pratinjau) setTimeout(onSelesai, 1200);
    } catch {
      window.prompt("Salin link ini:", hadiah.url);
    }
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/60 p-5" onClick={onTunda} role="dialog" aria-modal="true" aria-label={judul}>
      <div className="pop panel relative w-full max-w-md bg-yellow-200 p-6 text-center" style={{ transform: "none" }} onClick={(e) => e.stopPropagation()}>
        <Star size={36} strokeWidth={2.5} fill="#f9a8d4" className="float absolute -left-4 -top-5 -rotate-12" />
        <Sparkles size={32} strokeWidth={2.5} fill="#7dd3fc" className="float absolute -right-3 -top-4 rotate-12" />
        <button onClick={onTunda} aria-label="Tutup" className="btn absolute right-3 top-3 flex bg-white p-1"><X size={18} strokeWidth={3} /></button>

        <div className="float mx-auto flex h-24 w-24 items-center justify-center rounded-full border-4 border-black bg-pink-300 shadow-[4px_4px_0_#111]">
          <Gift size={46} strokeWidth={2.5} />
        </div>
        <h2 className="mt-4 flex items-center justify-center gap-2 font-comic text-4xl leading-tight tracking-wide">
          <Trophy size={30} strokeWidth={2.5} /> {judul}
        </h2>
        <p className="mt-2 whitespace-pre-line break-words font-body font-bold text-neutral-800">{pesan}</p>

        <div className="mt-5 flex flex-col gap-2.5">
          <a
            href={hadiah.url}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => !pratinjau && setTimeout(onSelesai, 600)}
            className="btn inline-flex items-center justify-center gap-2 bg-green-300 px-5 py-2 text-2xl"
          >
            <ExternalLink size={22} strokeWidth={2.5} /> {kaget.tombol}
          </a>
          <button onClick={salin} className="btn inline-flex items-center justify-center gap-2 bg-white px-5 py-1.5 text-lg">
            {tersalin ? <Check size={18} strokeWidth={3} /> : <Copy size={18} strokeWidth={2.5} />} {tersalin ? "LINK TERSALIN!" : "SALIN LINK"}
          </button>
          <button onClick={onTunda} className="font-body text-sm font-bold text-neutral-600 underline">{teks.kaget_nanti}</button>
        </div>
      </div>
    </div>
  );
}
