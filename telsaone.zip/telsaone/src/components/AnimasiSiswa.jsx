import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { useContent } from "../lib/content";
import { Users } from "lucide-react";
import Reveal from "./Reveal";
import { Selotip } from "./Hiasan";
import { BIRTHDAYS, studentPhotos } from "../lib/siswa";

// Carousel (+ gsap ticker) dimuat terpisah (code-splitting) dan baru diunduh saat pengunjung hampir sampai ke bagian ini.
const ArcFlowCarousel = lazy(() => import("./ArcFlowCarousel"));

// Sama dengan telsaone: 33 foto, urutan mengikuti nomor file.
// Nama diambil dari BIRTHDAYS berdasarkan nomor foto (siswa.js), jadi cukup ubah di satu tempat.
const namaFoto = (no) => BIRTHDAYS.find((b) => b.photo === no)?.name;
const ITEMS = studentPhotos.map((src, i) => ({ src, alt: namaFoto(i + 1) ?? `Siswa ${i + 1}`, nama: namaFoto(i + 1) }));

// Foto yang di-prefetch dari awal & akhir daftar (kartu yang pertama terlihat di kiri & kanan lengkungan).
const PRELOAD_EACH_SIDE = 6;

// Satu kali true begitu elemen mendekati layar (margin = jarak awal dalam px di bawah layar).
function useDekatLayar(ref, margin) {
  const [dekat, setDekat] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || dekat) return undefined;
    if (typeof IntersectionObserver === "undefined") { setDekat(true); return undefined; }
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { setDekat(true); io.disconnect(); }
    }, { rootMargin: `0px 0px ${margin}px 0px` });
    io.observe(el);
    return () => io.disconnect();
  }, [ref, margin, dekat]);
  return dekat;
}

export default function AnimasiSiswa() {
  const { teks } = useContent();
  const ref = useRef(null);
  const pasang = useDekatLayar(ref, 250);
  const dekat = useDekatLayar(ref, 1500);
  const prefetched = useRef([]);

  useEffect(() => {
    if (!dekat) return;
    const depan = ITEMS.slice(0, PRELOAD_EACH_SIDE);
    const belakang = ITEMS.slice(-PRELOAD_EACH_SIDE);
    prefetched.current = [...depan, ...belakang].map(({ src }) => {
      const img = new Image();
      img.decoding = "async";
      img.src = src;
      return img;
    });
  }, [dekat]);

  if (!ITEMS.length) return null;

  return (
    <div ref={ref}>
      <Reveal>
        <h3 className="mb-4 mt-14 flex items-center gap-2 font-comic text-3xl tracking-wide">
          <Users size={28} strokeWidth={2.5} /> {teks.animasi_judul}
        </h3>
      </Reveal>
      <Reveal delay={100}>
        <div className="relative">
          <Selotip className="-top-3 left-8 -rotate-6" />
          <Selotip warna="bg-sky-300" className="-top-3 right-8 rotate-6" />
          <div className="relative overflow-hidden border-4 border-black bg-white shadow-[6px_6px_0_#111]">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 opacity-70"
              style={{ backgroundImage: "radial-gradient(rgba(0,0,0,.14) 1.5px, transparent 1.5px)", backgroundSize: "9px 9px" }}
            />
            {/* Tinggi dicadangkan supaya halaman tidak "loncat" saat carousel baru dipasang */}
            <div className="relative h-[540px] sm:h-[620px]">
              {pasang && (
                <Suspense fallback={null}>
                  {/* Pengaturan SAMA dengan animasi siswa di telsaone (arc-flow-section.tsx).
                      Beda hanya tema: latar transparan di atas kotak komik, kartu berbingkai hitam + bayangan keras. */}
                  <ArcFlowCarousel
                    items={ITEMS}
                    radiusRatio={0.85}
                    cardRatio={0.27}
                    minCardWidth={210}
                    maxCardWidth={420}
                    cardAspect={0.62}
                    overlap={-0.04}
                    arcOffset={0.54}
                    smoothing={5.5}
                    dragSensitivity={1.2}
                    momentum={1}
                    snap={false}
                    wheelControl="horizontal"
                    autoRotateSpeed={0.12}
                    pauseOnHover
                    surfaceColor="transparent"
                    tinggi="100%"
                    cardClassName="border-4 border-black bg-white"
                    cardShadow="5px 5px 0 #111"
                  />
                </Suspense>
              )}
            </div>
          </div>
        </div>
      </Reveal>
    </div>
  );
}
