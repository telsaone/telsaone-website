import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Gamepad2, KeyRound, MessageCircle, UserRound, Wrench } from "lucide-react";
import { NAV } from "../data";
import { useGoSection } from "../lib/nav";
import { AVATAR_ICONS, fotoUser } from "../lib/avatars";
import { isAdmin } from "../lib/admin";
import { useContent } from "../lib/content";

// Ikon Profil di dock: foto / avatar pengguna yang sedang login
function ProfilIcon({ user }) {
  const m = user?.user_metadata || {};
  const Ikon = AVATAR_ICONS[m.avatar_icon];
  const foto = fotoUser(m);
  const [rusak, setRusak] = useState(false);
  useEffect(() => setRusak(false), [foto]);
  if (Ikon)
    return (
      <span className="flex h-full w-full items-center justify-center rounded-full border-2 border-black" style={{ background: m.avatar_bg || "#ffe45e" }}>
        <Ikon size="60%" strokeWidth={2.5} />
      </span>
    );
  if (foto && !rusak) return <img src={foto} alt="" referrerPolicy="no-referrer" onError={() => setRusak(true)} className="h-full w-full rounded-full border-2 border-black object-cover" />;
  return <UserRound size="100%" strokeWidth={2.5} />;
}

// Dock gaya React Bits (magnifikasi berbasis spring, bounce saat klik, tooltip, indikator aktif)
// dengan tampilan komik: garis tebal hitam, bayangan offset, tooltip balon ucapan.
const CONFIG = {
  baseItemSize: 50,
  magnification: 72,
  distance: 150,
  panelHeight: 68,
  gap: 10,
  spring: { mass: 0.1, stiffness: 150, damping: 12 },
};

// Warna pastel saat disorot (literal agar terbaca Tailwind)
const HOVER_BG = [
  "group-hover:bg-pink-200 group-focus-visible:bg-pink-200",
  "group-hover:bg-sky-200 group-focus-visible:bg-sky-200",
  "group-hover:bg-green-200 group-focus-visible:bg-green-200",
  "group-hover:bg-orange-200 group-focus-visible:bg-orange-200",
];

const POP = "cubic-bezier(0.2, 1.25, 0.4, 1)";
const useIsoLayoutEffect = typeof window === "undefined" ? useEffect : useLayoutEffect;

export default function Dock({ active, user, onLogin }) {
  const goSection = useGoSection();
  const navigate = useNavigate();
  const { teks } = useContent();
  const { magnification, distance, panelHeight, gap, spring } = CONFIG;

  const items = useMemo(
    () => [
      ...NAV.filter((n) => n.id !== "penutup").map((n) => ({ ...n, label: teks["nav_" + n.id] || n.label })),
      { id: "game", label: teks.nav_game, icon: Gamepad2 },
      { id: "chat", label: teks.nav_chat, icon: MessageCircle },
      ...(isAdmin(user) ? [{ id: "admin", label: "Admin", icon: Wrench }] : []),
      user
        ? { id: "profil", label: teks.nav_profil, icon: UserRound }
        : { id: "login", label: teks.nav_masuk, icon: KeyRound },
    ],
    [user, teks]
  );
  const n = items.length;

  // Perkecil otomatis kalau layar sempit
  const [vw, setVw] = useState(() => (typeof window === "undefined" ? 1024 : window.innerWidth));
  useEffect(() => {
    const on = () => setVw(window.innerWidth);
    window.addEventListener("resize", on);
    return () => window.removeEventListener("resize", on);
  }, []);
  // Layar lebar (desktop): dock dibuat lebih besar. Di HP/tablet kecil ukurannya tetap seperti semula.
  const desk = vw >= 1024;
  const baseMax = desk ? 58 : CONFIG.baseItemSize;
  const magn = desk ? 90 : magnification;
  const panelH = desk ? 76 : panelHeight;
  const pad = Math.round((panelH - baseMax) / 2);
  const fit = (vw - 24 - 8 - pad * 2 - gap * (n - 1) - 24) / n; // 24 margin sisi, 8 border panel
  const base = Math.max(34, Math.min(baseMax, fit));
  const thickness = base + pad * 2;

  const panelRef = useRef(null);
  const itemRefs = useRef([]);
  const iconRefs = useRef([]);
  const faceRefs = useRef([]);
  const sizes = useRef([]);
  const vels = useRef([]);
  const targets = useRef([]);
  const raf = useRef(0);
  const last = useRef(0);
  const pointer = useRef(null);
  const reduce = useRef(false);
  const baseRef = useRef(base);
  baseRef.current = base;

  const apply = (i, s) => {
    const el = itemRefs.current[i];
    if (!el) return;
    el.style.width = `${s}px`;
    el.style.height = `${s}px`;
    const ic = iconRefs.current[i];
    if (ic) {
      const d = s * (+ic.dataset.k || 0.5);
      ic.style.width = `${d}px`;
      ic.style.height = `${d}px`;
    }
  };

  const tick = (t) => {
    const dt = Math.min((t - last.current) / 1000, 1 / 30);
    last.current = t;
    const { mass, stiffness, damping } = spring;
    let moving = false;
    for (let i = 0; i < n; i++) {
      let x = sizes.current[i];
      let v = vels.current[i];
      const target = targets.current[i];
      const steps = 4;
      const h = dt / steps;
      for (let k = 0; k < steps; k++) {
        const a = (-stiffness * (x - target) - damping * v) / mass;
        v += a * h;
        x += v * h;
      }
      if (Math.abs(x - target) < 0.05 && Math.abs(v) < 0.05) {
        x = target;
        v = 0;
      } else moving = true;
      sizes.current[i] = x;
      vels.current[i] = v;
      apply(i, x);
    }
    raf.current = moving ? requestAnimationFrame(tick) : 0;
  };

  const run = () => {
    if (reduce.current) {
      for (let i = 0; i < n; i++) {
        sizes.current[i] = targets.current[i];
        vels.current[i] = 0;
        apply(i, targets.current[i]);
      }
      return;
    }
    if (!raf.current) {
      last.current = performance.now();
      raf.current = requestAnimationFrame(tick);
    }
  };

  const setTargets = () => {
    const b = baseRef.current;
    const p = pointer.current;
    if (p === null) {
      for (let i = 0; i < n; i++) targets.current[i] = b;
      return;
    }
    // Jarak dihitung dari posisi diam tiap ikon, supaya tidak bergetar saat panel melebar
    const rect = panelRef.current.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const left = cx - (n * b + (n - 1) * gap) / 2;
    const pk = Math.max(b, b * (magn / baseMax));
    const reach = distance * (b / baseMax);
    for (let i = 0; i < n; i++) {
      const c = left + i * (b + gap) + b / 2;
      const d = Math.min(Math.abs(p - c) / reach, 1);
      targets.current[i] = b + (pk - b) * 0.5 * (1 + Math.cos(Math.PI * d));
    }
  };

  // Sinkronkan ukuran saat jumlah item / ukuran dasar berubah
  useIsoLayoutEffect(() => {
    reduce.current = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    for (let i = 0; i < n; i++) {
      sizes.current[i] = base;
      vels.current[i] = 0;
      targets.current[i] = base;
      apply(i, base);
    }
    pointer.current = null;
  }, [n, base]);

  useEffect(() => () => cancelAnimationFrame(raf.current), []);

  // Animasi muncul
  useEffect(() => {
    if (reduce.current) return;
    panelRef.current?.animate(
      [{ transform: "translateY(130%) scale(.9)", opacity: 0 }, { transform: "none", opacity: 1 }],
      { duration: 560, easing: POP, delay: 150, fill: "backwards" }
    );
  }, []);

  const onMove = (e) => {
    pointer.current = e.clientX;
    setTargets();
    run();
  };
  const onLeave = () => {
    pointer.current = null;
    setTargets();
    run();
  };

  const hop = (i) => {
    const btn = itemRefs.current[i];
    const face = faceRefs.current[i];
    if (!face || reduce.current) return;
    const h = (sizes.current[i] || base) * 0.55;
    btn?.setAttribute("data-hop", "");
    const a = face.animate(
      [
        { transform: "translateY(0)", easing: "cubic-bezier(.2,.7,.3,1)" },
        { transform: `translateY(${-h}px) scale(1.05, .96)`, offset: 0.2, easing: "cubic-bezier(.7,0,.8,.4)" },
        { transform: "translateY(0) scale(1.08, .9)", offset: 0.38, easing: "ease-out" },
        { transform: `translateY(${-h * 0.42}px)`, offset: 0.55, easing: "cubic-bezier(.7,0,.8,.4)" },
        { transform: "translateY(0) scale(1.04, .95)", offset: 0.72 },
        { transform: "translateY(0)" },
      ],
      { duration: 760 }
    );
    a.onfinish = a.oncancel = () => btn?.removeAttribute("data-hop");
  };

  const go = (id) =>
    id === "login" ? onLogin() : id === "profil" || id === "chat" || id === "admin" || id === "game" ? navigate("/" + id) : goSection(id)();

  const press = (i, id) => {
    hop(i);
    go(id);
  };

  return (
    <div
      className="pointer-events-none fixed inset-x-0 bottom-0 z-40 flex justify-center px-3"
      style={{ paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 12px)" }}
    >
      <div
        ref={panelRef}
        onPointerMove={onMove}
        onPointerDown={onMove}
        onPointerLeave={onLeave}
        onPointerCancel={onLeave}
        onPointerUp={(e) => e.pointerType !== "mouse" && onLeave()}
        role="toolbar"
        aria-label="Navigasi dock"
        className="pointer-events-auto relative box-border flex items-end rounded-2xl border-4 border-black bg-white shadow-[6px_6px_0_#111]"
        style={{
          gap,
          height: thickness,
          padding: pad,
          touchAction: "pan-y",
          backgroundImage: "radial-gradient(#e3dfd0 1.1px, transparent 1.1px)",
          backgroundSize: "9px 9px",
        }}
      >
        {items.map((it, i) => {
          const Icon = it.icon;
          const on = active === it.id;
          return (
            <button
              key={it.id}
              ref={(el) => (itemRefs.current[i] = el)}
              onClick={() => press(i, it.id)}
              aria-label={it.label}
              aria-current={on ? "page" : undefined}
              style={{ width: base, height: base }}
              className="group relative m-0 flex-none cursor-pointer select-none border-0 bg-transparent p-0 outline-none [-webkit-tap-highlight-color:transparent] hover:z-[1] focus-visible:z-[1]"
            >
              <span
                ref={(el) => (faceRefs.current[i] = el)}
                className={`absolute inset-0 flex items-center justify-center rounded-xl border-[3px] border-black shadow-[3px_3px_0_#111] transition-[background-color,box-shadow,translate] duration-150 group-active:translate-x-[2px] group-active:translate-y-[2px] group-active:shadow-[1px_1px_0_#111] group-focus-visible:outline group-focus-visible:outline-[3px] group-focus-visible:outline-offset-[3px] group-focus-visible:outline-red-500 ${
                  on ? "bg-yellow-300" : `bg-neutral-50 ${HOVER_BG[i % HOVER_BG.length]}`
                }`}
              >
                <span
                  ref={(el) => (iconRefs.current[i] = el)}
                  data-k={it.id === "profil" ? "0.72" : "0.5"}
                  className="flex items-center justify-center"
                  style={{ width: base * (it.id === "profil" ? 0.72 : 0.5), height: base * (it.id === "profil" ? 0.72 : 0.5) }}
                >
                  {it.id === "profil" ? <ProfilIcon user={user} /> : <Icon size="100%" strokeWidth={2.5} />}
                </span>
              </span>

              {/* Tooltip balon ucapan */}
              <span
                className="pointer-events-none absolute bottom-[calc(100%+14px)] left-1/2 whitespace-nowrap rounded-md border-[3px] border-black bg-white px-2.5 py-0.5 font-comic text-base leading-tight tracking-wide opacity-0 shadow-[3px_3px_0_#111] [transform:translate(-50%,6px)_scale(.85)] [transition:opacity_.16s_ease,transform_.22s_cubic-bezier(.2,1.25,.4,1)] after:absolute after:-bottom-[8px] after:left-1/2 after:h-3 after:w-3 after:-translate-x-1/2 after:rotate-45 after:border-b-[3px] after:border-r-[3px] after:border-black after:bg-white after:content-[''] group-hover:opacity-100 group-hover:[transform:translate(-50%,0)_scale(1)] group-focus-visible:opacity-100 group-focus-visible:[transform:translate(-50%,0)_scale(1)] group-data-[hop]:!opacity-0"
              >
                {it.label}
              </span>

            </button>
          );
        })}
      </div>
    </div>
  );
}
