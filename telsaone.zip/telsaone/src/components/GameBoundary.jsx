import { Component } from "react";
import { ArrowLeft, RefreshCw } from "lucide-react";

// Pengaman: kalau sebuah game error (atau file game gagal dimuat karena sinyal putus / web baru diperbarui),
// hanya kotak game yang diganti pesan ramah. Halaman web lainnya tetap jalan, tidak jadi layar putih.
export default class GameBoundary extends Component {
  state = { galat: null };

  static getDerivedStateFromError(galat) {
    return { galat };
  }

  componentDidCatch(galat) {
    console.error("Game error:", galat);
  }

  render() {
    if (!this.state.galat) return this.props.children;
    const muat = /chunk|dynamically imported|import/i.test(String(this.state.galat?.message || this.state.galat));
    return (
      <div className="border-[3px] border-dashed border-black bg-pink-100 p-5 text-center">
        <p className="font-comic text-3xl leading-none tracking-wide">GAME BERMASALAH</p>
        <p className="mt-2 font-body text-sm font-bold text-neutral-700">
          {muat ? "Game gagal dimuat (sinyal putus atau web baru diperbarui). Muat ulang halaman ya." : "Ada kendala di game ini. Coba ulang, atau kembali ke daftar game."}
        </p>
        <div className="mt-3 flex flex-wrap justify-center gap-2">
          {!muat && (
            <button onClick={() => this.setState({ galat: null })} className="btn inline-flex items-center gap-1 bg-yellow-300 px-3 py-1 text-lg">
              <RefreshCw size={18} strokeWidth={2.5} /> COBA LAGI
            </button>
          )}
          {muat && (
            <button onClick={() => window.location.reload()} className="btn inline-flex items-center gap-1 bg-yellow-300 px-3 py-1 text-lg">
              <RefreshCw size={18} strokeWidth={2.5} /> MUAT ULANG
            </button>
          )}
          <button onClick={this.props.onBack} className="btn inline-flex items-center gap-1 bg-white px-3 py-1 text-lg">
            <ArrowLeft size={18} strokeWidth={2.5} /> KEMBALI
          </button>
        </div>
      </div>
    );
  }
}
