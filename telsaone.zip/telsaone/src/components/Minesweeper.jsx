import { useEffect, useRef, useState } from "react";
import { Bomb, Clock, Flag, MousePointerClick, Trophy, X } from "lucide-react";
import { Kotak, Pilihan, TombolAtas, InfoMasuk, bacaAngka, simpanAngka } from "./gamekit";

// Minesweeper: buka kotak yang aman, tandai yang berisi ranjau.
// Skor (hanya jika menang) = poin dasar level + bonus kecepatan.
const LEVEL = [
  { id: 1, nama: "MUDAH", r: 8, c: 8, m: 10, dasar: 1000, par: 120, k: 5, ikon: 22, huruf: "text-2xl" },
  { id: 2, nama: "SEDANG", r: 10, c: 10, m: 18, dasar: 2500, par: 240, k: 10, ikon: 19, huruf: "text-xl" },
  { id: 3, nama: "SULIT", r: 12, c: 12, m: 30, dasar: 5000, par: 400, k: 15, ikon: 16, huruf: "text-lg" },
];
const WARNA = ["", "#2563eb", "#16a34a", "#dc2626", "#7c3aed", "#b45309", "#0891b2", "#111111", "#6b7280"];
const kunciHi = (id) => `telsaone:ms:hi:${id}`;

function tetangga(i, R, C) {
  const r = Math.floor(i / C), c = i % C, out = [];
  for (let dr = -1; dr <= 1; dr++) {
    for (let dc = -1; dc <= 1; dc++) {
      if (!dr && !dc) continue;
      const rr = r + dr, cc = c + dc;
      if (rr >= 0 && rr < R && cc >= 0 && cc < C) out.push(rr * C + cc);
    }
  }
  return out;
}

const papanKosong = (L) => Array.from({ length: L.r * L.c }, () => ({ m: false, n: 0, o: false, f: false }));

// Ranjau dipasang SETELAH klik pertama: kotak pertama & sekitarnya dijamin aman
function pasangRanjau(sel, L, aman) {
  const larang = new Set([aman, ...tetangga(aman, L.r, L.c)]);
  const kand = [];
  for (let i = 0; i < sel.length; i++) if (!larang.has(i)) kand.push(i);
  for (let k = 0; k < L.m; k++) {
    const j = k + Math.floor(Math.random() * (kand.length - k));
    [kand[k], kand[j]] = [kand[j], kand[k]];
    sel[kand[k]].m = true;
  }
  for (let i = 0; i < sel.length; i++) {
    sel[i].n = tetangga(i, L.r, L.c).filter((j) => sel[j].m).length;
  }
}

// Buka kotak (dan meluas bila kosong). Mengembalikan indeks ranjau yang terinjak, atau -1.
function bukaSel(sel, L, awal) {
  const antre = [awal];
  let boom = -1;
  while (antre.length) {
    const i = antre.pop();
    const x = sel[i];
    if (x.o || x.f) continue;
    x.o = true;
    if (x.m) { if (boom < 0) boom = i; continue; }
    if (x.n === 0) for (const j of tetangga(i, L.r, L.c)) if (!sel[j].o && !sel[j].f) antre.push(j);
  }
  return boom;
}

export default function Minesweeper({ onBack, user, onLogin, onSelesai }) {
  const [li, setLi] = useState(0);
  const L = LEVEL[li];
  const [g, setG] = useState(() => ({ sel: papanKosong(LEVEL[0]), st: "siap", boom: -1 })); // st: siap | main | menang | kalah
  const [detik, setDetik] = useState(0);
  const [skor, setSkor] = useState(0);
  const [mode, setMode] = useState("buka"); // buka | bendera
  const [hi, setHi] = useState(() => bacaAngka(kunciHi(1)));
  const mulaiRef = useRef(0);
  const gRef = useRef(g);
  gRef.current = g;
  const laporRef = useRef(onSelesai);
  laporRef.current = onSelesai;
  const lp = useRef({ t: null, fired: false });

  // Waktu berjalan hanya selama permainan
  useEffect(() => {
    if (g.st !== "main") return undefined;
    const id = setInterval(() => setDetik(Math.min(999, Math.floor((Date.now() - mulaiRef.current) / 1000))), 250);
    return () => clearInterval(id);
  }, [g.st]);

  const reset = (idx = li) => {
    clearTimeout(lp.current.t);
    setLi(idx);
    setG({ sel: papanKosong(LEVEL[idx]), st: "siap", boom: -1 });
    setDetik(0);
    setSkor(0);
    setHi(bacaAngka(kunciHi(LEVEL[idx].id)));
  };

  const selesaiLangkah = (sel, st, boom) => {
    if (boom >= 0) {
      sel.forEach((x) => { if (x.m && !x.f) x.o = true; }); // tunjukkan semua ranjau
      setG({ sel, st: "kalah", boom });
      return;
    }
    const terbuka = sel.filter((x) => x.o).length;
    if (terbuka === sel.length - L.m) {
      sel.forEach((x) => { if (x.m) x.f = true; });
      const dt = Math.min(999, Math.floor((Date.now() - mulaiRef.current) / 1000));
      const sk = L.dasar + Math.max(0, L.par - dt) * L.k;
      setDetik(dt);
      setSkor(sk);
      if (sk > bacaAngka(kunciHi(L.id))) { simpanAngka(kunciHi(L.id), sk); setHi(sk); }
      setG({ sel, st: "menang", boom: -1 });
      laporRef.current?.({ score: sk, level: L.id });
      return;
    }
    setG({ sel, st, boom: -1 });
  };

  const buka = (i) => {
    const cur = gRef.current;
    if (cur.st === "menang" || cur.st === "kalah") return;
    const sel = cur.sel.map((x) => ({ ...x }));
    if (sel[i].o || sel[i].f) return;
    let st = cur.st;
    if (st === "siap") {
      pasangRanjau(sel, L, i);
      st = "main";
      mulaiRef.current = Date.now();
      setDetik(0);
    }
    selesaiLangkah(sel, st, bukaSel(sel, L, i));
  };

  const bendera = (i) => {
    const cur = gRef.current;
    if (cur.st === "menang" || cur.st === "kalah") return;
    if (cur.sel[i].o) return;
    const sel = cur.sel.map((x) => ({ ...x }));
    sel[i].f = !sel[i].f;
    setG({ sel, st: cur.st, boom: -1 });
  };

  // Ketuk angka yang jumlah benderanya sudah pas -> buka semua kotak di sekitarnya
  const chord = (i) => {
    const cur = gRef.current;
    if (cur.st !== "main") return;
    const x = cur.sel[i];
    if (!x.o || x.n === 0) return;
    const sekitar = tetangga(i, L.r, L.c);
    if (sekitar.filter((j) => cur.sel[j].f).length !== x.n) return;
    const sel = cur.sel.map((y) => ({ ...y }));
    let boom = -1;
    for (const j of sekitar) {
      if (sel[j].o || sel[j].f) continue;
      const b = bukaSel(sel, L, j);
      if (boom < 0) boom = b;
    }
    selesaiLangkah(sel, cur.st, boom);
  };

  const ketuk = (i) => {
    if (lp.current.fired) { lp.current.fired = false; return; } // sudah jadi bendera lewat tahan lama
    const x = gRef.current.sel[i];
    if (x.o) return chord(i);
    if (mode === "bendera") bendera(i);
    else buka(i);
  };

  const tekan = (e, i) => {
    clearTimeout(lp.current.t);
    lp.current.fired = false;
    if (e.pointerType === "mouse") {
      if (e.button === 2) bendera(i); // klik kanan
      return;
    }
    // layar sentuh: tahan ±0,35 detik = pasang/lepas bendera
    lp.current.t = setTimeout(() => { lp.current.fired = true; bendera(i); }, 350);
  };
  const lepas = () => clearTimeout(lp.current.t);

  useEffect(() => () => clearTimeout(lp.current.t), []);

  const sisa = L.m - g.sel.filter((x) => x.f).length;
  const aktif = g.st === "siap" || g.st === "main";

  return (
    <div className="mx-auto w-full max-w-[420px]">
      <style>{`
        @keyframes ms-buka { from { transform: scale(.8); opacity: .5; } to { transform: scale(1); opacity: 1; } }
        .ms-buka { animation: ms-buka .16s ease-out both; }
        @media (prefers-reduced-motion: reduce) { .ms-buka { animation: none; } }
      `}</style>

      <div className="grid grid-cols-3 gap-2">
        <Kotak label="RANJAU" bg="bg-yellow-300">
          <span className="inline-flex items-center justify-center gap-1"><Bomb size={18} strokeWidth={2.5} /> {sisa}</span>
        </Kotak>
        <Kotak label="WAKTU" bg="bg-sky-200">
          <span className="inline-flex items-center justify-center gap-1"><Clock size={18} strokeWidth={2.5} /> {detik}</span>
        </Kotak>
        <Kotak label="REKOR" bg="bg-green-200">{hi}</Kotak>
      </div>

      <TombolAtas onBack={onBack} onUlang={() => reset()} />

      <div className="mt-3">
        <Pilihan kecil opsi={LEVEL.map((l, n) => ({ id: n, label: l.nama }))} nilai={li} onPilih={(n) => reset(n)} />
      </div>

      {/* Papan */}
      <div className="mt-3 border-4 border-black bg-neutral-300 p-[2px] shadow-[6px_6px_0_#111]">
        <div
          className="grid gap-[2px]"
          style={{ gridTemplateColumns: `repeat(${L.c}, minmax(0, 1fr))`, touchAction: "manipulation", WebkitTouchCallout: "none", userSelect: "none" }}
          onContextMenu={(e) => e.preventDefault()}
        >
          {g.sel.map((x, i) => {
            let cls = `flex aspect-square select-none items-center justify-center font-comic leading-none ${L.huruf} `;
            if (!x.o) {
              cls += "bg-sky-200 shadow-[inset_-3px_-3px_0_rgba(0,0,0,.14),inset_3px_3px_0_rgba(255,255,255,.65)] ";
              if (aktif) cls += "cursor-pointer hover:bg-sky-300 active:bg-sky-400 ";
            } else if (x.m) {
              cls += `ms-buka ${i === g.boom ? "bg-rose-300" : "bg-white"} `;
            } else {
              cls += `ms-buka ${x.n === 0 ? "bg-neutral-100" : "bg-white"} `;
            }
            const salah = g.st === "kalah" && x.f && !x.m;
            return (
              <button
                key={i}
                type="button"
                className={cls}
                onClick={() => ketuk(i)}
                onPointerDown={(e) => tekan(e, i)}
                onPointerUp={lepas}
                onPointerLeave={lepas}
                onPointerCancel={lepas}
                aria-label={x.o ? (x.m ? "Ranjau" : x.n ? `Angka ${x.n}` : "Kosong") : x.f ? "Bendera" : "Tertutup"}
              >
                {x.o && x.m && <Bomb size={L.ikon} strokeWidth={2.5} color="#111" fill="#111" fillOpacity={0.15} />}
                {x.o && !x.m && x.n > 0 && <span style={{ color: WARNA[x.n] }}>{x.n}</span>}
                {!x.o && x.f && !salah && <Flag size={L.ikon} strokeWidth={2.5} color="#111" fill="#fb7185" />}
                {salah && <X size={L.ikon} strokeWidth={3} color="#dc2626" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Mode ketuk (untuk layar sentuh) */}
      <div className="mt-3 grid grid-cols-2 gap-2">
        <button type="button" onClick={() => setMode("buka")} aria-pressed={mode === "buka"} className={`btn inline-flex items-center justify-center gap-1 px-2 py-1 text-lg ${mode === "buka" ? "bg-yellow-300" : "bg-white"}`}>
          <MousePointerClick size={18} strokeWidth={2.5} /> BUKA
        </button>
        <button type="button" onClick={() => setMode("bendera")} aria-pressed={mode === "bendera"} className={`btn inline-flex items-center justify-center gap-1 px-2 py-1 text-lg ${mode === "bendera" ? "bg-yellow-300" : "bg-white"}`}>
          <Flag size={18} strokeWidth={2.5} /> BENDERA
        </button>
      </div>
      <p className="mt-2 font-body text-xs font-bold leading-snug text-neutral-600">
        Tahan sebuah kotak (atau klik kanan) untuk memasang bendera. Ketuk angka yang benderanya sudah pas untuk membuka kotak di sekitarnya. Klik pertama selalu aman.
      </p>

      {g.st === "menang" && (
        <div className="pop mt-3 border-[3px] border-black bg-green-200 p-3 text-center shadow-[4px_4px_0_#111]">
          <p className="font-comic text-3xl leading-none tracking-wide">BERHASIL!</p>
          <p className="mt-1 inline-flex items-center gap-1 font-comic text-xl tracking-wide"><Trophy size={18} strokeWidth={2.5} /> SKOR {skor} · {detik} DETIK</p>
          <InfoMasuk user={user} onLogin={onLogin} />
          <button onClick={() => reset()} className="btn mt-2 bg-yellow-300 px-4 py-1 text-xl">MAIN LAGI</button>
        </div>
      )}
      {g.st === "kalah" && (
        <div className="pop mt-3 border-[3px] border-black bg-rose-200 p-3 text-center shadow-[4px_4px_0_#111]">
          <p className="font-comic text-3xl leading-none tracking-wide">BOOM! KENA RANJAU</p>
          <p className="mt-1 font-body text-sm font-bold text-neutral-700">Coba lagi, pelan-pelan saja.</p>
          <button onClick={() => reset()} className="btn mt-2 bg-yellow-300 px-4 py-1 text-xl">COBA LAGI</button>
        </div>
      )}
      {g.st === "siap" && <InfoMasuk user={user} onLogin={onLogin} />}
    </div>
  );
}
