import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { Kotak, Overlay, TombolAtas, InfoMasuk, bacaAngka, simpanAngka } from "./gamekit";

// 2048 tanpa batas: geser untuk menggabungkan angka kembar, terus lanjut setelah 2048.
// Geser di papan (sentuh/mouse) atau pakai tombol panah / WASD.
const N = 4;
const KUNCI_HI = "telsaone:2048:hi";
const MAKS_SKOR = 1000000; // batas skor yang diterima server

const PALET = ["#ffffff", "#fef3c7", "#fde047", "#fdba74", "#fda4af", "#f9a8d4", "#bae6fd", "#7dd3fc", "#86efac", "#a5b4fc", "#facc15"];
const PALET_LANJUT = ["#c4b5fd", "#5eead4", "#fb923c", "#111111"];
const eksp = (v) => Math.round(Math.log2(v));
function warna(v) {
  const e = eksp(v);
  if (e <= PALET.length) return { bg: PALET[e - 1], fg: "#111" };
  const bg = PALET_LANJUT[(e - PALET.length - 1) % PALET_LANJUT.length];
  return { bg, fg: bg === "#111111" ? "#fde047" : "#111" };
}

let idTile = 1;
const baruId = () => idTile++;

function ubinBaru(tiles, sebelumnya) {
  const isi = new Set(tiles.filter((t) => !t.gone).map((t) => t.r * N + t.c));
  const kosong = [];
  for (let i = 0; i < N * N; i++) if (!isi.has(i)) kosong.push(i);
  if (!kosong.length) return null;
  const p = kosong[Math.floor(Math.random() * kosong.length)];
  return { id: baruId(), v: Math.random() < 0.9 ? 2 : 4, r: Math.floor(p / N), c: p % N, anim: "baru", gone: false, gt: sebelumnya };
}

function awalGame() {
  const a = ubinBaru([], 0);
  const b = ubinBaru([a], 0);
  return [a, b];
}

// Satu gerakan. Mengembalikan { tiles, gain, moved }.
// Dua ubin yang bergabung sama-sama meluncur ke tujuan (ditandai gone), lalu muncul ubin hasil gabungan baru.
function gerak(tiles, arah, gt) {
  const hidup = tiles.filter((t) => !t.gone);
  const horizontal = arah === "kiri" || arah === "kanan";
  const maju = arah === "kiri" || arah === "atas"; // mengisi dari indeks 0
  const out = [];
  let gain = 0, moved = false;

  for (let k = 0; k < N; k++) {
    const garis = hidup
      .filter((t) => (horizontal ? t.r === k : t.c === k))
      .sort((a, b) => {
        const d = horizontal ? a.c - b.c : a.r - b.r;
        return maju ? d : -d;
      });
    let pos = 0;
    let last = null; // { tile, v, pos, merged }
    const koord = (p) => {
      const idx = maju ? p : N - 1 - p;
      return horizontal ? { r: k, c: idx } : { r: idx, c: k };
    };
    for (const t of garis) {
      if (last && !last.merged && last.v === t.v) {
        const { r, c } = koord(last.pos);
        last.tile.gone = true; last.tile.gt = gt;
        out.push({ ...t, r, c, gone: true, gt });
        const m = { id: baruId(), v: t.v * 2, r, c, anim: "gabung", gone: false, gt };
        out.push(m);
        gain += m.v;
        moved = true;
        last = { tile: m, v: m.v, pos: last.pos, merged: true };
      } else {
        const { r, c } = koord(pos);
        if (r !== t.r || c !== t.c) moved = true;
        const placed = { ...t, r, c };
        out.push(placed);
        last = { tile: placed, v: t.v, pos, merged: false };
        pos += 1;
      }
    }
  }
  return { tiles: out, gain, moved };
}

function bisaGerak(tiles) {
  const hidup = tiles.filter((t) => !t.gone);
  if (hidup.length < N * N) return true;
  const g = Array.from({ length: N }, () => Array(N).fill(0));
  hidup.forEach((t) => { g[t.r][t.c] = t.v; });
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    if (c + 1 < N && g[r][c] === g[r][c + 1]) return true;
    if (r + 1 < N && g[r][c] === g[r + 1][c]) return true;
  }
  return false;
}

export default function Game2048({ onBack, user, onLogin, onSelesai }) {
  const [tiles, setTiles] = useState(awalGame);
  const [skor, setSkor] = useState(0);
  const [hi, setHi] = useState(() => bacaAngka(KUNCI_HI));
  const [tamat, setTamat] = useState(false);
  const [plus, setPlus] = useState(null); // { v, k } animasi +poin
  const [info, setInfo] = useState("");
  const [bw, setBw] = useState(320);
  const boardRef = useRef(null);
  const swipe = useRef(null);
  const moveId = useRef(0);
  const dikirim = useRef(false);
  const dicapai2048 = useRef(false);
  const timers = useRef([]);
  const tunda = (fn, ms) => { timers.current.push(setTimeout(fn, ms)); };

  const tilesRef = useRef(tiles); tilesRef.current = tiles;
  const skorRef = useRef(0); skorRef.current = skor;
  const tamatRef = useRef(false); tamatRef.current = tamat;
  const laporRef = useRef(onSelesai); laporRef.current = onSelesai;

  // Ukuran papan -> posisi ubin dihitung dalam piksel agar geserannya mulus
  useLayoutEffect(() => {
    const el = boardRef.current;
    if (!el) return undefined;
    const ukur = () => setBw(el.clientWidth || 320);
    ukur();
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(ukur) : null;
    ro?.observe(el);
    window.addEventListener("resize", ukur);
    return () => { ro?.disconnect(); window.removeEventListener("resize", ukur); };
  }, []);

  const lapor = useCallback(() => {
    if (dikirim.current || skorRef.current <= 0) return;
    dikirim.current = true;
    const maks = Math.max(2, ...tilesRef.current.filter((t) => !t.gone).map((t) => t.v));
    laporRef.current?.({ score: Math.min(skorRef.current, MAKS_SKOR), level: Math.max(1, eksp(maks)) });
  }, []);

  // Keluar halaman = skor terakhir tetap terkirim
  useEffect(() => () => { lapor(); timers.current.forEach(clearTimeout); }, [lapor]);

  const arahRef = useCallback((arah) => {
    if (tamatRef.current) return;
    const id = ++moveId.current;
    const hasil = gerak(tilesRef.current, arah, id);
    if (!hasil.moved) return;
    const baru = ubinBaru(hasil.tiles, id);
    const daftar = baru ? [...hasil.tiles, baru] : hasil.tiles;
    tilesRef.current = daftar;
    setTiles(daftar);
    if (hasil.gain) {
      const total = skorRef.current + hasil.gain;
      skorRef.current = total;
      setSkor(total);
      setPlus({ v: hasil.gain, k: id });
      if (total > bacaAngka(KUNCI_HI)) { simpanAngka(KUNCI_HI, total); setHi(total); }
      if (!dicapai2048.current && daftar.some((t) => !t.gone && t.v >= 2048)) {
        dicapai2048.current = true;
        setInfo("2048 tercapai! Lanjut terus, tidak ada batasnya.");
        tunda(() => setInfo(""), 3200);
      }
    }
    // buang ubin "bayangan" yang sudah menyatu setelah animasi selesai
    tunda(() => setTiles((l) => { const n = l.filter((t) => !(t.gone && t.gt <= id)); tilesRef.current = n; return n; }), 170);
    if (!bisaGerak(daftar)) { setTamat(true); tamatRef.current = true; tunda(lapor, 0); }
  }, [lapor]);

  // Keyboard
  useEffect(() => {
    const PETA = { ArrowLeft: "kiri", ArrowRight: "kanan", ArrowUp: "atas", ArrowDown: "bawah", a: "kiri", d: "kanan", w: "atas", s: "bawah", A: "kiri", D: "kanan", W: "atas", S: "bawah" };
    const onKey = (e) => {
      const tag = e.target?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || e.ctrlKey || e.metaKey || e.altKey) return;
      const a = PETA[e.key];
      if (!a) return;
      e.preventDefault();
      arahRef(a);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [arahRef]);

  // Geser di papan
  const onDown = (e) => {
    swipe.current = { x: e.clientX, y: e.clientY };
    try { e.currentTarget.setPointerCapture?.(e.pointerId); } catch { /* abaikan */ }
  };
  const onUp = (e) => {
    const s = swipe.current;
    swipe.current = null;
    if (!s) return;
    const dx = e.clientX - s.x, dy = e.clientY - s.y;
    if (Math.max(Math.abs(dx), Math.abs(dy)) < 24) return;
    if (Math.abs(dx) > Math.abs(dy)) arahRef(dx > 0 ? "kanan" : "kiri");
    else arahRef(dy > 0 ? "bawah" : "atas");
  };

  const ulang = () => {
    lapor();
    dikirim.current = false;
    dicapai2048.current = false;
    const a = awalGame();
    tilesRef.current = a; skorRef.current = 0; tamatRef.current = false;
    setTiles(a); setSkor(0); setTamat(false); setPlus(null); setInfo("");
  };

  const keluar = () => { lapor(); onBack?.(); };

  const gap = Math.round(bw * 0.028);
  const sel = (bw - gap * (N + 1)) / N;
  const pos = (n) => gap + n * (sel + gap);
  const maksTile = Math.max(2, ...tiles.filter((t) => !t.gone).map((t) => t.v));

  return (
    <div className="mx-auto w-full max-w-[420px]">
      <style>{`
        @keyframes g48-baru { from { transform: scale(0); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        @keyframes g48-gabung { 0% { transform: scale(.6); opacity: 0; } 55% { transform: scale(1.14); opacity: 1; } 100% { transform: scale(1); opacity: 1; } }
        @keyframes g48-plus { from { transform: translateY(0); opacity: 1; } to { transform: translateY(-22px); opacity: 0; } }
        .g48-baru { animation: g48-baru .18s ease-out .1s both; }
        .g48-gabung { animation: g48-gabung .2s ease-out .1s both; }
        .g48-plus { animation: g48-plus .6s ease-out forwards; }
        @media (prefers-reduced-motion: reduce) { .g48-baru, .g48-gabung, .g48-plus { animation: none; } }
      `}</style>

      <div className="grid grid-cols-3 gap-2">
        <div className="relative">
          <Kotak label="SKOR" bg="bg-yellow-300">{skor}</Kotak>
          {plus && <span key={plus.k} className="g48-plus pointer-events-none absolute right-2 top-0 font-comic text-lg text-green-700">+{plus.v}</span>}
        </div>
        <Kotak label="REKOR" bg="bg-sky-200">{Math.max(hi, skor)}</Kotak>
        <Kotak label="TERBESAR" bg="bg-pink-200">{maksTile}</Kotak>
      </div>

      <TombolAtas onBack={keluar} onUlang={ulang} />

      <div
        ref={boardRef}
        className="relative mt-4 aspect-square w-full select-none border-4 border-black bg-neutral-300 shadow-[6px_6px_0_#111]"
        style={{ touchAction: "none", boxSizing: "border-box" }}
        onPointerDown={onDown}
        onPointerUp={onUp}
        onPointerCancel={() => { swipe.current = null; }}
        aria-label="Papan 2048"
      >
        {/* petak kosong */}
        {Array.from({ length: N * N }, (_, i) => (
          <div
            key={i}
            className="absolute bg-neutral-200"
            style={{ width: sel, height: sel, left: pos(i % N), top: pos(Math.floor(i / N)), borderRadius: 8 }}
          />
        ))}

        {/* ubin */}
        {tiles.map((t) => {
          const { bg, fg } = warna(t.v);
          const digit = String(t.v).length;
          const fs = sel * (digit <= 2 ? 0.52 : digit === 3 ? 0.42 : digit === 4 ? 0.34 : digit === 5 ? 0.28 : 0.23);
          return (
            <div
              key={t.id}
              className="absolute left-0 top-0"
              style={{ width: sel, height: sel, transform: `translate(${pos(t.c)}px, ${pos(t.r)}px)`, transition: "transform 120ms ease-out", zIndex: t.anim === "gabung" ? 2 : 1, willChange: "transform" }}
            >
              <div
                className={`flex h-full w-full items-center justify-center font-comic leading-none tracking-wide ${t.anim === "baru" ? "g48-baru" : t.anim === "gabung" ? "g48-gabung" : ""}`}
                style={{ background: bg, color: fg, fontSize: fs, border: "2px solid #111", borderRadius: 8 }}
              >
                {t.v}
              </div>
            </div>
          );
        })}

        {tamat && (
          <Overlay lebar={250}>
            <h2 className="font-comic text-4xl leading-none tracking-wide text-rose-500" style={{ WebkitTextStroke: "1.5px #111" }}>GAME OVER</h2>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Kotak label="SKOR" bg="bg-yellow-300">{skor}</Kotak>
              <Kotak label="TERBESAR" bg="bg-pink-200">{maksTile}</Kotak>
            </div>
            {skor >= hi && skor > 0 && (
              <div className="mx-auto mt-2 inline-block -rotate-2 border-[3px] border-black bg-yellow-300 px-2 font-comic text-lg tracking-wider shadow-[2px_2px_0_#111]">REKOR BARU!</div>
            )}
            <InfoMasuk user={user} onLogin={onLogin} />
            <button onClick={ulang} className="btn mt-3 w-full bg-yellow-300 px-4 py-2 text-2xl">MAIN LAGI</button>
          </Overlay>
        )}
      </div>

      {info && <p className="pop mt-3 border-[3px] border-black bg-yellow-200 px-2 py-1 text-center font-comic text-lg tracking-wide shadow-[3px_3px_0_#111]">{info}</p>}
      <p className="mt-3 font-body text-xs font-bold leading-snug text-neutral-600">
        Geser papan (atau pakai tombol panah / WASD). Angka yang sama akan menyatu. Tidak ada batas angka tertinggi.
      </p>
    </div>
  );
}
