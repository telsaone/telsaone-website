import { useEffect, useState } from "react";
import { useContent } from "../lib/content";
import { Sisip } from "../lib/sisip";
import { Eye, EyeOff, Github } from "lucide-react";
import { pakaiEmail } from "../lib/provider";
import { supabase } from "../lib/supabase";
import { GoogleIcon } from "./Icons";

const redirect = () => window.location.origin + window.location.pathname;

const pesan = (m = "") => {
  if (/invalid login credentials/i.test(m)) return "Email atau password salah. Belum punya akun? Pilih DAFTAR dulu.";
  if (/email not confirmed/i.test(m)) return "Email belum dikonfirmasi. Cek inbox Anda.";
  if (/already registered|already been registered/i.test(m)) return "Email sudah terdaftar. Silakan masuk.";
  if (/rate limit|too many|seconds/i.test(m)) return "Terlalu banyak percobaan. Tunggu sebentar lalu coba lagi.";
  if (/password should be|weak/i.test(m)) return "Password terlalu lemah. Minimal 6 karakter.";
  if (/token has expired|invalid|expired/i.test(m)) return "Kode salah atau sudah kedaluwarsa.";
  return m;
};

const input = "w-full border-[3px] border-black bg-white px-3 py-2 font-body font-bold outline-none transition-shadow focus:shadow-[4px_4px_0_#111]";

export default function LoginModal({ mode: awal = "masuk", onClose, onToast }) {
  const { teks } = useContent();
  const [mode, setMode] = useState(awal);
  const [nama, setNama] = useState("");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [pass2, setPass2] = useState("");
  const [kode, setKode] = useState("");
  const [lihat, setLihat] = useState(false);
  const [busy, setBusy] = useState(false);
  const [tunggu, setTunggu] = useState(0);
  const [terverifikasi, setTerverifikasi] = useState(false); // kode reset sudah dipakai

  useEffect(() => {
    if (tunggu <= 0) return;
    const t = setTimeout(() => setTunggu((n) => n - 1), 1000);
    return () => clearTimeout(t);
  }, [tunggu]);

  const tutup = async () => {
    if (terverifikasi) await supabase?.auth.signOut(); // kode benar tapi password belum diganti
    onClose();
  };
  const need = () => onToast("Isi VITE_SUPABASE_URL dan VITE_SUPABASE_ANON_KEY di file .env terlebih dahulu.");
  const pindah = (m) => { setMode(m); setPass(""); setPass2(""); setKode(""); setLihat(false); setTerverifikasi(false); };

  // Reset password hanya untuk akun dengan login email; akun Google/GitHub tidak punya password
  const userEmail = async () => pakaiEmail((await supabase.auth.getUser()).data?.user);
  const tolakNonEmail = async () => {
    await supabase.auth.signOut();
    onToast("Akun ini masuk lewat Google/GitHub, jadi tidak ada reset password. Masuk dengan tombol Google/GitHub.");
    onClose();
  };

  const oauth = async (provider) => {
    if (!supabase) return need();
    const { error } = await supabase.auth.signInWithOAuth({ provider, options: { redirectTo: redirect() } });
    if (error) onToast(pesan(error.message));
  };

  const kirimUlang = async () => {
    if (tunggu > 0 || !supabase) return;
    const { error } = mode === "verifikasi"
      ? await supabase.auth.resend({ type: "signup", email })
      : await supabase.auth.resetPasswordForEmail(email);
    if (error) onToast(pesan(error.message));
    else { onToast("Kode baru dikirim ke email Anda."); setTunggu(60); }
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!supabase) return need();
    const butuhPass = ["daftar", "reset"].includes(mode) || (mode === "kode" && terverifikasi);
    if (butuhPass && pass.length < 6) return onToast("Password minimal 6 karakter.");
    if (butuhPass && pass !== pass2) return onToast("Konfirmasi password tidak sama.");
    if (mode === "daftar" && !nama.trim()) return onToast("Nama wajib diisi.");
    if ((mode === "verifikasi" || mode === "kode") && !kode.trim() && !terverifikasi) return onToast("Masukkan kode dari email Anda.");

    setBusy(true);
    try {
      if (mode === "masuk") {
        const { error } = await supabase.auth.signInWithPassword({ email, password: pass });
        if (error) return onToast(pesan(error.message));
        onToast(teks.login_toast_masuk);
        onClose();
      } else if (mode === "daftar") {
        const { data, error } = await supabase.auth.signUp({
          email, password: pass,
          options: { data: { full_name: nama.trim() }, emailRedirectTo: redirect() },
        });
        if (error) return onToast(pesan(error.message));
        if (data.user && data.user.identities?.length === 0) { onToast("Email sudah terdaftar. Silakan masuk."); return pindah("masuk"); }
        if (!data.session) { onToast("Kode konfirmasi dikirim ke email Anda."); setTunggu(60); return pindah("verifikasi"); }
        onToast(teks.login_toast_daftar);
        onClose();
      } else if (mode === "verifikasi") {
        const { error } = await supabase.auth.verifyOtp({ email, token: kode.trim(), type: "signup" });
        if (error) return onToast(pesan(error.message));
        onToast(teks.login_toast_konfirmasi);
        onClose();
      } else if (mode === "lupa") {
        const { error } = await supabase.auth.resetPasswordForEmail(email);
        if (error) return onToast(pesan(error.message));
        onToast("Jika email terdaftar, kode dikirim. Cek email Anda.");
        setTunggu(60);
        pindah("kode");
      } else if (mode === "kode") {
        if (!terverifikasi) {
          // Langkah 1: kode harus benar dulu. Kalau salah, form password tidak muncul.
          const { data, error } = await supabase.auth.verifyOtp({ email, token: kode.trim(), type: "recovery" });
          if (error) return onToast(pesan(error.message));
          if (!pakaiEmail(data?.user)) return await tolakNonEmail();
          setTerverifikasi(true);
          return onToast(teks.login_kode_benar);
        }
        if (!(await userEmail())) return await tolakNonEmail();
        const { error } = await supabase.auth.updateUser({ password: pass });
        if (error) return onToast(pesan(error.message));
        onToast(teks.login_toast_password);
        onClose();
      } else if (mode === "reset") {
        // untuk tautan reset lama (PASSWORD_RECOVERY)
        if (!(await userEmail())) return await tolakNonEmail();
        const { error } = await supabase.auth.updateUser({ password: pass });
        if (error) return onToast(pesan(error.message));
        onToast(teks.login_toast_password);
        onClose();
      }
    } catch (err) {
      onToast("Terjadi kesalahan: " + err.message);
    } finally {
      setBusy(false);
    }
  };

  const tab = (m, label) => (
    <button type="button" onClick={() => pindah(m)} className={`btn flex-1 py-1 text-xl ${mode === m ? "bg-yellow-300" : "bg-white"}`}>{label}</button>
  );

  const passField = (value, set, ph) => (
    <div className="relative">
      <input value={value} onChange={(e) => set(e.target.value)} type={lihat ? "text" : "password"} placeholder={ph}
        autoComplete={mode === "masuk" ? "current-password" : "new-password"} className={input + " pr-11"} />
      <button type="button" onClick={() => setLihat(!lihat)} aria-label="Tampilkan password"
        className="absolute right-2 top-1/2 -translate-y-1/2">{lihat ? <EyeOff size={20} strokeWidth={2.5} /> : <Eye size={20} strokeWidth={2.5} />}</button>
    </div>
  );

  const auth = mode === "masuk" || mode === "daftar";
  const pakaiKode = mode === "verifikasi" || mode === "kode";
  const link = "w-full text-center font-body text-sm font-bold underline";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/50 p-4" onClick={tutup}>
      <div className="panel pop my-auto w-full max-w-sm p-6" style={{ transform: "none" }} onClick={(e) => e.stopPropagation()}>
        <h3 className="font-comic text-4xl tracking-wide">{teks["login_judul_" + mode]}</h3>

        {auth && <div className="mt-4 flex gap-3">{tab("masuk", teks.login_tab_masuk)}{tab("daftar", teks.login_tab_daftar)}</div>}
        {mode === "lupa" && <p className="mt-2 font-body font-bold text-neutral-600">{teks.login_info_lupa}</p>}
        {pakaiKode && !terverifikasi && <p className="mt-2 font-body font-bold text-neutral-600"><Sisip teks={teks.login_info_kode} nilai={{ email: <span className="break-all text-black">{email}</span> }} /></p>}
        {mode === "lupa" && <p className="mt-2 font-body text-sm font-bold text-neutral-600">{teks.login_info_oauth}</p>}
        {mode === "kode" && terverifikasi && <p className="mt-2 font-body font-bold text-green-700">{teks.login_kode_benar}</p>}

        <form onSubmit={submit} className="mt-4 space-y-3">
          {mode === "daftar" && <input value={nama} onChange={(e) => setNama(e.target.value)} placeholder={teks.login_ph_nama} autoComplete="name" className={input} />}
          {(auth || mode === "lupa") && <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required placeholder={teks.login_ph_email} autoComplete="email" className={input} />}
          {pakaiKode && !terverifikasi && (
            <input value={kode} onChange={(e) => setKode(e.target.value.replace(/\D/g, ""))} inputMode="numeric" maxLength={10} autoComplete="one-time-code"
              placeholder={teks.login_ph_kode} className={input + " text-center font-comic text-2xl tracking-[.3em]"} />
          )}
          {(auth || mode === "reset" || (mode === "kode" && terverifikasi)) && passField(pass, setPass, mode === "reset" || mode === "kode" ? "Password baru" : "Password")}
          {(mode === "daftar" || mode === "reset" || (mode === "kode" && terverifikasi)) && passField(pass2, setPass2, "Ulangi password")}

          <button type="submit" disabled={busy} className="btn w-full bg-yellow-300 py-2 text-xl disabled:opacity-60">{busy ? teks.login_tunggu : mode === "kode" && !terverifikasi ? teks.login_tombol_verifikasi_kode : teks["login_tombol_" + mode]}</button>

          {mode === "masuk" && <button type="button" onClick={() => pindah("lupa")} className={link}>{teks.login_lupa}</button>}
          {pakaiKode && !terverifikasi && (
            <button type="button" onClick={kirimUlang} disabled={tunggu > 0} className={link + " disabled:no-underline disabled:opacity-60"}>
              {tunggu > 0 ? `Kirim ulang kode (${tunggu}d)` : "Kirim ulang kode"}
            </button>
          )}
          {(mode === "lupa" || pakaiKode) && <button type="button" onClick={() => pindah("masuk")} className={link}>{teks.login_kembali}</button>}
        </form>

        {auth && (
          <div className="mt-4 space-y-3">
            <div className="flex items-center gap-2 font-comic tracking-wide"><span className="h-[3px] flex-1 bg-black" />{teks.login_atau}<span className="h-[3px] flex-1 bg-black" /></div>
            <button onClick={() => oauth("google")} className="btn flex w-full items-center justify-center gap-2 bg-white py-2 text-xl"><GoogleIcon size={22} /> {mode === "masuk" ? teks.login_google_masuk : teks.login_google_daftar}</button>
            <button onClick={() => oauth("github")} className="btn flex w-full items-center justify-center gap-2 bg-neutral-100 py-2 text-xl"><Github size={22} strokeWidth={2.5} /> {mode === "masuk" ? teks.login_github_masuk : teks.login_github_daftar}</button>
          </div>
        )}

        <button onClick={tutup} className="mt-4 w-full font-comic text-lg tracking-wide underline">{teks.login_tutup}</button>
      </div>
    </div>
  );
}
