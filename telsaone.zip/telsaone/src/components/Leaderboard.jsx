import { useCallback, useEffect, useState } from "react";
import { Crown, Gift, Medal, RefreshCw, Star, Trophy, Zap } from "lucide-react";
import { ambilPeringkat } from "../lib/games";
import { ambilJuara } from "../lib/hadiah";
import { useContent } from "../lib/content";
import Avatar from "./Avatar";

const jadiUser = (p) => ({
  user_metadata: { full_name: p?.nama, avatar_icon: p?.avatar_icon, avatar_bg: p?.avatar_bg, avatar_url: p?.avatar_url },
});

// Bentuk ledakan komik (burst) untuk lencana peringkat
const BURST = (() => {
  const n = 12;
  const pts = [];
  for (let i = 0; i < n * 2; i++) {
    const a = (Math.PI * i) / n;
    const r = i % 2 ? 38 : 50;
    pts.push(`${(50 + r * Math.cos(a)).toFixed(1)}% ${(50 + r * Math.sin(a)).toFixed(1)}%`);
  }
  return `polygon(${pts.join(",")})`;
})();

const PODIUM = [
  { bg: "bg-yellow-200", warna: "#fde047", Ikon: Crown, seru: "JUARA!" },
  { bg: "bg-zinc-100", warna: "#e4e4e7", Ikon: Medal, seru: "WOW!" },
  { bg: "bg-orange-100", warna: "#fdba74", Ikon: Medal, seru: "KEREN!" },
];

function Lencana({ n }) {
  const p = PODIUM[n - 1];
  if (!p)
    return (
      <div className="flex h-9 w-9 shrink-0 items-center justify-center border-[3px] border-black bg-white font-comic text-lg leading-none">{n}</div>
    );
  const Ikon = p.Ikon;
  return (
    <div className="relative h-12 w-12 shrink-0">
      <div className="absolute inset-0 bg-black" style={{ clipPath: BURST }} />
      <div className="absolute inset-[2.5px] flex items-center justify-center" style={{ clipPath: BURST, background: p.warna }}>
        <Ikon size={20} strokeWidth={2.5} />
      </div>
    </div>
  );
}

export default function Leaderboard({ gameId, user, refreshKey = 0 }) {
  const [rows, setRows] = useState(null);
  const [galat, setGalat] = useState(false);
  const [juara, setJuara] = useState(null);
  const [, setDetik] = useState(0);
  const { kaget, teks } = useContent();

  const muat = useCallback(async () => {
    const [{ rows: r, error }, j] = await Promise.all([ambilPeringkat(gameId), ambilJuara(gameId)]);
    setGalat(!!error);
    setRows(error ? [] : r);
    setJuara(j);
  }, [gameId]);

  useEffect(() => { const t = setInterval(() => setDetik((n) => n + 1), 30000); return () => clearInterval(t); }, []);

  useEffect(() => { setRows(null); muat(); }, [muat, refreshKey]);

  // Hitung mundur hadiah Dana Kaget untuk juara 1 (hanya jika sinkron dengan papan)
  const sisaMs = juara && rows?.[0]?.user_id === juara.user_id && kaget?.aktif
    ? new Date(juara.sejak).getTime() + kaget.jam * 3600000 - Date.now()
    : null;
  const teksSisa = (ms) => {
    const m = Math.max(0, Math.ceil(ms / 60000));
    return `${Math.floor(m / 60)} JAM ${m % 60} MNT`;
  };

  const saya = rows && user ? rows.findIndex((r) => r.user_id === user.id) : -1;

  return (
    <div className="relative mx-auto mt-8 w-full max-w-xl">
      {/* hiasan komik */}
      <Star size={34} strokeWidth={2.5} fill="#fde047" className="float absolute -left-3 -top-5 z-10 -rotate-12" />
      <Zap size={30} strokeWidth={2.5} fill="#7dd3fc" className="float absolute -right-2 top-10 z-10 rotate-12" />
      <Star size={22} strokeWidth={2.5} fill="#f9a8d4" className="float absolute -right-3 -top-3 z-10 rotate-12" />

      <div className="relative border-4 border-black bg-yellow-300 px-4 py-3 shadow-[6px_6px_0_#111]">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="flex items-center gap-2 font-comic text-3xl leading-none tracking-wide">
            <Trophy size={28} strokeWidth={2.5} /> {teks.lb_judul}
          </h3>
          <span className="-rotate-3 border-[3px] border-black bg-pink-300 px-2 font-comic tracking-wider shadow-[2px_2px_0_#111]">{teks.lb_badge}</span>
        </div>
        <p className="mt-1 font-body text-sm font-bold">{teks.lb_info}</p>
        {sisaMs !== null && (
          <p className="mt-2 flex items-start gap-1.5 border-[3px] border-black bg-white px-2 py-1 font-body text-sm font-bold shadow-[2px_2px_0_#111]">
            <Gift size={18} strokeWidth={2.5} className="mt-0.5 shrink-0" />
            <span>
              {juara.hadiah_diberikan
                ? `Hadiah Dana Kaget sudah diberikan ke ${juara.profiles?.nama || "juara"}.` +
                  (kaget.reset_juara && !kaget.tahan_permanen && juara.reset_at && new Date(juara.reset_at).getTime() > Date.now()
                    ? ` Tetap di papan ${teksSisa(new Date(juara.reset_at).getTime() - Date.now())} lagi, lalu ronde baru dimulai. Rebut puncaknya!`
                    : " Rebut puncak untuk ronde berikutnya!")
                : sisaMs > 0
                  ? `Bertahan di peringkat 1 selama ${kaget.jam} jam tanpa tergeser = Dana Kaget! ${juara.profiles?.nama || "Juara"} tinggal ${teksSisa(sisaMs)} lagi.`
                  : `${juara.profiles?.nama || "Juara"} sudah bertahan ${kaget.jam} jam, hadiah segera dikirim!`}
            </span>
          </p>
        )}
      </div>

      <div
        className="border-4 border-t-0 border-black p-3 shadow-[6px_6px_0_#111]"
        style={{ backgroundColor: "#fff7d6", backgroundImage: "radial-gradient(#f9a8d4 1.2px, transparent 1.2px)", backgroundSize: "12px 12px" }}
      >
        {rows === null ? (
          <p className="py-10 text-center font-comic text-2xl tracking-wide">{teks.memuat}</p>
        ) : galat ? (
          <div className="border-[3px] border-dashed border-black bg-white p-6 text-center">
            <p className="font-comic text-2xl tracking-wide">{teks.lb_belum_aktif_judul}</p>
            <p className="font-body text-sm font-bold text-neutral-600">{teks.lb_belum_aktif_pesan}</p>
          </div>
        ) : rows.length === 0 ? (
          <div className="border-[3px] border-dashed border-black bg-white p-6 text-center">
            <div className="float mx-auto flex h-16 w-16 items-center justify-center rounded-full border-4 border-black bg-yellow-300 shadow-[3px_3px_0_#111]">
              <Crown size={30} strokeWidth={2.5} />
            </div>
            <p className="mt-3 font-comic text-3xl tracking-wide">{teks.lb_kosong_judul}</p>
            <p className="font-body text-sm font-bold text-neutral-600">{teks.lb_kosong_pesan}</p>
          </div>
        ) : (
          <ol className="papan-scroll max-h-[28rem] space-y-2.5 overflow-y-auto py-1 pl-1 pr-2.5">
            {rows.map((r, i) => {
              const n = i + 1;
              const p = PODIUM[i];
              const aku = i === saya;
              return (
                <li
                  key={r.user_id}
                  className={`relative flex items-center gap-2 border-[3px] border-black px-2 py-1.5 shadow-[3px_3px_0_#111] ${aku ? "bg-sky-200" : p ? p.bg : "bg-white"}`}
                >
                  <Lencana n={n} />
                  <Avatar user={jadiUser(r.profiles)} size={n === 1 ? 48 : 40} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-comic text-xl leading-tight tracking-wide">
                      {r.profiles?.nama || "Pengguna"}
                      {aku && <span className="ml-1.5 border-2 border-black bg-pink-300 px-1 align-middle font-comic text-xs tracking-wider">{teks.lb_kamu}</span>}
                    </p>
                    <p className="font-body text-xs font-bold text-neutral-600">LV {r.level} · {r.plays}x main</p>
                  </div>
                  <p className="font-comic text-3xl leading-none tracking-wide">{r.skor}</p>
                  {p && (
                    <span className={`absolute -top-3 right-3 border-2 border-black bg-white px-1.5 font-comic text-sm tracking-wider shadow-[2px_2px_0_#111] ${i === 1 ? "rotate-3" : "-rotate-3"}`}>
                      {p.seru}
                    </span>
                  )}
                </li>
              );
            })}
          </ol>
        )}

        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <span className="font-comic text-lg tracking-wide">
            {saya >= 0 ? teks.lb_peringkatmu.replace("{n}", saya + 1) : user ? teks.lb_main : teks.lb_masuk}
          </span>
          <button onClick={muat} className="btn inline-flex items-center gap-1 bg-sky-200 px-3 py-0.5 text-base" aria-label="Muat ulang peringkat">
            <RefreshCw size={16} strokeWidth={2.5} /> {teks.lb_segarkan}
          </button>
        </div>
      </div>
    </div>
  );
}
