import { useRef, useState } from "react";
import { Infinity as IkonTakHingga } from "lucide-react";

// jam: 0 = permanen (tanpa batas)
export const LANGKAH = [
  { jam: 1, label: "1 J", teks: "1 JAM" },
  { jam: 6, label: "6 J", teks: "6 JAM" },
  { jam: 12, label: "12 J", teks: "12 JAM" },
  { jam: 24, label: "24 J", teks: "24 JAM" },
  { jam: 72, label: "3 HR", teks: "3 HARI" },
  { jam: 168, label: "7 HR", teks: "7 HARI" },
  { jam: 0, label: "∞", teks: "PERMANEN" },
];
export const INDEKS_24J = 3;

// Indeks langkah yang paling dekat dengan sisa waktu story (null = permanen)
export const indeksDari = (sisaMs) => {
  if (sisaMs === null) return LANGKAH.length - 1;
  const j = Math.max(1, sisaMs / 3600000);
  let b = 0;
  LANGKAH.slice(0, -1).forEach((l, n) => { if (Math.abs(l.jam - j) < Math.abs(LANGKAH[b].jam - j)) b = n; });
  return b;
};

// Slider geser dengan titik-titik berhenti. Titik terakhir = permanen, ditandai ikon infinity.
export default function DurasiGeser({ nilai, onUbah, onSelesai, disabled = false }) {
  const trek = useRef(null);
  const aktif = useRef(false); // sedang menekan/menggeser (ref supaya ketukan cepat tetap terbaca)
  const terakhir = useRef(nilai); // pilihan paling baru (state bisa belum ter-render saat jari dilepas)
  const [tarik, setTarik] = useState(false);
  const akhir = LANGKAH.length - 1;
  const pos = (n) => `${(n / akhir) * 100}%`;
  const permanen = LANGKAH[nilai].jam === 0;

  const dariX = (x) => {
    const r = trek.current.getBoundingClientRect();
    const f = Math.min(1, Math.max(0, (x - r.left) / r.width));
    const n = Math.round(f * akhir);
    terakhir.current = n;
    if (n !== nilai) onUbah(n);
  };
  const turun = (e) => {
    if (disabled) return;
    e.preventDefault();
    e.currentTarget.setPointerCapture?.(e.pointerId);
    aktif.current = true;
    setTarik(true);
    dariX(e.clientX);
  };
  const gerak = (e) => { if (tarik && !disabled) dariX(e.clientX); };
  const lepas = () => { if (!aktif.current) return; aktif.current = false; setTarik(false); onSelesai?.(terakhir.current); };
  const tombol = (e) => {
    if (disabled) return;
    const ke = (n) => { terakhir.current = n; onUbah(n); };
    if (e.key === "ArrowRight" || e.key === "ArrowUp") { e.preventDefault(); ke(Math.min(akhir, nilai + 1)); }
    else if (e.key === "ArrowLeft" || e.key === "ArrowDown") { e.preventDefault(); ke(Math.max(0, nilai - 1)); }
    else if (e.key === "Home") { e.preventDefault(); ke(0); }
    else if (e.key === "End") { e.preventDefault(); ke(akhir); }
    else if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onSelesai?.(nilai); }
  };

  return (
    <div className={disabled ? "opacity-60" : ""}>
      {/* Angka besar */}
      <div className="flex h-14 items-center justify-center" aria-live="polite">
        <span key={nilai} className="pop inline-flex items-center gap-2 border-[3px] border-black px-4 py-1 font-comic text-3xl tracking-wide shadow-[4px_4px_0_#111]"
          style={{ background: permanen ? "linear-gradient(120deg,#f9a8d4,#fde047,#7dd3fc)" : "#fde047", transform: "rotate(-1.5deg)" }}>
          {permanen && <IkonTakHingga size={30} strokeWidth={3.5} />}
          {LANGKAH[nilai].teks}
        </span>
      </div>

      {/* Treknya */}
      <div className="px-5 pt-5">
        <div ref={trek} role="slider" tabIndex={disabled ? -1 : 0} aria-label="Durasi story" aria-valuemin={0} aria-valuemax={akhir}
          aria-valuenow={nilai} aria-valuetext={LANGKAH[nilai].teks} onKeyDown={tombol}
          onPointerDown={turun} onPointerMove={gerak} onPointerUp={lepas} onPointerCancel={lepas}
          className="relative h-3 cursor-pointer touch-none select-none rounded-full border-[3px] border-black bg-white outline-none focus-visible:ring-4 focus-visible:ring-sky-300">
          {/* Isi */}
          <div className="absolute inset-y-0 left-0 rounded-full"
            style={{ width: pos(nilai), background: permanen ? "linear-gradient(90deg,#fde047,#f9a8d4,#7dd3fc)" : "#fde047", transition: tarik ? "none" : "width .2s ease" }} />
          {/* Titik-titik berhenti */}
          {LANGKAH.map((l, n) => (
            <span key={n} className="absolute top-1/2 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-black"
              style={{ left: pos(n), background: n <= nilai ? "#111" : "#fff" }} />
          ))}
          {/* Gagang geser */}
          <div className="absolute top-1/2 z-10 flex h-11 w-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-[3px] border-black shadow-[3px_3px_0_#111]"
            style={{
              left: pos(nilai), background: permanen ? "#f9a8d4" : "#fde047",
              transform: `translate(-50%, -50%) scale(${tarik ? 1.15 : 1})`,
              transition: tarik ? "transform .12s ease, left .12s ease-out" : "transform .2s ease, left .22s cubic-bezier(.34,1.56,.64,1), background .2s",
            }}>
            {permanen
              ? <IkonTakHingga size={22} strokeWidth={3.5} style={{ animation: "wiggle .6s ease" }} />
              : <span className="font-comic text-sm leading-none tracking-wide">{LANGKAH[nilai].label}</span>}
          </div>
        </div>

        {/* Label di bawah trek */}
        <div className="relative mt-5 h-6" aria-hidden="true">
          {LANGKAH.map((l, n) => (
            <button key={n} type="button" tabIndex={-1} disabled={disabled} onClick={() => { terakhir.current = n; onUbah(n); onSelesai?.(n); }}
              className="absolute top-0 -translate-x-1/2 px-1 font-comic text-sm leading-6 tracking-wide transition-colors"
              style={{ left: pos(n), color: n === nilai ? "#111" : "#8a8a8a", fontWeight: n === nilai ? 700 : 400 }}>
              {l.jam === 0 ? <IkonTakHingga size={18} strokeWidth={3.5} className="mt-1" /> : l.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
