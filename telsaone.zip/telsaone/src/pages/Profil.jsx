import { useEffect, useRef, useState } from "react";
import { Lock, Pencil, ShieldCheck, CalendarDays, Clock, KeyRound, LogOut, Save, X, ImagePlus } from "lucide-react";
import { supabase } from "../lib/supabase";
import { AVATAR_ICONS } from "../lib/avatars";
import Reveal from "../components/Reveal";
import { useContent } from "../lib/content";
import Avatar from "../components/Avatar";
import GantiPassword from "../components/GantiPassword";
import SukaSitus from "../components/SukaSitus";
import SpeedTest from "../components/SpeedTest";
import { AvatarDekor, PanelDekor } from "../components/ProfilDekor";

const WARNA = ["#ffe45e", "#7ed6ff", "#ff9ec4", "#9df0a8", "#ffb36b", "#c5a3ff"];
const PROVIDER = { email: "Email", google: "Google", github: "GitHub" };
const input = "w-full border-[3px] border-black bg-white px-3 py-2 font-body font-bold outline-none transition-shadow focus:shadow-[4px_4px_0_#111]";
const btnIcon = "inline-flex items-center justify-center gap-2";

function NamaAnimasi({ text }) {
  let n = 0;
  return (
    <h1 key={text} aria-label={text} className="break-words font-comic text-5xl leading-none tracking-wide md:text-6xl">
      {text.split(" ").map((kata, w) => (
        <span key={w}>
          <span className="inline-block whitespace-nowrap" aria-hidden>
            {[...kata].map((c, i) => <span key={i} className="letter" style={{ animationDelay: `${n++ * 45}ms` }}>{c}</span>)}
          </span>{" "}
        </span>
      ))}
    </h1>
  );
}

// Potong persegi dari tengah, kecilkan, jadikan JPEG supaya ringan
async function kecilkan(file, sisi = 256) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
    const s = Math.min(img.width, img.height);
    const c = document.createElement("canvas");
    c.width = c.height = sisi;
    c.getContext("2d").drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, sisi, sisi);
    return await new Promise((res) => c.toBlob(res, "image/jpeg", 0.85));
  } finally { URL.revokeObjectURL(url); }
}

const tgl = (v, opsi) => (v ? new Date(v).toLocaleString("id-ID", opsi) : "-");

export default function Profil({ user, onLogin, onLogout, onToast }) {
  const meta = user?.user_metadata || {};
  const [editing, setEditing] = useState(false);
  const [nama, setNama] = useState("");
  const [bio, setBio] = useState("");
  const [ikon, setIkon] = useState("");
  const [warna, setWarna] = useState(WARNA[0]);
  const [foto, setFoto] = useState("");
  const [upl, setUpl] = useState(false);
  const fileRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const { teks } = useContent();

  useEffect(() => { window.scrollTo(0, 0); }, []);

  if (!user)
    return (
      <section className="mx-auto flex min-h-screen max-w-md items-center px-5 pb-32 pt-28">
        <Reveal className="w-full">
          <div className="panel pop p-8 text-center" style={{ transform: "none" }}>
            <div className="float mx-auto flex h-24 w-24 items-center justify-center rounded-full border-4 border-black bg-yellow-300 shadow-[4px_4px_0_#111]">
              <Lock size={44} strokeWidth={2.5} />
            </div>
            <h1 className="mt-4 font-comic text-4xl tracking-wide">{teks.profil_masuk_judul}</h1>
            <p className="mt-2 font-body font-bold text-neutral-600">{teks.profil_masuk_pesan}</p>
            <button onClick={onLogin} className="btn mt-5 bg-yellow-300 px-6 py-2 text-xl">{teks.profil_masuk_tombol}</button>
          </div>
        </Reveal>
      </section>
    );

  const tampil = meta.full_name || user.email?.split("@")[0] || "Pengguna";
  const providers = [...new Set([...(user.app_metadata?.providers || []), user.app_metadata?.provider].filter(Boolean))];
  const pakaiPassword = providers.includes("email");

  const buka = () => {
    setNama(meta.full_name || ""); setBio(meta.bio || "");
    setFoto(meta.avatar_photo || ""); setIkon(meta.avatar_icon || ""); setWarna(meta.avatar_bg || WARNA[0]);
    setEditing(true);
  };

  const simpan = async () => {
    if (!supabase) return;
    if (!nama.trim()) return onToast(teks.profil_toast_nama);
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ data: { full_name: nama.trim(), bio: bio.trim(), avatar_icon: ikon, avatar_bg: warna, avatar_photo: foto } });
    setBusy(false);
    if (error) return onToast(error.message);
    if (foto) { // hapus foto lama milik sendiri (best effort)
      const { data: ls } = await supabase.storage.from("avatars").list(user.id);
      const lama = (ls || []).filter((f) => f.name !== foto.split("/").pop()).map((f) => `${user.id}/${f.name}`);
      if (lama.length) supabase.storage.from("avatars").remove(lama);
    }
    onToast(teks.profil_toast_sukses);
    setEditing(false);
  };

  const pilihFoto = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file || !supabase) return;
    if (!file.type.startsWith("image/")) return onToast(teks.profil_toast_bukan_gambar);
    if (file.size > 10 * 1024 * 1024) return onToast(teks.profil_toast_besar);
    setUpl(true);
    try {
      const blob = await kecilkan(file);
      const path = `${user.id}/${Date.now()}.jpg`;
      const { error } = await supabase.storage.from("avatars").upload(path, blob, { contentType: "image/jpeg", cacheControl: "31536000" });
      if (error) throw error;
      setFoto(supabase.storage.from("avatars").getPublicUrl(path).data.publicUrl);
      setIkon("");
    } catch (err) {
      onToast(err?.message?.includes("Bucket") ? "Bucket avatars belum dibuat. Jalankan telsaone-chat.sql." : "Gagal mengunggah foto: " + (err?.message || "format tidak didukung"));
    }
    setUpl(false);
  };

  const preview = { user_metadata: { ...meta, full_name: nama, avatar_icon: ikon, avatar_bg: warna, avatar_photo: foto } };
  const statistik = [
    { Icon: CalendarDays, label: "Bergabung", nilai: tgl(user.created_at, { day: "numeric", month: "long", year: "numeric" }) },
    { Icon: Clock, label: "Login terakhir", nilai: tgl(user.last_sign_in_at, { dateStyle: "medium", timeStyle: "short" }) },
    { Icon: KeyRound, label: "Masuk via", nilai: providers.map((p) => PROVIDER[p] || p).join(", ") || "-" },
  ];

  return (
    <section className="mx-auto max-w-4xl px-5 pb-32 pt-28 lg:max-w-5xl lg:px-8 2xl:max-w-6xl">
      <Reveal>
        <div className="panel relative isolate overflow-hidden p-6 md:p-8" style={{ transform: "none" }}>
          <PanelDekor />
          <div className="relative z-10 flex flex-col items-center gap-8 md:flex-row">
            <div className="relative flex h-48 w-48 shrink-0 items-center justify-center">
              <AvatarDekor />
              <div className="burst absolute inset-0 bg-black" style={{ animation: "spin 16s linear infinite" }} />
              <div className="burst absolute inset-2 bg-yellow-300" style={{ animation: "spin 16s linear infinite" }} />
              <div className="float relative"><div className="wiggle"><Avatar user={editing ? preview : user} size={116} /></div></div>
            </div>

            <div className="min-w-0 flex-1 text-center md:text-left">
              <span className="inline-block border-2 border-black bg-pink-300 px-2 font-comic tracking-wider">{teks.profil_label}</span>
              <div className="mt-2"><NamaAnimasi text={editing && nama.trim() ? nama : tampil} /></div>
              <p className="mt-1 break-all font-body font-bold text-neutral-500">{user.email}</p>

              <div className="bubble panel mt-5 rounded-2xl p-3 text-left" style={{ transform: "none", boxShadow: "4px 4px 0 #111" }}>
                <p className="font-body font-bold text-neutral-700">{(editing ? bio : meta.bio) || teks.profil_bio_kosong}</p>
              </div>

              <div className="mt-7 flex flex-wrap justify-center gap-3 md:justify-start">
                {!editing && <button onClick={buka} className={`btn ${btnIcon} bg-yellow-300 px-5 py-2 text-xl`}><Pencil size={20} strokeWidth={2.5} /> {teks.profil_ubah}</button>}
                <button onClick={onLogout} className={`btn ${btnIcon} bg-pink-200 px-5 py-2 text-xl`}><LogOut size={20} strokeWidth={2.5} /> {teks.profil_keluar}</button>
              </div>
            </div>
          </div>
        </div>
      </Reveal>

      {editing && (
        <div className="panel slide-in mt-8 space-y-5 p-6" style={{ transform: "none" }}>
          <h2 className="flex items-center gap-2 font-comic text-3xl tracking-wide"><Pencil size={26} strokeWidth={2.5} /> {teks.profil_edit_judul}</h2>

          <div>
            <label className="font-comic text-xl tracking-wide">{teks.profil_nama}</label>
            <input value={nama} onChange={(e) => setNama(e.target.value)} maxLength={30} placeholder={teks.profil_ph_nama} className={input} />
          </div>

          <div>
            <label className="font-comic text-xl tracking-wide">{teks.profil_bio} <span className="font-body text-sm text-neutral-500">({bio.length}/120)</span></label>
            <textarea value={bio} onChange={(e) => setBio(e.target.value)} maxLength={120} rows={3} placeholder={teks.profil_ph_bio} className={input} />
          </div>

          <div>
            <label className="font-comic text-xl tracking-wide">{teks.profil_avatar}</label>
            <div className="mt-2 flex flex-wrap gap-2">
              <input ref={fileRef} type="file" accept="image/*" onChange={pilihFoto} className="hidden" />
              <button type="button" onClick={() => fileRef.current?.click()} disabled={upl}
                className={`btn ${btnIcon} bg-sky-200 px-3 py-1 text-lg disabled:opacity-60`}>
                <ImagePlus size={18} strokeWidth={2.5} /> {upl ? "MENGUNGGAH..." : "UNGGAH FOTO"}
              </button>
              {(foto || meta.avatar_url) && (
                <button type="button" onClick={() => setIkon("")} className={`btn px-3 py-1 text-lg ${!ikon ? "bg-yellow-300" : "bg-white"}`}>{teks.profil_pakai_foto}</button>
              )}
              {Object.entries(AVATAR_ICONS).map(([k, Ikon]) => (
                <button key={k} type="button" onClick={() => setIkon(k)} aria-label={"Avatar " + k}
                  className={`flex h-11 w-11 items-center justify-center border-[3px] border-black transition-transform hover:-translate-y-1 ${ikon === k ? "bg-yellow-300 shadow-[3px_3px_0_#111]" : "bg-white"}`}>
                  <Ikon size={24} strokeWidth={2.5} />
                </button>
              ))}
            </div>
            {ikon && (
              <div className="slide-in mt-3 flex flex-wrap items-center gap-2">
                <span className="font-body font-bold">{teks.profil_warna}</span>
                {WARNA.map((c) => (
                  <button key={c} type="button" onClick={() => setWarna(c)} aria-label={"Warna " + c} style={{ background: c }}
                    className={`h-9 w-9 rounded-full border-[3px] border-black transition-transform hover:scale-110 ${warna === c ? "scale-110 shadow-[3px_3px_0_#111]" : ""}`} />
                ))}
              </div>
            )}
          </div>

          <div className="flex flex-wrap gap-3">
            <button onClick={simpan} disabled={busy} className={`btn ${btnIcon} bg-yellow-300 px-6 py-2 text-xl disabled:opacity-60`}><Save size={20} strokeWidth={2.5} /> {busy ? teks.profil_menyimpan : teks.profil_simpan}</button>
            <button onClick={() => setEditing(false)} className={`btn ${btnIcon} bg-white px-6 py-2 text-xl`}><X size={20} strokeWidth={2.5} /> {teks.profil_batal}</button>
          </div>
        </div>
      )}

      <div className="mt-8 grid gap-6 sm:grid-cols-3">
        {statistik.map(({ Icon, label, nilai }, i) => (
          <Reveal key={label} delay={i * 100}>
            <div className="panel h-full p-4">
              <div className="mb-2 flex h-11 w-11 items-center justify-center rounded-full border-[3px] border-black bg-yellow-300"><Icon size={22} strokeWidth={2.5} /></div>
              <p className="font-comic text-lg tracking-wide text-neutral-500">{label}</p>
              <p className="font-body font-bold">{nilai}</p>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal delay={100}>
        <div className="panel mt-8 p-6" style={{ transform: "none" }}>
          <h2 className="flex items-center gap-2 font-comic text-3xl tracking-wide"><ShieldCheck size={28} strokeWidth={2.5} /> {teks.profil_keamanan}</h2>
          {pakaiPassword ? (
            <GantiPassword email={user.email} onToast={onToast} />
          ) : (
            <p className="mt-2 font-body font-bold text-neutral-600">Akun Anda masuk lewat {providers.map((p) => PROVIDER[p] || p).join(", ")}, jadi tidak memakai password di sini.</p>
          )}
        </div>
      </Reveal>

      <SukaSitus onToast={onToast} />

      <SpeedTest />
    </section>
  );
}
