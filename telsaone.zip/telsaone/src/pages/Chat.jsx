import { useCallback, useEffect, useRef, useState } from "react";
import StoryBar from "../components/Story";
import { MessageCircle, Send, Trash2, LogIn } from "lucide-react";
import { supabase, envKurang } from "../lib/supabase";
import { syncProfile } from "../lib/profile";
import { isAdmin } from "../lib/admin";
import Reveal from "../components/Reveal";
import { useContent } from "../lib/content";
import Avatar from "../components/Avatar";
import UserCard from "../components/UserCard";

const PROF = "nama,avatar_icon,avatar_bg,avatar_url";
const PROF_FULL = PROF + ",bio,joined_at"; // bio + tanggal join (butuh telsaone-profil-stat.sql)
const MAX = 500;

const waktu = (v) => {
  const d = new Date(v);
  const jam = d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
  return d.toDateString() === new Date().toDateString()
    ? jam
    : d.toLocaleDateString("id-ID", { day: "numeric", month: "short" }) + ", " + jam;
};

const jadiUser = (p) => ({
  user_metadata: { full_name: p?.nama, avatar_icon: p?.avatar_icon, avatar_bg: p?.avatar_bg, avatar_url: p?.avatar_url },
});

// Data untuk kartu statistik (pesan milik sendiri memakai data akun yang sedang login)
const infoPengguna = (m, user) => {
  const mine = user?.id === m.user_id;
  const meta = user?.user_metadata || {};
  return {
    id: m.user_id,
    user: mine ? user : jadiUser(m.profiles),
    nama: (mine && meta.full_name) || m.profiles?.nama || "Pengguna",
    bio: mine ? meta.bio || m.profiles?.bio || "" : m.profiles?.bio || "",
    joined: mine ? user.created_at : m.profiles?.joined_at,
  };
};

export default function Chat({ user, onLogin, onToast }) {
  const { teks } = useContent();
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState("");
  const [error, setError] = useState("");
  const [ready, setReady] = useState(false);
  const [kartu, setKartu] = useState(null);
  const admin = isAdmin(user);
  const listRef = useRef(null);
  const stick = useRef(true);
  const profCache = useRef({}); // user_id -> profil, supaya pesan realtime tidak perlu muat ulang semuanya

  const load = useCallback(async () => {
    if (!supabase) return;
    let data = null;
    let err = null;
    // Coba kolom lengkap (dengan bio + tanggal join), lalu versi lama bila kolom belum ada
    for (const kolom of [PROF_FULL, PROF]) {
      const r = await supabase
        .from("messages").select(`id,user_id,content,created_at,profiles(${kolom})`).order("created_at", { ascending: false }).limit(100);
      if (!r.error) { data = r.data; err = null; break; }
      err = r.error;
    }
    if (err) { // cadangan: ambil pesan polos, profil diambil terpisah
      const r = await supabase.from("messages").select("id,user_id,content,created_at").order("created_at", { ascending: false }).limit(100);
      if (!r.error) {
        const ids = [...new Set(r.data.map((x) => x.user_id))];
        let ps = [];
        if (ids.length) {
          for (const kolom of [PROF_FULL, PROF]) {
            const q = await supabase.from("profiles").select("id," + kolom).in("id", ids);
            if (!q.error) { ps = q.data; break; }
          }
        }
        const peta = Object.fromEntries(ps.map((x) => [x.id, x]));
        data = r.data.map((x) => ({ ...x, profiles: peta[x.user_id] || null }));
        err = null;
      }
    }
    if (err) setError(err.message);
    else {
      setError("");
      for (const x of data) if (x.profiles) profCache.current[x.user_id] = x.profiles;
      setMsgs((prev) => [...data.reverse(), ...prev.filter((x) => x.pending)]);
    }
    setReady(true);
  }, []);

  useEffect(() => { window.scrollTo(0, 0); }, []);

  // Pesan realtime ditambahkan / dihapus langsung dari datanya (tanpa muat ulang 100 pesan)
  const onRealtime = useCallback(async (p) => {
    if (p.eventType === "DELETE") {
      const id = p.old?.id;
      if (id != null) setMsgs((m) => m.filter((x) => x.id !== id));
      return;
    }
    if (p.eventType !== "INSERT") return;
    const r = p.new;
    let prof = profCache.current[r.user_id];
    if (!prof) {
      for (const kolom of [PROF_FULL, PROF]) {
        const q = await supabase.from("profiles").select(kolom).eq("id", r.user_id).maybeSingle();
        if (!q.error) { prof = q.data; break; }
      }
      if (prof) profCache.current[r.user_id] = prof;
    }
    setMsgs((m) => (m.some((x) => x.id === r.id)
      ? m
      : [...m.filter((x) => !(x.pending && x.user_id === r.user_id && x.content === r.content)), { ...r, profiles: prof || null }]));
  }, []);

  // Muat pesan, langganan realtime, dan polling cadangan (kalau realtime belum diaktifkan)
  useEffect(() => {
    if (!supabase) return undefined;
    load();                                        // tampilkan pesan segera, tanpa menunggu sinkron profil
    if (user) Promise.resolve(syncProfile(user)).catch(() => {});
    const ch = supabase.channel("chat-publik")
      .on("postgres_changes", { event: "*", schema: "public", table: "messages" }, onRealtime)
      .subscribe();
    const iv = setInterval(() => { if (!document.hidden) load(); }, 15000);
    return () => { clearInterval(iv); supabase.removeChannel(ch); };
  }, [load, onRealtime, user?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const el = listRef.current;
    if (el && stick.current) el.scrollTop = el.scrollHeight;
  }, [msgs]);

  const onScroll = () => {
    const el = listRef.current;
    stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
  };

  // Optimistis: pesan langsung tampil dan kolom ketik langsung kosong; server mengonfirmasi di belakang layar
  const kirim = async (e) => {
    e.preventDefault();
    const isi = text.trim();
    if (!isi || !user) return;
    const tmp = `tmp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setMsgs((m) => [...m, { id: tmp, user_id: user.id, content: isi, created_at: new Date().toISOString(), profiles: null, pending: true }]);
    setText("");
    stick.current = true;

    const masuk = () => supabase.from("messages").insert({ user_id: user.id, content: isi }).select("id,user_id,content,created_at").single();
    let { data, error: err } = await masuk();
    if (err?.code === "23503") { // profil belum ada di tabel: buat lalu coba lagi
      await syncProfile(user);
      ({ data, error: err } = await masuk());
    }
    if (err) {
      setMsgs((m) => m.filter((x) => x.id !== tmp));
      setText((t) => t || isi); // kembalikan teks agar bisa dikirim ulang
      return onToast(err.message || teks.chat_gagal_kirim);
    }
    setMsgs((m) => (m.some((x) => x.id === data.id) ? m.filter((x) => x.id !== tmp) : m.map((x) => (x.id === tmp ? { ...data, profiles: null, k: tmp } : x))));
  };

  const hapus = async (id) => {
    setMsgs((m) => m.filter((x) => x.id !== id));
    const { error: err } = await supabase.from("messages").delete().eq("id", id);
    if (err) { onToast(err.message); load(); }
  };

  return (
    <section className="mx-auto max-w-3xl px-5 pb-32 pt-28 lg:max-w-4xl lg:px-8 2xl:max-w-5xl">
      <div className="mb-8"><StoryBar user={user} onLogin={onLogin} onToast={onToast} /></div>
      <Reveal>
        <div className="panel p-4 md:p-6" style={{ transform: "none" }}>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h1 className="flex items-center gap-2 font-comic text-4xl tracking-wide">
              <MessageCircle size={34} strokeWidth={2.5} /> {teks.chat_judul}
            </h1>
            <span className="border-2 border-black bg-green-200 px-2 font-comic tracking-wider">{teks.chat_label}</span>
          </div>
          <p className="mt-1 font-body font-bold text-neutral-600">
            {teks.chat_info}
          </p>

          {!supabase ? (
            <p className="mt-4 border-[3px] border-black bg-yellow-100 p-3 font-body font-bold">
              Supabase belum diatur. Isi {envKurang.join(" dan ")} di file .env (atau di Environment Variables hosting), lalu restart / deploy ulang.
            </p>
          ) : error ? (
            <p className="mt-4 border-[3px] border-black bg-pink-100 p-3 font-body font-bold">
              Chat belum siap: {error}. Jalankan <code>telsaone-chat.sql</code> di Supabase SQL Editor.
            </p>
          ) : (
            <>
              <div ref={listRef} onScroll={onScroll}
                className="mt-4 h-[52vh] lg:h-[58vh] space-y-4 overflow-y-auto border-[3px] border-black bg-[#fdfbf4] p-3">
                {!ready && <p className="py-10 text-center font-comic text-2xl tracking-wide">{teks.memuat}</p>}
                {ready && msgs.length === 0 && (
                  <p className="py-10 text-center font-comic text-2xl tracking-wide text-neutral-500">
                    {teks.chat_kosong}
                  </p>
                )}
                {msgs.map((m) => {
                  const mine = user?.id === m.user_id;
                  return (
                    <div key={m.k ?? m.id} className={`pop flex items-end gap-2 ${mine ? "flex-row-reverse" : ""} ${m.pending ? "opacity-60" : ""}`}>
                      <button type="button" onClick={() => setKartu(infoPengguna(m, user))} aria-label="Lihat profil" className="shrink-0 rounded-full transition-transform hover:scale-110 active:scale-95">
                        <Avatar user={mine ? user : jadiUser(m.profiles)} size={38} />
                      </button>
                      <div className={`min-w-0 max-w-[78%] ${mine ? "text-right" : ""}`}>
                        <p className="font-comic text-lg leading-none tracking-wide">
                          <button type="button" onClick={() => setKartu(infoPengguna(m, user))} className="tracking-wide hover:underline">
                            {(mine && user?.user_metadata?.full_name) || m.profiles?.nama || "Pengguna"}
                          </button>{" "}
                          <span className="font-body text-xs font-bold text-neutral-500">{waktu(m.created_at)}</span>
                        </p>
                        <div className={`mt-1 inline-block whitespace-pre-wrap break-words rounded-2xl border-[3px] border-black px-3 py-2 text-left font-body font-bold shadow-[3px_3px_0_#111] ${mine ? "bg-yellow-300" : "bg-white"}`}>
                          {m.content}
                        </div>
                        {(mine || admin) && !m.pending && (
                          <button onClick={() => hapus(m.id)} aria-label="Hapus pesan"
                            className="ml-2 inline-flex align-bottom text-neutral-500 transition-colors hover:text-red-600">
                            <Trash2 size={16} strokeWidth={2.5} />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {user ? (
                <form onSubmit={kirim} className="mt-4 flex gap-2">
                  <input value={text} onChange={(e) => setText(e.target.value)} maxLength={MAX}
                    placeholder={teks.chat_placeholder} aria-label="Pesan"
                    className="min-w-0 flex-1 border-[3px] border-black bg-white px-3 py-2 font-body font-bold outline-none transition-shadow focus:shadow-[4px_4px_0_#111]" />
                  <button type="submit" disabled={!text.trim()}
                    className="btn inline-flex items-center gap-2 bg-yellow-300 px-4 py-2 text-xl disabled:opacity-60">
                    <Send size={20} strokeWidth={2.5} /> <span className="hidden sm:inline">{teks.chat_kirim}</span>
                  </button>
                </form>
              ) : (
                <button onClick={onLogin} className="btn mt-4 inline-flex w-full items-center justify-center gap-2 bg-yellow-300 px-4 py-2 text-xl">
                  <LogIn size={20} strokeWidth={2.5} /> {teks.chat_masuk}
                </button>
              )}
            </>
          )}
        </div>
      </Reveal>
      {kartu && <UserCard info={kartu} onClose={() => setKartu(null)} />}
    </section>
  );
}
