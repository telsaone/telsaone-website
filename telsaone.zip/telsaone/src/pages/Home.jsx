import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { Pengenalan, Isi, Penutup } from "../components/Sections";
import StoryBar from "../components/Story";
import { Pita } from "../components/Hiasan";

export default function Home({ user, onLogin, onToast }) {
  const { state } = useLocation();
  useEffect(() => {
    const id = state?.scrollTo;
    if (!id) return;
    const t = setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" }), 80);
    return () => clearTimeout(t);
  }, [state]);

  return (
    <>
      <div className="mx-auto max-w-5xl px-5 pt-28 lg:max-w-6xl lg:px-8 2xl:max-w-7xl">
        <StoryBar user={user} onLogin={onLogin} onToast={onToast} />
      </div>
      <Pengenalan user={user} />
      <Pita />
      <Isi />
      <Penutup />
    </>
  );
}
