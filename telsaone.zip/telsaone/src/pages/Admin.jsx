import { useEffect, useRef, useState } from "react";
import { BookOpen, ArrowDown, ArrowUp, ImagePlus, Link2, Lock, Music, Image as ImageIcon, Plus, Save, Trash2, Type, Upload, Wrench, Gamepad2, Gift, Contact, RotateCcw } from "lucide-react";
import { supabase } from "../lib/supabase";
import { isAdmin } from "../lib/admin";
import { unggah, hapusFile } from "../lib/upload";
import { useContent } from "../lib/content";
import { SOSIAL } from "../data";
import { TEKS, TEKS_GRUP } from "../lib/teks";
import Reveal from "../components/Reveal";
import GameAdmin from "../components/GameAdmin";
import HadiahAdmin from "../components/HadiahAdmin";

const input = "w-full border-[3px] border-black bg-white px-3 py-2 font-body font-bold outline-none transition-shadow focus:shadow-[4px_4px_0_#111]";
const row = "inline-flex items-center justify-center gap-2";
const TAB = [
  { id: "musik", label: "MUSIK", Icon: Music },
  { id: "media", label: "MEDIA", Icon: ImageIcon },
  { id: "murotal", label: "MUROTAL", Icon: BookOpen },
  { id: "sosial", label: "TAUTAN", Icon: Link2 },
  { id: "teks", label: "TEKS", Icon: Type },
  { id: "game", label: "GAME", Icon: Gamepad2 },
  { id: "hadiah", label: "HADIAH", Icon: Gift },
  { id: "lanyard", label: "LANYARD", Icon: Contact },
];

async function simpanKunci(key, value) {
  const { error } = await supabase.from("site_content").upsert({ key, value, updated_at: new Date().toISOString() });
  if (error) throw error;
}

const urlsDari = (items) => (items || []).map((x) => x.src).filter(Boolean);

// Daftar yang bisa ditambah, diunggah, diurutkan, dihapus (dipakai untuk musik dan media)
function ListEditor({ kind, awal, contentKey, refresh, onToast }) {
  const musik = kind === "musik";
  const [items, setItems] = useState(awal);
  const [asli, setAsli] = useState(awal);
  const [busy, setBusy] = useState(-1);
  const [status, setStatus] = useState("");
  const [saving, setSaving] = useState(false);
  const fileRef = useRef(null);
  const target = useRef(-1);

  const ubah = (i, patch) => setItems((l) => l.map((x, n) => (n === i ? { ...x, ...patch } : x)));
  const pindah = (i, d) => setItems((l) => {
    const j = i + d;
    if (j < 0 || j >= l.length) return l;
    const c = [...l]; [c[i], c[j]] = [c[j], c[i]]; return c;
  });
  const tambah = () => setItems((l) => [...l, musik ? { title: "", artist: "", src: "" } : { type: "image", title: "", src: "" }]);

  const pilih = (i) => { target.current = i; fileRef.current?.click(); };
  const onFile = async (e) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    const i = target.current;
    if (!f || i < 0) return;
    setBusy(i);
    try {
      const url = await unggah(f, musik ? "musik" : "media", 50, setStatus);
      ubah(i, { src: url, ...(musik ? {} : { type: f.type.startsWith("video/") ? "video" : "image" }), title: items[i].title || f.name.replace(/\.[^.]+$/, "") });
      onToast("File terunggah. Klik SIMPAN agar tampil di web.");
    } catch (err) {
      onToast(/bucket/i.test(err.message) ? "Bucket 'konten' belum dibuat. Jalankan telsaone-admin.sql." : err.message || "Gagal mengunggah.");
    }
    setBusy(-1);
  };

  const simpan = async () => {
    setSaving(true);
    try {
      const bersih = items.map((x) => ({ ...x, title: x.title.trim(), ...(musik ? { artist: (x.artist || "").trim() } : {}), src: x.src.trim() }));
      await simpanKunci(contentKey, bersih);
      const dipakai = new Set(urlsDari(bersih));
      urlsDari(asli).forEach((u) => !dipakai.has(u) && hapusFile(u)); // bersihkan file yang tidak dipakai lagi
      setItems(bersih); setAsli(bersih);
      await refresh();
      onToast("Tersimpan! Perubahan sudah tampil di web.");
    } catch (err) { onToast(err.message || "Gagal menyimpan."); }
    setSaving(false);
  };

  return (
    <div className="space-y-4">
      <input ref={fileRef} type="file" onChange={onFile} className="hidden" accept={musik ? "audio/*" : "image/*,video/*"} />
      {items.length === 0 && <p className="border-[3px] border-dashed border-black p-4 text-center font-body font-bold text-neutral-500">Belum ada item. Klik TAMBAH.</p>}
      {items.map((it, i) => (
        <div key={i} className="border-[3px] border-black bg-white p-3 shadow-[4px_4px_0_#111]">
          <div className="flex items-center justify-between gap-2">
            <span className="font-comic text-xl tracking-wide">#{i + 1}</span>
            <div className="flex gap-1">
              <button type="button" onClick={() => pindah(i, -1)} disabled={i === 0} aria-label="Naik" className="btn flex bg-white p-1 disabled:opacity-40"><ArrowUp size={18} strokeWidth={3} /></button>
              <button type="button" onClick={() => pindah(i, 1)} disabled={i === items.length - 1} aria-label="Turun" className="btn flex bg-white p-1 disabled:opacity-40"><ArrowDown size={18} strokeWidth={3} /></button>
              <button type="button" onClick={() => setItems((l) => l.filter((_, n) => n !== i))} aria-label="Hapus" className="btn flex bg-pink-200 p-1"><Trash2 size={18} strokeWidth={3} /></button>
            </div>
          </div>
          <div className="mt-2 grid gap-2 sm:grid-cols-2">
            <input value={it.title} onChange={(e) => ubah(i, { title: e.target.value })} placeholder="Judul" maxLength={80} className={input} />
            {musik
              ? <input value={it.artist || ""} onChange={(e) => ubah(i, { artist: e.target.value })} placeholder="Artis" maxLength={80} className={input} />
              : (
                <select value={it.type} onChange={(e) => ubah(i, { type: e.target.value })} className={input}>
                  <option value="image">Gambar</option>
                  <option value="video">Video</option>
                </select>
              )}
          </div>
          <div className="mt-2 flex flex-col gap-2 sm:flex-row">
            <input value={it.src} onChange={(e) => ubah(i, { src: e.target.value })} placeholder="URL file (atau unggah)" className={`${input} min-w-0 flex-1`} />
            <button type="button" onClick={() => pilih(i)} disabled={busy === i} className={`btn ${row} shrink-0 bg-sky-200 px-4 py-2 text-lg disabled:opacity-60`}>
              <Upload size={18} strokeWidth={2.5} /> {busy === i ? (status || "MENGUNGGAH...").toUpperCase() : "UNGGAH"}
            </button>
          </div>
          {!musik && it.src && (it.type === "video"
            ? <video src={it.src} controls className="mt-2 max-h-40 border-[3px] border-black" />
            : <img src={it.src} alt="" className="mt-2 max-h-40 border-[3px] border-black object-cover" />)}
          {musik && it.src && <audio src={it.src} controls className="mt-2 w-full" />}
        </div>
      ))}
      <div className="flex flex-wrap gap-3">
        <button type="button" onClick={tambah} className={`btn ${row} bg-white px-5 py-2 text-xl`}><Plus size={20} strokeWidth={3} /> TAMBAH</button>
        <button type="button" onClick={simpan} disabled={saving} className={`btn ${row} bg-yellow-300 px-5 py-2 text-xl disabled:opacity-60`}><Save size={20} strokeWidth={2.5} /> {saving ? "MENYIMPAN..." : "SIMPAN"}</button>
      </div>
    </div>
  );
}

// Murotal (halaman Game): SATU video relax yang diputar berulang (bisu) + daftar file audio (.mp3 / .m4a)
function MurotalEditor({ awal, refresh, onToast }) {
  const c = useContent();
  const [items, setItems] = useState(() => awal.map((x) => ({ judul: x.judul || "", qari: x.qari || "", audio: x.audio || x.video || "" })));
  const [asli, setAsli] = useState(items);
  const [video, setVideo] = useState(c.murotalVideo || "");
  const [videoAsli, setVideoAsli] = useState(c.murotalVideo || "");
  const [busy, setBusy] = useState(""); // "video" atau indeks audio
  const [status, setStatus] = useState("");
  const [saving, setSaving] = useState(false);
  const fileRef = useRef(null);
  const target = useRef(-1); // -1 = video relax, >= 0 = indeks audio

  const ubah = (i, patch) => setItems((l) => l.map((x, n) => (n === i ? { ...x, ...patch } : x)));
  const pindah = (i, d) => setItems((l) => {
    const j = i + d;
    if (j < 0 || j >= l.length) return l;
    const cp = [...l]; [cp[j], cp[i]] = [cp[i], cp[j]]; return cp;
  });
  const tambah = () => setItems((l) => [...l, { judul: "", qari: "", audio: "" }]);

  const pilih = (i) => {
    target.current = i;
    if (fileRef.current) { fileRef.current.accept = i === -1 ? "video/*" : "audio/*,.mp3,.m4a"; fileRef.current.click(); }
  };
  const onFile = async (e) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    const i = target.current;
    if (!f) return;
    setBusy(i === -1 ? "video" : i);
    try {
      const url = await unggah(f, "murotal", 50, setStatus);
      if (i === -1) setVideo(url);
      else ubah(i, { audio: url, judul: items[i].judul || f.name.replace(/\.[^.]+$/, "") });
      onToast("File terunggah. Klik SIMPAN agar tampil di web.");
    } catch (err) {
      onToast(/bucket/i.test(err.message) ? "Bucket 'konten' belum dibuat. Jalankan telsaone-admin.sql." : err.message || "Gagal mengunggah.");
    }
    setBusy("");
  };

  const simpan = async () => {
    setSaving(true);
    try {
      const bersih = items.map((x) => ({ judul: x.judul.trim(), qari: x.qari.trim(), audio: x.audio.trim() }));
      const vBersih = video.trim();
      await simpanKunci("murotal", bersih);
      await simpanKunci("murotal_video", { src: vBersih });
      const dipakai = new Set([...bersih.map((x) => x.audio), vBersih].filter(Boolean));
      [...asli.map((x) => x.audio), videoAsli].filter(Boolean).forEach((u) => !dipakai.has(u) && hapusFile(u)); // bersihkan file yang tidak dipakai lagi
      setItems(bersih); setAsli(bersih); setVideo(vBersih); setVideoAsli(vBersih);
      await refresh();
      onToast("Tersimpan! Murotal sudah tampil di halaman Game.");
    } catch (err) { onToast(err.message || "Gagal menyimpan."); }
    setSaving(false);
  };

  const kolomFile = (nilai, setNilai, i, placeholder) => (
    <div className="flex flex-col gap-2 sm:flex-row">
      <input value={nilai} onChange={(e) => setNilai(e.target.value)} placeholder={placeholder} className={`${input} min-w-0 flex-1`} />
      <button type="button" onClick={() => pilih(i)} disabled={busy === (i === -1 ? "video" : i)} className={`btn ${row} shrink-0 bg-sky-200 px-4 py-2 text-lg disabled:opacity-60`}>
        <Upload size={18} strokeWidth={2.5} /> {busy === (i === -1 ? "video" : i) ? (status || "MENGUNGGAH...").toUpperCase() : "UNGGAH"}
      </button>
    </div>
  );

  return (
    <div className="space-y-4">
      <input ref={fileRef} type="file" onChange={onFile} className="hidden" />
      <p className="font-body text-sm font-bold text-neutral-600">Muncul di halaman Game, di bawah jadwal sholat. Cukup unggah SATU video relax (diputar berulang tanpa suara), lalu tambahkan murotal berupa file audio .mp3 / .m4a saja.</p>

      <div className="border-[3px] border-black bg-green-100 p-3 shadow-[4px_4px_0_#111]">
        <p className="font-comic text-xl tracking-wide">VIDEO RELAX (SATU UNTUK SEMUA)</p>
        {kolomFile(video, setVideo, -1, "URL video (atau unggah)")}
        {video && <video src={video} muted loop controls playsInline className="mt-2 max-h-40 border-[3px] border-black" />}
      </div>

      <p className="font-comic text-xl tracking-wide">DAFTAR AUDIO</p>
      {items.length === 0 && <p className="border-[3px] border-dashed border-black p-4 text-center font-body font-bold text-neutral-500">Belum ada murotal. Klik TAMBAH.</p>}
      {items.map((it, i) => (
        <div key={i} className="border-[3px] border-black bg-white p-3 shadow-[4px_4px_0_#111]">
          <div className="flex items-center justify-between gap-2">
            <span className="font-comic text-xl tracking-wide">#{i + 1}</span>
            <div className="flex gap-1">
              <button type="button" onClick={() => pindah(i, -1)} disabled={i === 0} aria-label="Naik" className="btn flex bg-white p-1 disabled:opacity-40"><ArrowUp size={18} strokeWidth={3} /></button>
              <button type="button" onClick={() => pindah(i, 1)} disabled={i === items.length - 1} aria-label="Turun" className="btn flex bg-white p-1 disabled:opacity-40"><ArrowDown size={18} strokeWidth={3} /></button>
              <button type="button" onClick={() => setItems((l) => l.filter((_, n) => n !== i))} aria-label="Hapus" className="btn flex bg-pink-200 p-1"><Trash2 size={18} strokeWidth={3} /></button>
            </div>
          </div>
          <div className="mt-2 grid gap-2 sm:grid-cols-2">
            <input value={it.judul} onChange={(e) => ubah(i, { judul: e.target.value })} placeholder="Judul (mis. Surah Ar-Rahman)" maxLength={80} className={input} />
            <input value={it.qari} onChange={(e) => ubah(i, { qari: e.target.value })} placeholder="Qari" maxLength={80} className={input} />
          </div>
          <div className="mt-2">{kolomFile(it.audio, (v) => ubah(i, { audio: v }), i, "URL audio .mp3 / .m4a (atau unggah)")}</div>
          {it.audio && <audio src={it.audio} controls className="mt-2 w-full" />}
        </div>
      ))}
      <div className="flex flex-wrap gap-3">
        <button type="button" onClick={tambah} className={`btn ${row} bg-white px-5 py-2 text-xl`}><Plus size={20} strokeWidth={3} /> TAMBAH</button>
        <button type="button" onClick={simpan} disabled={saving} className={`btn ${row} bg-yellow-300 px-5 py-2 text-xl disabled:opacity-60`}><Save size={20} strokeWidth={2.5} /> {saving ? "MENYIMPAN..." : "SIMPAN"}</button>
      </div>
    </div>
  );
}

function SosialEditor({ awal, refresh, onToast }) {
  const [v, setV] = useState(() => Object.fromEntries(SOSIAL.map((s) => [s.label, awal[s.label] || ""])));
  const [saving, setSaving] = useState(false);
  const simpan = async () => {
    setSaving(true);
    try {
      await simpanKunci("sosial", Object.fromEntries(Object.entries(v).map(([k, x]) => [k, x.trim()])));
      await refresh();
      onToast("Tautan tersimpan!");
    } catch (err) { onToast(err.message || "Gagal menyimpan."); }
    setSaving(false);
  };
  return (
    <div className="space-y-3">
      {SOSIAL.map(({ label, icon: Icon }) => (
        <label key={label} className="block">
          <span className="flex items-center gap-2 font-comic text-xl tracking-wide"><Icon size={20} strokeWidth={2.5} /> {label}</span>
          <input value={v[label]} onChange={(e) => setV({ ...v, [label]: e.target.value })} placeholder="https://..." className={input} />
        </label>
      ))}
      <button type="button" onClick={simpan} disabled={saving} className={`btn ${row} bg-yellow-300 px-5 py-2 text-xl disabled:opacity-60`}><Save size={20} strokeWidth={2.5} /> {saving ? "MENYIMPAN..." : "SIMPAN"}</button>
    </div>
  );
}

// Gambar penuh pada kartu lanyard (satu gambar, dipakai depan dan belakang kartu)
function LanyardEditor({ awal, refresh, onToast }) {
  const [src, setSrc] = useState(awal || "");
  const [asli, setAsli] = useState(awal || "");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("");
  const [saving, setSaving] = useState(false);
  const fileRef = useRef(null);

  const onFile = async (e) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    if (!f.type.startsWith("image/")) { onToast("Pilih file gambar."); return; }
    setBusy(true);
    try {
      const url = await unggah(f, "lanyard", 50, setStatus);
      if (src && src !== asli) hapusFile(src); // unggahan sebelumnya yang belum disimpan
      setSrc(url);
      onToast("Gambar terunggah. Klik SIMPAN agar tampil di web.");
    } catch (err) {
      onToast(/bucket/i.test(err.message) ? "Bucket 'konten' belum dibuat. Jalankan telsaone-admin.sql." : err.message || "Gagal mengunggah.");
    }
    setBusy(false);
  };

  const simpan = async () => {
    setSaving(true);
    try {
      const baru = src.trim();
      await simpanKunci("lanyard", { gambar: baru });
      if (asli && asli !== baru) hapusFile(asli); // bersihkan file lama yang tidak dipakai lagi
      setSrc(baru); setAsli(baru);
      await refresh();
      onToast("Tersimpan! Gambar lanyard sudah tampil di web.");
    } catch (err) { onToast(err.message || "Gagal menyimpan."); }
    setSaving(false);
  };

  return (
    <div className="space-y-4">
      <input ref={fileRef} type="file" onChange={onFile} className="hidden" accept="image/*" />
      <p className="font-body font-bold text-neutral-600">Satu gambar atau GIF penuh untuk kartu lanyard (depan dan belakang). GIF tetap bergerak di kartu. Kosongkan untuk kembali ke kartu putih polos.</p>
      <div className="flex flex-col gap-4 sm:flex-row">
        <div className="mx-auto w-44 shrink-0 sm:mx-0">
          <div className="aspect-[1.6/2.25] overflow-hidden border-[3px] border-black bg-white shadow-[4px_4px_0_#111]" style={{ borderRadius: "14px" }}>
            {src
              ? <img src={src} alt="Pratinjau kartu" className="h-full w-full object-cover" />
              : <div className="flex h-full items-center justify-center p-2 text-center font-comic text-lg tracking-wide text-neutral-400">KARTU PUTIH</div>}
          </div>
          <p className="mt-1 text-center font-body text-xs font-bold text-neutral-500">Pratinjau (dipotong rasio 1.6 : 2.25)</p>
        </div>
        <div className="min-w-0 flex-1 space-y-2">
          <input value={src} onChange={(e) => setSrc(e.target.value)} placeholder="URL gambar/GIF (atau unggah)" className={input} />
          <div className="flex flex-wrap gap-3">
            <button type="button" onClick={() => fileRef.current?.click()} disabled={busy} className={`btn ${row} bg-sky-200 px-4 py-2 text-lg disabled:opacity-60`}>
              <Upload size={18} strokeWidth={2.5} /> {busy ? (status || "MENGUNGGAH...").toUpperCase() : "UNGGAH GAMBAR / GIF"}
            </button>
            <button type="button" onClick={() => setSrc("")} disabled={!src} className={`btn ${row} bg-pink-200 px-4 py-2 text-lg disabled:opacity-40`}>
              <Trash2 size={18} strokeWidth={2.5} /> HAPUS GAMBAR
            </button>
          </div>
          <p className="font-body text-sm font-bold text-neutral-500">Saran: gambar/GIF potret, mis. 1024x1440. Gambar JPG/PNG dikecilkan otomatis; GIF diunggah apa adanya (maks 50 MB), jadi pilih GIF yang ringan.</p>
        </div>
      </div>
      <button type="button" onClick={simpan} disabled={saving || busy} className={`btn ${row} bg-yellow-300 px-5 py-2 text-xl disabled:opacity-60`}><Save size={20} strokeWidth={2.5} /> {saving ? "MENYIMPAN..." : "SIMPAN"}</button>
    </div>
  );
}

function TeksEditor({ awal, refresh, onToast }) {
  const [v, setV] = useState(awal);
  const [saving, setSaving] = useState(false);
  const [cari, setCari] = useState("");
  const q = cari.trim().toLowerCase();
  const cocok = (f) => !q || [f.label, f.def, f.k, v[f.k]].some((x) => (x || "").toLowerCase().includes(q));

  const simpan = async () => {
    setSaving(true);
    try {
      // Simpan hanya yang berbeda dari bawaan; kosong = kembali ke bawaan
      const out = {};
      Object.entries(v).forEach(([k, x]) => { const t = (x || "").trim(); if (t && t !== TEKS[k]) out[k] = t; });
      await simpanKunci("teks", out);
      await refresh();
      setV(Object.fromEntries(Object.keys(TEKS).map((k) => [k, (v[k] || "").trim() || TEKS[k]])));
      onToast("Teks tersimpan! Perubahan sudah tampil di web.");
    } catch (err) { onToast(err.message || "Gagal menyimpan."); }
    setSaving(false);
  };

  return (
    <div className="space-y-3">
      <p className="font-body font-bold text-neutral-600">
        Ubah teks di seluruh web, lalu klik SIMPAN. Kosongkan kolom (atau tekan tombol ↺) untuk kembali ke teks bawaan.
        Teks statistik profil (Bergabung, Login terakhir, Masuk via) tidak bisa diubah.
      </p>
      <input value={cari} onChange={(e) => setCari(e.target.value)} placeholder="Cari teks (judul, tombol, isi kotak, nama kolom...)" className={input} />
      {TEKS_GRUP.map((g, gi) => g.isi.some(cocok) && (
        <details key={g.judul + (q ? "-cari" : "")} open={q ? true : gi === 0} className="group border-[3px] border-black bg-white shadow-[4px_4px_0_#111]">
          <summary className="cursor-pointer select-none px-3 py-2 font-comic text-xl tracking-wide marker:content-none">
            <span className="mr-2 inline-block transition-transform group-open:rotate-90">▶</span>{g.judul}
          </summary>
          <div className="space-y-3 border-t-[3px] border-black p-3">
            {g.isi.filter(cocok).map((f) => (
              <label key={f.k} className="block">
                <span className="flex items-center justify-between gap-2">
                  <span className="font-comic text-lg tracking-wide">{f.label}</span>
                  {(v[f.k] || "").trim() !== f.def && (
                    <button type="button" onClick={() => setV({ ...v, [f.k]: f.def })} aria-label="Kembalikan ke bawaan" title="Kembalikan ke bawaan" className="btn flex bg-white p-1"><RotateCcw size={14} strokeWidth={3} /></button>
                  )}
                </span>
                {f.m
                  ? <textarea value={v[f.k] || ""} onChange={(e) => setV({ ...v, [f.k]: e.target.value })} placeholder={f.def} rows={4} maxLength={600} className={input} />
                  : <input value={v[f.k] || ""} onChange={(e) => setV({ ...v, [f.k]: e.target.value })} placeholder={f.def} maxLength={120} className={input} />}
                {f.h && <span className="font-body text-xs font-bold text-neutral-500">{f.h}</span>}
              </label>
            ))}
          </div>
        </details>
      ))}
      <button type="button" onClick={simpan} disabled={saving} className={`btn ${row} bg-yellow-300 px-5 py-2 text-xl disabled:opacity-60`}><Save size={20} strokeWidth={2.5} /> {saving ? "MENYIMPAN..." : "SIMPAN"}</button>
    </div>
  );
}

export default function Admin({ user, onLogin, onToast }) {
  const c = useContent();
  const [tab, setTab] = useState("musik");
  const [raw, setRaw] = useState(null); // nilai tersimpan di DB (untuk tautan)

  useEffect(() => { window.scrollTo(0, 0); }, []);
  useEffect(() => {
    if (!supabase || !isAdmin(user)) return;
    supabase.from("site_content").select("value").eq("key", "sosial").maybeSingle().then(({ data }) => setRaw(data?.value || {}));
  }, [user]);

  if (!isAdmin(user))
    return (
      <section className="mx-auto flex min-h-screen max-w-md items-center px-5 pb-32 pt-28">
        <Reveal className="w-full">
          <div className="panel pop p-8 text-center" style={{ transform: "none" }}>
            <div className="float mx-auto flex h-24 w-24 items-center justify-center rounded-full border-4 border-black bg-pink-200 shadow-[4px_4px_0_#111]"><Lock size={44} strokeWidth={2.5} /></div>
            <h1 className="mt-4 font-comic text-4xl tracking-wide">KHUSUS ADMIN</h1>
            <p className="mt-2 font-body font-bold text-neutral-600">
              {user ? "Akun ini bukan admin." : "Masuk dengan Google memakai akun admin."}
            </p>
            {!user && <button onClick={onLogin} className="btn mt-5 bg-yellow-300 px-6 py-2 text-xl">MASUK</button>}
          </div>
        </Reveal>
      </section>
    );

  const siap = c?.ready && raw;

  return (
    <section className="mx-auto max-w-3xl px-5 pb-32 pt-28 lg:max-w-5xl lg:px-8">
      <Reveal>
        <div className="panel p-5 md:p-6" style={{ transform: "none" }}>
          <h1 className="flex items-center gap-2 font-comic text-4xl tracking-wide"><Wrench size={32} strokeWidth={2.5} /> PANEL ADMIN</h1>
          <p className="mt-1 font-body font-bold text-neutral-600">Ubah isi web. Pengunjung hanya bisa melihat, mendengarkan, dan chat.</p>

          <div className="mt-4 flex flex-wrap gap-2">
            {TAB.map(({ id, label, Icon }) => (
              <button key={id} type="button" onClick={() => setTab(id)} className={`btn ${row} px-4 py-1 text-lg ${tab === id ? "bg-yellow-300" : "bg-white"}`}>
                <Icon size={18} strokeWidth={2.5} /> {label}
              </button>
            ))}
          </div>

          <div className="mt-5">
            {!siap ? (
              <p className="py-8 text-center font-comic text-2xl tracking-wide">MEMUAT...</p>
            ) : (
              <>
                {tab === "musik" && <ListEditor key="musik" kind="musik" contentKey="playlist" awal={c.playlist} refresh={c.refresh} onToast={onToast} />}
                {tab === "media" && <ListEditor key="media" kind="media" contentKey="media" awal={c.media} refresh={c.refresh} onToast={onToast} />}
                {tab === "murotal" && <MurotalEditor key="murotal" awal={c.murotal} refresh={c.refresh} onToast={onToast} />}
                {tab === "sosial" && <SosialEditor key="sosial" awal={raw} refresh={c.refresh} onToast={onToast} />}
                {tab === "teks" && <TeksEditor key="teks" awal={c.teks} refresh={c.refresh} onToast={onToast} />}
                {tab === "game" && <GameAdmin key="game" onToast={onToast} />}
                {tab === "lanyard" && <LanyardEditor key="lanyard" awal={c.lanyard?.gambar} refresh={c.refresh} onToast={onToast} />}
                {tab === "hadiah" && <HadiahAdmin key="hadiah" kaget={c.kaget} refresh={c.refresh} onToast={onToast} />}
              </>
            )}
          </div>
          <p className="mt-5 flex items-center gap-2 font-body text-sm font-bold text-neutral-500"><ImagePlus size={16} /> Batas unggah 50 MB per file (setelah dipangkas). Gambar dan video otomatis dikecilkan; pemrosesan video berjalan sepanjang durasinya, jadi jangan pindah tab dulu.</p>
        </div>
      </Reveal>
    </section>
  );
}
