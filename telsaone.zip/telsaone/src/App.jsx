import { useEffect, useState } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { supabase } from "./lib/supabase";
import { syncProfile, profileKey } from "./lib/profile";
import { NAV } from "./data";
import Navbar from "./components/Navbar";
import Dock from "./components/Dock";
import MiniPlayer from "./components/MiniPlayer";
import Footer from "./components/Footer";
import LoginModal from "./components/LoginModal";
import Home from "./pages/Home";
import Profil from "./pages/Profil";
import Chat from "./pages/Chat";
import Admin from "./pages/Admin";
import Game from "./pages/Game";
import DanaKagetPopup from "./components/DanaKagetPopup";
import { useContent } from "./lib/content";
import { useHadiahSaya } from "./lib/hadiah";
import { GAME_META } from "./lib/games";
import { LogOut, X } from "lucide-react";
import { inAppReset } from "./lib/flag";

function useActive(pathname) {
  const [active, setActive] = useState("pengenalan");
  useEffect(() => {
    if (pathname !== "/") return;
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: "-45% 0px -50% 0px" }
    );
    NAV.forEach((n) => { const el = document.getElementById(n.id); el && io.observe(el); });
    return () => io.disconnect();
  }, [pathname]);
  return pathname === "/profil" ? "profil" : pathname === "/chat" ? "chat" : pathname === "/admin" ? "admin" : pathname === "/game" ? "game" : active;
}

export default function App() {
  const { pathname } = useLocation();
  const active = useActive(pathname);
  const [user, setUser] = useState(null);
  const [modal, setModal] = useState(false);
  const [toast, setToast] = useState("");
  const [konfirmasi, setKonfirmasi] = useState(false);
  const { kaget, teks } = useContent();
  const { hadiah, tunda, selesai } = useHadiahSaya(user);
  const showToast = (m) => { setToast(m); setTimeout(() => setToast(""), 3500); };

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((event, s) => {
      setUser(s?.user ?? null);
      if (event === "PASSWORD_RECOVERY" && !inAppReset.on) setModal((m) => m || "reset");
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  // Samakan data profil publik (nama + foto) untuk dipakai di chat
  const pk = profileKey(user);
  useEffect(() => { if (user) syncProfile(user); }, [pk]); // eslint-disable-line react-hooks/exhaustive-deps

  const logout = async () => { await supabase?.auth.signOut(); setUser(null); showToast("Sampai jumpa lagi!"); };
  const mintaKeluar = () => setKonfirmasi(true);
  const yakinKeluar = async () => { setKonfirmasi(false); await logout(); };

  useEffect(() => {
    if (!konfirmasi) return undefined;
    const esc = (e) => e.key === "Escape" && setKonfirmasi(false);
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [konfirmasi]);
  const bukaMasuk = () => setModal("masuk");

  return (
    <>
      <Navbar active={active} user={user} onLogin={bukaMasuk} onRegister={() => setModal("daftar")} onLogout={mintaKeluar} />
      <main>
        <Routes>
          <Route path="/profil" element={<Profil user={user} onLogin={bukaMasuk} onLogout={mintaKeluar} onToast={showToast} />} />
          <Route path="/chat" element={<Chat user={user} onLogin={bukaMasuk} onToast={showToast} />} />
          <Route path="/game" element={<Game user={user} onLogin={bukaMasuk} onToast={showToast} />} />
          <Route path="/admin" element={<Admin user={user} onLogin={bukaMasuk} onToast={showToast} />} />
          <Route path="*" element={<Home user={user} onLogin={bukaMasuk} onToast={showToast} />} />
        </Routes>
      </main>
      <Footer />
      <MiniPlayer />
      <Dock active={active} user={user} onLogin={bukaMasuk} />
      {modal && <LoginModal key={modal} mode={modal} onClose={() => setModal(false)} onToast={showToast} />}
      {konfirmasi && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-5" onClick={() => setKonfirmasi(false)} role="dialog" aria-modal="true" aria-label="Konfirmasi keluar">
          <div className="pop panel w-full max-w-sm p-6 text-center" style={{ transform: "none" }} onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border-4 border-black bg-pink-200 shadow-[4px_4px_0_#111]"><LogOut size={30} strokeWidth={2.5} /></div>
            <h2 className="mt-3 font-comic text-3xl tracking-wide">{teks.keluar_judul}</h2>
            <p className="mt-1 font-body font-bold text-neutral-600">{teks.keluar_pesan}</p>
            <div className="mt-5 flex justify-center gap-3">
              <button onClick={yakinKeluar} className="btn inline-flex items-center justify-center gap-2 bg-pink-200 px-5 py-2 text-xl"><LogOut size={20} strokeWidth={2.5} /> {teks.keluar_ya}</button>
              <button onClick={() => setKonfirmasi(false)} className="btn inline-flex items-center justify-center gap-2 bg-white px-5 py-2 text-xl"><X size={20} strokeWidth={2.5} /> {teks.keluar_batal}</button>
            </div>
          </div>
        </div>
      )}
      {hadiah && (
        <DanaKagetPopup
          key={hadiah.id}
          hadiah={hadiah}
          kaget={kaget}
          nama={user?.user_metadata?.full_name || user?.email?.split("@")[0]}
          gameJudul={GAME_META.find((g) => g.id === hadiah.game_id)?.judul || hadiah.game_id}
          onTunda={() => tunda(hadiah.id)}
          onSelesai={() => selesai(hadiah.id)}
        />
      )}
      {toast && (
        <div className="pop fixed left-1/2 top-24 z-[200] -translate-x-1/2 border-4 border-black bg-yellow-300 px-4 py-2 font-comic text-lg tracking-wide shadow-[4px_4px_0_#111]">
          {toast}
        </div>
      )}
    </>
  );
}
