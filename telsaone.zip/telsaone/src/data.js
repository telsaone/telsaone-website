import { Sparkles, Music, Heart, Instagram, Music2, Youtube, Github } from "lucide-react";

export const NAV = [
  { id: "pengenalan", label: "Pengenalan", icon: Sparkles },
  { id: "isi", label: "Isi", icon: Music },
  { id: "penutup", label: "Penutup", icon: Heart },
];

// Taruh file musik di folder public/music lalu isi src, contoh: "/music/lagu1.mp3"
// Atau pilih lagu langsung dari perangkat lewat tombol di music player.
export const PLAYLIST = [
  { title: "Lagu Pertama", artist: "Isi nanti", src: "" },
  { title: "Lagu Kedua", artist: "Isi nanti", src: "" },
  { title: "Lagu Ketiga", artist: "Isi nanti", src: "" },
];

// Taruh file di folder public/media lalu isi src, contoh: "/media/foto1.jpg"
// type: "image" atau "video"
export const MEDIA = [
  { type: "image", title: "Foto 1", src: "" },
  { type: "image", title: "Foto 2", src: "" },
  { type: "video", title: "Video 1", src: "" },
  { type: "image", title: "Foto 3", src: "" },
  { type: "image", title: "Foto 4", src: "" },
  { type: "video", title: "Video 2", src: "" },
];

export const SOSIAL = [
  { label: "Instagram", icon: Instagram, href: "#" },
  { label: "TikTok", icon: Music2, href: "#" },
  { label: "YouTube", icon: Youtube, href: "#" },
  { label: "GitHub", icon: Github, href: "#" },
];

// Hadiah Dana Kaget untuk juara 1 yang bertahan (dapat diubah admin di Admin > HADIAH).
// Placeholder pesan: {nama}, {game}, {jam}
export const DANA_KAGET = {
  aktif: true,
  jam: 24,
  judul: "SELAMAT, JUARA!",
  pesan: "Kamu bertahan di peringkat 1 {game} selama {jam} jam tanpa tergeser. Ini hadiah Dana Kaget untukmu, {nama}. Buka linknya sekarang sebelum keduluan!",
  tombol: "BUKA DANA KAGET",
};

// Playlist murotal (hanya bisa diputar di halaman Game; musik otomatis berhenti saat murotal diputar).
// Cukup satu video relax (diputar berulang & bisu) + daftar file audio .mp3 / .m4a.
// Taruh file di public/murotal dan public/media, lalu isi seperti contoh:
//   MUROTAL_VIDEO_BAWAAN = "/media/relax.mp4"
//   { judul: "Surah Yasin", qari: "Nama Qari", audio: "/murotal/yasin.mp3" }
// Keduanya juga bisa diatur lewat Admin > MUROTAL tanpa mengubah kode.
export const MUROTAL_VIDEO_BAWAAN = "";
export const MUROTAL = [
  { judul: "Murotal Pertama", qari: "Isi nanti", audio: "" },
  { judul: "Murotal Kedua", qari: "Isi nanti", audio: "" },
  { judul: "Murotal Ketiga", qari: "Isi nanti", audio: "" },
];
