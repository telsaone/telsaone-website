-- Jalankan sekali di Supabase > SQL Editor.
-- Membuat: profil publik (nama + foto), pesan chat, dan bucket foto profil.

-- 1) Profil publik (diisi otomatis oleh aplikasi dari data login)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nama text not null default 'Pengguna',
  avatar_icon text not null default '',
  avatar_bg text not null default '#ffe45e',
  avatar_url text not null default '',
  bio text not null default '',
  joined_at timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

drop policy if exists "profil dibaca semua" on public.profiles;
create policy "profil dibaca semua" on public.profiles for select using (true);
drop policy if exists "profil sendiri insert" on public.profiles;
create policy "profil sendiri insert" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "profil sendiri update" on public.profiles;
create policy "profil sendiri update" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- 2) Pesan chat: semua orang boleh membaca, hanya yang login boleh mengirim
create table if not exists public.messages (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(btrim(content)) between 1 and 500),
  created_at timestamptz not null default now()
);
create index if not exists messages_created_idx on public.messages (created_at desc);
alter table public.messages enable row level security;

drop policy if exists "pesan dibaca semua" on public.messages;
create policy "pesan dibaca semua" on public.messages for select using (true);
drop policy if exists "pesan kirim sendiri" on public.messages;
create policy "pesan kirim sendiri" on public.messages for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "pesan hapus sendiri" on public.messages;
create policy "pesan hapus sendiri" on public.messages for delete to authenticated using (auth.uid() = user_id);

-- Realtime (pesan baru muncul langsung di semua perangkat)
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null; end $$;

-- 3) Bucket foto profil (publik dibaca, hanya pemilik yang boleh unggah/hapus)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 1048576, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists "avatar dibaca semua" on storage.objects;
create policy "avatar dibaca semua" on storage.objects for select using (bucket_id = 'avatars');
drop policy if exists "avatar unggah sendiri" on storage.objects;
create policy "avatar unggah sendiri" on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "avatar ubah sendiri" on storage.objects;
create policy "avatar ubah sendiri" on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "avatar hapus sendiri" on storage.objects;
create policy "avatar hapus sendiri" on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
