# telsaone

React + Vite + Tailwind CSS, tema komik, navbar, dock, dan login Supabase.

## Menjalankan
1. `npm install`
2. Salin `.env.example` menjadi `.env`, lalu isi URL dan anon key Supabase Anda.
3. `npm run dev`

## Supabase
- Authentication > Providers: aktifkan Google (dan GitHub jika dipakai).
- Authentication > URL Configuration: tambahkan `http://localhost:5173` dan domain produksi Anda ke Redirect URLs.

## Kustomisasi
- Playlist, media, dan sosial: `src/data.js` (file musik di `public/music`, media di `public/media`)
- Teks Pengenalan dan Penutup: `src/components/Sections.jsx`

## Login
- Masuk dan Daftar dengan email + password (tab terpisah), Google, GitHub, serta lupa/reset password.
- Supabase: Authentication > Sign In / Providers > Email harus aktif (default aktif). Jika "Confirm email" aktif, pengguna baru wajib klik tautan di email sebelum bisa masuk.

## Kode email (bukan link)
Konfirmasi pendaftaran dan reset password memakai kode angka. Ubah template email di Supabase
sesuai `telsaone-email-templates.md`, kalau tidak, email yang terkirim tetap berisi link.

## Halaman
- `/` halaman utama (Pengenalan, Isi, Penutup)
- `/profil` halaman profil: ubah nama, bio, avatar (icon + warna), ganti password. Data disimpan di user metadata Supabase (tanpa tabel tambahan).
- `/chat` obrolan publik: siapa saja bisa membaca dari perangkat mana pun, hanya yang login bisa mengirim. Nama dan foto diambil dari profil (tabel `profiles`, disinkronkan otomatis).
- Foto profil diunggah ke Supabase Storage (bucket `avatars`), otomatis dipotong persegi 256px.
- `/admin` panel admin (hanya akun Google admin, diatur lewat `VITE_ADMIN_EMAIL`): ubah musik, media (gambar/video), tautan sosial, dan teks. Pengunjung hanya melihat dan chat.
- Saat deploy, semua path harus diarahkan ke `index.html`. File `public/_redirects` (Netlify) dan `vercel.json` (Vercel) sudah disediakan.
- Di Supabase > URL Configuration, tambahkan `http://localhost:5173/**` dan `https://domain-anda/**` ke Redirect URLs.

## Chat dan foto profil (wajib, sekali saja)
Buka Supabase > SQL Editor, tempel isi `telsaone-chat.sql`, lalu Run. Ini membuat tabel `profiles` dan `messages`, mengaktifkan realtime, dan membuat bucket `avatars`.

## Admin (wajib, sekali saja)
Jalankan `telsaone-admin.sql` di SQL Editor. Admin ditentukan di Supabase lewat fungsi `is_admin()` (email Google admin; ganti `GANTI_DENGAN_EMAIL_ADMIN` di file SQL sebelum dijalankan), jadi pengunjung tidak bisa mengubah isi walau memakai API langsung. Pastikan Google provider aktif dan "Confirm email" tetap menyala.

## Ganti password
Di Profil > Keamanan: klik kotak, kode verifikasi dikirim ke email, masukkan kode, lalu isi password baru. Memakai template email reset password (kode) yang sama.

## Game (`/game`)
Ikon gamepad di dock membuka halaman Game. Daftar game ada di `src/pages/Game.jsx` (array `GAMES`); tambahkan game baru di sana.

## Statistik pengguna di chat
Klik foto atau nama seseorang di `/chat` untuk melihat nama, foto, bio, tanggal bergabung, dan jumlah pesannya. Jalankan `telsaone-profil-stat.sql` sekali di SQL Editor agar bio dan tanggal bergabung tersimpan di tabel `profiles`.


## Game, peringkat, dan monitoring admin

- Game ada di menu **Game** (Navbar dan Dock). Game pertama: **Brick Breaker**.
- Jalankan `telsaone-game.sql` sekali di Supabase > SQL Editor (setelah `telsaone-chat.sql` dan `telsaone-admin.sql`). File ini membuat tabel `games` (status terbit/arsip), tabel `game_scores` (skor terbaik tiap pemain), dan fungsi `kirim_skor`.
- Admin: tab **GAME** di halaman Admin untuk menerbitkan / mengarsipkan game, melihat jumlah pemain, total main, skor tertinggi, aktivitas terbaru, dan menghapus skor yang mencurigakan.
- Game baru: tambahkan metadata di `src/lib/games.js` (`GAME_META`) dan komponennya di `KOMPONEN` pada `src/pages/Game.jsx`. Komponen menerima props `onBack`, `user`, `onLogin`, `onSelesai({ score, level })`.

## Hadiah Dana Kaget untuk juara 1

Pemain yang bertahan di peringkat 1 selama 24 jam (bisa diubah) tanpa tergeser otomatis mendapat satu link Dana Kaget lewat pop-up ucapan selamat.

- Jalankan `telsaone-hadiah.sql` sekali di Supabase > SQL Editor (setelah `telsaone-game.sql`). Aman dijalankan ulang. File ini juga memperbarui fungsi `kirim_skor`.
- Admin > tab **HADIAH**: tempel link Dana Kaget (satu per baris, tiap link untuk satu pemenang), ubah judul/pesan/tombol pop-up (placeholder `{nama}`, `{game}`, `{jam}`), atur lama bertahan, jeda hadiah, pratinjau pop-up, dan lihat riwayat pemenang.
- Link bersifat rahasia: tabelnya hanya bisa dibaca admin. Pemenang menerimanya lewat pop-up; pop-up muncul lagi saat web dibuka berikutnya sampai link dibuka atau disalin.
- Jika stok link habis saat ada pemenang, ia ditandai "MENUNGGU LINK" dan otomatis mendapat link begitu admin menambah stok.
- Pemeriksaan berjalan saat ada pemain login / skor masuk (tanpa cron). Pemenang yang sedang offline tetap mendapat pop-up saat login berikutnya.

## Musik tetap berjalan
Pemutar musik bersifat global (`src/lib/music.jsx`, dipasang di `main.jsx`): musik tidak berhenti saat pindah halaman, dan di halaman selain beranda muncul kontrol mini (jeda / lanjut). Lagu, posisi, volume, dan status putar terakhir disimpan di browser; saat web dibuka lagi musik lanjut dari posisi terakhir. Jika browser memblokir pemutaran otomatis, musik berlanjut pada sentuhan/klik pertama.

## Hadiah per level & reset peringkat (Brick Breaker)
Jalankan `telsaone-level.sql` sekali di Supabase > SQL Editor (setelah `telsaone-hadiah.sql`).
Atur di Admin > HADIAH: hadiah per level, batas level, reset otomatis juara, dan tombol reset manual.

## Juara 1 tidak langsung hilang (tahan 24 jam)
Jalankan `telsaone-juara-tahan.sql` sekali di Supabase > SQL Editor (setelah `telsaone-level.sql`; sudah termasuk di `telsaone-semua.sql`).
Setelah juara menerima hadiah, ia tetap tampil di papan peringkat selama 24 jam baru skornya direset ke 0 (jika "Reset otomatis" aktif).
Lama penahanan diatur di **Admin > HADIAH > Tahan juara di papan setelah hadiah (jam)**: 0 sampai 720, 0 = langsung direset. Jika puncak direbut orang lain di masa tahan, skor juara lama tidak direset.
Centang **Permanen** di kolom yang sama agar juara tidak pernah hilang / direset otomatis (hanya tergeser kalau puncak direbut orang lain; reset manual admin tetap ada).
Semua pengaturan hadiah ini hanya bisa diubah admin (tersimpan di `site_content`, kunci `dana_kaget`).

## Password hanya untuk login email
Reset/ganti password hanya muncul dan berlaku untuk akun dengan login email. Untuk penguncian di sisi server,
jalankan `telsaone-password-email.sql` sekali di Supabase > SQL Editor.

## Story 24 jam
Jalankan `telsaone-story.sql` sekali di Supabase > SQL Editor (setelah `telsaone-chat.sql` dan `telsaone-admin.sql`).
Pengguna yang login bisa membuat story foto/video (video maks 30 detik, dipangkas otomatis seperti unggahan admin).
Story tampil publik 24 jam di Beranda dan Obrolan; setelah itu hilang dan file-nya dibersihkan otomatis oleh siapa pun yang membuka situs.
Admin dan pemilik bisa menghapus story dari penampil story.

### Durasi story (admin)
Jalankan `telsaone-story-durasi.sql` sekali. Admin bisa mengatur durasi tiap story: buka story, ketuk ikon jam, geser pilihan
1 j / 6 j / 12 j / 24 j / 3 hr / 7 hr / ∞ (permanen), lalu SIMPAN. Admin juga bisa memilih durasi saat membuat story.
Story permanen tidak pernah dihapus otomatis. Pengguna biasa tetap 24 jam.

### Hapus story tepat waktu dari server
Jalankan `telsaone-story-cron.sql` (aktifkan pg_cron & pg_net, isi URL proyek dan service_role key). Tiap 5 menit story > 24 jam
dihapus dari Storage lewat API resmi, baru barisnya dihapus.

## Suka website
Jalankan `telsaone-like.sql` sekali di Supabase > SQL Editor. Tombol suka (PulseHeart) tampil di halaman Profil;
satu akun hanya bisa memberi satu suka dan tidak bisa dibatalkan.

## Lanyard
Kotak lanyard 3D di bawah grid Media memakai komponen asli React Bits (`src/components/Lanyard.jsx`, tidak diubah) dengan tema bawaan (pita hitam, kartu putih, tanpa tulisan) dan library `three` (`npm install` sekali).
Gambar kartu penuh diatur admin di **Admin > LANYARD** (unggah / tempel URL / hapus, lalu SIMPAN). Bisa gambar (JPG/PNG/WebP) atau GIF animasi (tetap bergerak; didekode di `src/lib/gif.js`). Satu gambar dipakai di depan dan belakang kartu; kosong = kartu putih polos.
Tidak perlu SQL baru: disimpan di `site_content` (kunci `lanyard`) dan bucket `konten` dari `telsaone-admin.sql`. Rasio kartu 1.6 : 2.25 (mis. 1024x1440).

## Teks yang bisa diubah admin
Admin > TEKS memuat semua teks situs (menu, Beranda: pengenalan/isi/penutup, Music Player, Footer, Chat, Game, Profil), dikelompokkan dan bisa dikembalikan ke bawaan.
Daftar dan teks bawaannya ada di `src/lib/teks.js`; tambah baris baru di sana lalu pakai `useContent().teks.kunci_baru` di komponen.
Tidak bisa diubah: Bergabung, Login terakhir, Masuk via (statistik profil). Tidak perlu SQL baru (tersimpan di `site_content`, kunci `teks`).

## Database baru (urutan SQL)
Paling mudah: tempel `telsaone-semua.sql` di Supabase > SQL Editor, lalu Run. Isinya sama dengan file-file berikut, sudah berurutan:
chat, profil-stat, admin, game, hadiah, level, like, story, story-durasi, password-email.
Opsional terakhir: `telsaone-story-cron.sql` (aktifkan pg_cron dan pg_net, ganti URL proyek dan service_role key di dalamnya).
Admin ditentukan di `telsaone-admin.sql` (fungsi `is_admin()`); ganti emailnya jika akun admin baru berbeda.
Isi `.env` dari `.env.example` dengan URL dan anon key database baru.

## Animasi siswa dan Ulang tahun
Di beranda (bagian Isi): Musik, Media, **Animasi siswa**, Lanyard, lalu **Ulang tahun siswa**. Data nama, tanggal lahir, dan foto ada di `src/lib/siswa.js` (foto di `src/assets/siswa`). Tidak butuh SQL.
