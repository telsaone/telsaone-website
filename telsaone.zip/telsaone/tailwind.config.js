/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: { extend: { fontFamily: {
    comic: ["Bangers", "Impact", "sans-serif"],
    body: ['"Comic Neue"', '"Comic Sans MS"', "sans-serif"],
  } } },
  plugins: [],
};
